"use strict";
(() => {
var exports = {};
exports.id = 2147;
exports.ids = [2147];
exports.modules = {

/***/ 9735:
/***/ ((module) => {

module.exports = require("moralis-v1/node");

/***/ }),

/***/ 8295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handle)
/* harmony export */ });
const Moralis = __webpack_require__(9735);
async function handle(req, res) {
    const env = {
        APP_ID: "wi3vmn7KB9vehixK5lZ2vOuAfgbJzJNSjum3AkUp",
        APP_SERVER_URL: "https://b3o7m8vdspy1.usemoralis.com:2053/server",
        APP_MASTER_KEY: "zW1oIZN0Muq2OW5bBsAwsbm7pn22IJz1DJtHj2Tb"
    };
    if (req.method === "POST") {
        let { status , timestamp , data  } = req.body;
        await Moralis?.start({
            serverUrl: env.APP_SERVER_URL,
            appId: env.APP_ID,
            masterKey: env.APP_MASTER_KEY
        });
        if (status != "success") {
            res.status(500).json({
                msg: "Internal Server Error!!!"
            });
        }
        let token = timestamp;
        let id, address, amount;
        const resp = await Moralis.Cloud.run("getTempFile", {
            token
        });
        id = resp._id;
        address = resp.address;
        amount = resp.token_amount;
        if (id == null || id == undefined || address == null || address == undefined || amount == null || amount == undefined) {
            res.status(500).json({
                msg: "Internal Server Error!!!"
            });
        }
        await Moralis.Cloud.run("deleteTempFile", {
            id: id
        });
        await Moralis.Cloud.run("saveTokenSwap", data);
        await Moralis.Cloud.run("sendPushAdmin", {
            to: data["address"],
            amount: data["yltAmount"]
        });
        res.status(200).json({
            msg: "success"
        });
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8295));
module.exports = __webpack_exports__;

})();