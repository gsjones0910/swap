"use strict";
(() => {
var exports = {};
exports.id = 1727;
exports.ids = [1727];
exports.modules = {

/***/ 5666:
/***/ ((module) => {

module.exports = require("crypto-js");

/***/ }),

/***/ 9735:
/***/ ((module) => {

module.exports = require("moralis-v1/node");

/***/ }),

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 4887:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handle)
/* harmony export */ });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_0__]);
uuid__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const PRIVATE_KEY = "sk_test_rXXPihdgV35n9hWedz233wVN";
const stripe = __webpack_require__(8174)(PRIVATE_KEY);
const Moralis = __webpack_require__(9735);
//const crypto = require('crypto');
const CryptoJS = __webpack_require__(5666);

const YOUR_DOMAIN = "https://swapdev.yourlife.io";
async function handle(req, res) {
    const env = {
        APP_ID: "wi3vmn7KB9vehixK5lZ2vOuAfgbJzJNSjum3AkUp",
        APP_SERVER_URL: "https://b3o7m8vdspy1.usemoralis.com:2053/server",
        APP_MASTER_KEY: "zW1oIZN0Muq2OW5bBsAwsbm7pn22IJz1DJtHj2Tb"
    };
    const payid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__.v4)();
    if (req.method === "POST") {
        try {
            const { item  } = req.body;
            const redirectURL = "https://swapdev.yourlife.io";
            await Moralis.start({
                serverUrl: env.APP_SERVER_URL,
                appId: env.APP_ID,
                masterKey: env.APP_MASTER_KEY
            });
            if (item.address.length < 10 || item.email.length < 3 || item.price.length == 0 || item.amount <= 0) res.status(500).json({
                msg: "Internal Server Error!!!"
            });
            if (item.token.length < 20) res.status(500).json({
                msg: "Internal Server Error!!!"
            });
            const desc = "You will buy " + item.amount + " YLT Tokens and those will transferred directly to your wallet address : [ " + item.address + " ]";
            const transformedItem = {
                price_data: {
                    currency: "usd",
                    product_data: {
                        images: [
                            item.image
                        ],
                        name: item.name
                    },
                    unit_amount: item.price * 100
                },
                description: desc,
                quantity: item.quantity
            };
            const hash_1 = payid.replace(/-/g, "");
            const session = await stripe.checkout.sessions.create({
                payment_method_types: [
                    "card"
                ],
                line_items: [
                    transformedItem
                ],
                mode: "payment",
                success_url: YOUR_DOMAIN + "?status=success&token=" + hash_1 + "&timestamp=" + item.token,
                cancel_url: YOUR_DOMAIN + "?status=cancel&token=" + item.token,
                metadata: {
                    images: item.image,
                    buyer: item.address,
                    amount: item.amount,
                    uid: item.uid
                }
            });
            const data = {
                email: item.email,
                address: item.address,
                amount: item.price.toString(),
                token_amount: item.amount.toString(),
                token: hash_1,
                uid: item.uid
            };
            await Moralis?.Cloud.run("saveTempFile", data);
            res.status(200).json({
                id: session.id
            });
        } catch (e) {}
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4887));
module.exports = __webpack_exports__;

})();