"use strict";
(() => {
var exports = {};
exports.id = 7622;
exports.ids = [7622];
exports.modules = {

/***/ 9735:
/***/ ((module) => {

module.exports = require("moralis-v1/node");

/***/ }),

/***/ 3665:
/***/ ((module) => {

module.exports = require("raw-body");

/***/ }),

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 4891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./contracts/abi/REWARD.json
const REWARD_namespaceObject = JSON.parse('[{"inputs":[{"internalType":"address","name":"_ylt20","type":"address"},{"internalType":"contract YLProxy","name":"_proxy","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"timestamp","type":"uint256"}],"name":"DepositeToReward","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"timestamp","type":"uint256"}],"name":"TransferToUser","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"timestamp","type":"uint256"}],"name":"WithdrawFromReward","type":"event"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"depositeYLT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_user","type":"address"},{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"transferToUser","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"withdrawToken","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"ylproxy","outputs":[{"internalType":"contract YLProxy","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"ylt20","outputs":[{"internalType":"contract IERC20","name":"","type":"address"}],"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: external "ethers"
const external_ethers_namespaceObject = require("ethers");
;// CONCATENATED MODULE: ./pages/api/listenstripe.js
const getRawBody = __webpack_require__(3665);
const endpointSecret = process.env.NEXT_PUBLIC_STRIPE_WEBHOOK;
const RewardContractAddress = process.env.NEXT_PUBLIC_REWARD_ADDRESS;
const StripeSkey = "sk_test_rXXPihdgV35n9hWedz233wVN";
const stripe = __webpack_require__(8174)(StripeSkey, {
    apiVersion: "2022-11-15"
});


const Moralis = __webpack_require__(9735);
async function handler(req, res) {
    const env = {
        APP_ID: "wi3vmn7KB9vehixK5lZ2vOuAfgbJzJNSjum3AkUp",
        APP_SERVER_URL: "https://b3o7m8vdspy1.usemoralis.com:2053/server",
        APP_MASTER_KEY: "zW1oIZN0Muq2OW5bBsAwsbm7pn22IJz1DJtHj2Tb"
    };
    await Moralis.start({
        serverUrl: env.APP_SERVER_URL,
        appId: env.APP_ID,
        masterKey: env.APP_MASTER_KEY
    });
    const headers = req.headers;
    try {
        const rawBody = await getRawBody(req);
        const stripeEvent = stripe.webhooks.constructEvent(rawBody, headers["stripe-signature"], endpointSecret);
        const object = stripeEvent.data.object;
        switch(stripeEvent.type){
            case "checkout.session.completed":
                const buyer = object.metadata.buyer;
                const amount = object.metadata.amount;
                const uid = object.metadata.uid;
                const privateKey = process.env.NEXT_PUBLIC_REWARD_KEY;
                let wallet = new external_ethers_namespaceObject.ethers.Wallet(privateKey);
                let provider = new external_ethers_namespaceObject.ethers.providers.JsonRpcProvider("https://data-seed-prebsc-1-s3.binance.org:8545");
                let walletWithProvider = new external_ethers_namespaceObject.ethers.Wallet(privateKey, provider);
                const RewardContract = new external_ethers_namespaceObject.ethers.Contract(RewardContractAddress, REWARD_namespaceObject, walletWithProvider);
                let tx = await RewardContract.transferToUser(buyer, external_ethers_namespaceObject.ethers.utils.parseUnits(Number(amount).toString(), 18));
                const res1 = await tx.wait();
                await Moralis.Cloud.run("updateSwapTokenLogFromAuto", {
                    uid: uid,
                    scanid: res1.transactionHash,
                    state: 1
                });
                break;
            case "payment_intent.succeeded":
                break;
        }
        // Send success response
        res.send({
            status: "success"
        });
    } catch (error) {
        console.log("stripe webhook error", error);
        // Send error response
        res.send({
            status: "error",
            code: error.code,
            message: error.message
        });
    }
};
;
const config = {
    api: {
        bodyParser: false
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4891));
module.exports = __webpack_exports__;

})();