"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 9438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Web3ReactManager)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _connectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3966);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5820);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1407);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9620);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_connectors__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_connectors__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const MessageWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-dc887407-0"
})`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 20rem;
`;
const Message = styled_components__WEBPACK_IMPORTED_MODULE_3___default().h2.withConfig({
    componentId: "sc-dc887407-1"
})`
  color: ${({ theme  })=>theme.colors.primaryDark};
`;
function Web3ReactManager({ children  }) {
    const { active  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)();
    const { active: networkActive , error: networkError , activate: activateNetwork  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.useWeb3React)(_constants__WEBPACK_IMPORTED_MODULE_6__/* .NetworkContextName */ .AQ);
    // try to eagerly connect to an injected provider, if it exists and has granted access already
    const triedEager = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useEagerConnect */ .yW)();
    // after eagerly trying injected, if the network connect ever isn't active or in an error state, activate itd
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (triedEager && !networkActive && !networkError && !active) {
            activateNetwork(_connectors__WEBPACK_IMPORTED_MODULE_4__/* .network */ .L5);
        }
    }, [
        triedEager,
        networkActive,
        networkError,
        activateNetwork,
        active
    ]);
    // when there's no account connected, react to logins (broadly speaking) on the injected provider, if it exists
    (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useInactiveListener */ .fJ)(!triedEager);
    // handle delayed loader state
    const { 0: showLoader , 1: setShowLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const timeout = setTimeout(()=>{
            setShowLoader(true);
        }, 600);
        return ()=>{
            clearTimeout(timeout);
        };
    }, []);
    // on page load, do nothing until we've tried to connect to the injected connector
    if (!triedEager) {
        return null;
    }
    // if the account context isn't active, and there's an error on the network context, it's an irrecoverable error
    if (!active && networkError) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MessageWrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Message, {
                children: "unknownError"
            })
        });
    }
    // if neither context is active, spin
    if (!active && !networkActive) {
        return showLoader ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MessageWrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
        }) : null;
    }
    return children;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useIsWindowVisible)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Returns whether the window is currently visible to the user.
 */ function useIsWindowVisible() {
    const { 0: isWindowVisible , 1: setIsWindowVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: focused , 1: setFocused  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(isWindowVisible);
    const listener = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setFocused(isWindowVisible);
    }, [
        setFocused,
        isWindowVisible
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const VISIBILITY_STATE_SUPPORTED = "visibilityState" in document;
        setIsWindowVisible(!VISIBILITY_STATE_SUPPORTED || document.visibilityState !== "hidden");
        if (!VISIBILITY_STATE_SUPPORTED) return undefined;
        document.addEventListener("visibilitychange", listener);
        return ()=>{
            document.removeEventListener("visibilitychange", listener);
        };
    }, [
        listener
    ]);
    return focused;
};


/***/ }),

/***/ 5656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6921);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_ThemeContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(159);
/* harmony import */ var _components_Web3ReactManager__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9438);
/* harmony import */ var _utils_getLibrary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6440);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1484);
/* harmony import */ var _state_application_updater__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5179);
/* harmony import */ var _state_lists_updater__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5216);
/* harmony import */ var _state_multicall_updater__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2820);
/* harmony import */ var _state_transactions_updater__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8053);
/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4722);
/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Web3ReactManager__WEBPACK_IMPORTED_MODULE_8__, _state_application_updater__WEBPACK_IMPORTED_MODULE_11__, _state_lists_updater__WEBPACK_IMPORTED_MODULE_12__, _state_multicall_updater__WEBPACK_IMPORTED_MODULE_13__, _state_transactions_updater__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Web3ReactManager__WEBPACK_IMPORTED_MODULE_8__, _state_application_updater__WEBPACK_IMPORTED_MODULE_11__, _state_lists_updater__WEBPACK_IMPORTED_MODULE_12__, _state_multicall_updater__WEBPACK_IMPORTED_MODULE_13__, _state_transactions_updater__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const APP_ID = "wi3vmn7KB9vehixK5lZ2vOuAfgbJzJNSjum3AkUp";
const SERVER_URL = "https://b3o7m8vdspy1.usemoralis.com:2053/server";
const Web3ProviderNetwork = next_dynamic__WEBPACK_IMPORTED_MODULE_6___default()(null, {
    loadableGenerated: {
        modules: [
            "_app.tsx -> " + "../components/Web3ProviderNetwork"
        ]
    },
    ssr: false
});
const AppWrapper = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-8b8e572e-0"
})`
  flex-flow: column;
  align-items: flex-start;
  overflow-x: hidden;
`;
const BodyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-8b8e572e-1"
})`
  ${({ theme  })=>theme.mediaQueries.xs} {
    background-size: auto;
  }

  ${({ theme  })=>theme.mediaQueries.lg} {
    background-image: url('/images/background.png');
    background-repeat: no-repeat;
    background-position: center;
    background-size: contain, 266px, 266px;
    background-color: #0c0c0c;
    min-height: 90vh;
    font-family: Gilroy Medium;
  }
`;
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_moralis__WEBPACK_IMPORTED_MODULE_3__.MoralisProvider, {
        appId: APP_ID,
        serverUrl: SERVER_URL,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppWrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_web3_react_core__WEBPACK_IMPORTED_MODULE_2__.Web3ReactProvider, {
                getLibrary: _utils_getLibrary__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Web3ProviderNetwork, {
                    getLibrary: _utils_getLibrary__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Web3ReactManager__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
                            store: _state__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_ThemeContext__WEBPACK_IMPORTED_MODULE_7__/* .ThemeContextProvider */ .z, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.ModalProvider, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_lists_updater__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_application_updater__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_transactions_updater__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_state_multicall_updater__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BodyWrapper, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                    ...pageProps
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Updater)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _hooks_useDebounce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4841);
/* harmony import */ var _hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9218);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8887);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__]);
_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Updater() {
    const { library , chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const windowVisible = (0,_hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        chainId,
        blockNumber: null
    });
    const blockNumberCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((blockNumber)=>{
        setState((s)=>{
            if (chainId === s.chainId) {
                if (typeof s.blockNumber !== "number") return {
                    chainId,
                    blockNumber
                };
                return {
                    chainId,
                    blockNumber: Math.max(blockNumber, s.blockNumber)
                };
            }
            return s;
        });
    }, [
        chainId,
        setState
    ]);
    // attach/detach listeners
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!library || !chainId || !windowVisible) return undefined;
        setState({
            chainId,
            blockNumber: null
        });
        library.getBlockNumber().then(blockNumberCallback).catch((error)=>console.error(`Failed to get block number for chainId: ${chainId}`, error));
        library.on("block", blockNumberCallback);
        return ()=>{
            library.removeListener("block", blockNumberCallback);
        };
    }, [
        dispatch,
        chainId,
        library,
        blockNumberCallback,
        windowVisible
    ]);
    const debouncedState = (0,_hooks_useDebounce__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(state, 100);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!debouncedState.chainId || !debouncedState.blockNumber || !windowVisible) return;
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_5__/* .updateBlockNumber */ .fG)({
            chainId: debouncedState.chainId,
            blockNumber: debouncedState.blockNumber
        }));
    }, [
        windowVisible,
        dispatch,
        debouncedState.blockNumber,
        debouncedState.chainId
    ]);
    return null;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ typeInput),
/* harmony export */   "g": () => (/* binding */ Field)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

var Field;
(function(Field) {
    Field["LIQUIDITY_PERCENT"] = "LIQUIDITY_PERCENT";
    Field["LIQUIDITY"] = "LIQUIDITY";
    Field["CURRENCY_A"] = "CURRENCY_A";
    Field["CURRENCY_B"] = "CURRENCY_B";
})(Field || (Field = {}));
const typeInput = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("burn/typeInputBurn");


/***/ }),

/***/ 1484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZP": () => (/* binding */ state)
});

// UNUSED EXPORTS: persistor, store

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: ./state/global/actions.ts

// fired once when the app reloads but before the app renders
// allows any updates to be applied to store data loaded from localStorage
const updateVersion = (0,toolkit_.createAction)("global/updateVersion");
/* harmony default export */ const actions = ((/* unused pure expression or super */ null && (createAction)));

// EXTERNAL MODULE: ./state/application/actions.ts
var application_actions = __webpack_require__(8887);
;// CONCATENATED MODULE: ./state/application/reducer.ts


const initialState = {
    blockNumber: {},
    popupList: [],
    walletModalOpen: false,
    settingsMenuOpen: false
};
/* harmony default export */ const reducer = ((0,toolkit_.createReducer)(initialState, (builder)=>builder.addCase(application_actions/* updateBlockNumber */.fG, (state, action)=>{
        const { chainId , blockNumber  } = action.payload;
        if (typeof state.blockNumber[chainId] !== "number") {
            state.blockNumber[chainId] = blockNumber;
        } else {
            state.blockNumber[chainId] = Math.max(blockNumber, state.blockNumber[chainId]);
        }
    }).addCase(application_actions/* toggleWalletModal */.Pd, (state)=>{
        state.walletModalOpen = !state.walletModalOpen;
    }).addCase(application_actions/* toggleSettingsMenu */.mm, (state)=>{
        state.settingsMenuOpen = !state.settingsMenuOpen;
    }).addCase(application_actions/* addPopup */.i8, (state, { payload: { content , key , removeAfterMs =15000  }  })=>{
        state.popupList = (key ? state.popupList.filter((popup)=>popup.key !== key) : state.popupList).concat([
            {
                key: key || (0,toolkit_.nanoid)(),
                show: true,
                content,
                removeAfterMs
            }
        ]);
    }).addCase(application_actions/* removePopup */.hC, (state, { payload: { key  }  })=>{
        state.popupList.forEach((p)=>{
            if (p.key === key) {
                p.show = false;
            }
        });
    })));

// EXTERNAL MODULE: ./constants/index.ts
var constants = __webpack_require__(1407);
// EXTERNAL MODULE: ./state/user/actions.ts
var user_actions = __webpack_require__(8652);
;// CONCATENATED MODULE: ./state/user/reducer.ts




const currentTimestamp = ()=>new Date().getTime();
function pairKey(token0Address, token1Address) {
    return `${token0Address};${token1Address}`;
}
const reducer_initialState = {
    userDarkMode: null,
    matchesDarkMode: false,
    userExpertMode: false,
    userSlippageTolerance: constants/* INITIAL_ALLOWED_SLIPPAGE */.gv,
    userDeadline: constants/* DEFAULT_DEADLINE_FROM_NOW */.PY,
    tokens: {},
    pairs: {},
    timestamp: currentTimestamp(),
    audioPlay: true
};
/* harmony default export */ const user_reducer = ((0,toolkit_.createReducer)(reducer_initialState, (builder)=>builder.addCase(updateVersion, (state)=>{
        // slippage isnt being tracked in local storage, reset to default
        // noinspection SuspiciousTypeOfGuard
        if (typeof state.userSlippageTolerance !== "number") {
            state.userSlippageTolerance = constants/* INITIAL_ALLOWED_SLIPPAGE */.gv;
        }
        // deadline isnt being tracked in local storage, reset to default
        // noinspection SuspiciousTypeOfGuard
        if (typeof state.userDeadline !== "number") {
            state.userDeadline = constants/* DEFAULT_DEADLINE_FROM_NOW */.PY;
        }
        state.lastUpdateVersionTimestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserDarkMode */.vP, (state, action)=>{
        state.userDarkMode = action.payload.userDarkMode;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateMatchesDarkMode */._I, (state, action)=>{
        state.matchesDarkMode = action.payload.matchesDarkMode;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserExpertMode */.zv, (state, action)=>{
        state.userExpertMode = action.payload.userExpertMode;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserSlippageTolerance */.rQ, (state, action)=>{
        state.userSlippageTolerance = action.payload.userSlippageTolerance;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* updateUserDeadline */.gw, (state, action)=>{
        state.userDeadline = action.payload.userDeadline;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* addSerializedToken */.eg, (state, { payload: { serializedToken  }  })=>{
        state.tokens[serializedToken.chainId] = state.tokens[serializedToken.chainId] || {};
        state.tokens[serializedToken.chainId][serializedToken.address] = serializedToken;
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* removeSerializedToken */.zQ, (state, { payload: { address , chainId  }  })=>{
        state.tokens[chainId] = state.tokens[chainId] || {};
        delete state.tokens[chainId][address];
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* addSerializedPair */.f9, (state, { payload: { serializedPair  }  })=>{
        if (serializedPair.token0.chainId === serializedPair.token1.chainId && serializedPair.token0.address !== serializedPair.token1.address) {
            const { chainId  } = serializedPair.token0;
            state.pairs[chainId] = state.pairs[chainId] || {};
            state.pairs[chainId][pairKey(serializedPair.token0.address, serializedPair.token1.address)] = serializedPair;
        }
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* removeSerializedPair */.cd, (state, { payload: { chainId , tokenAAddress , tokenBAddress  }  })=>{
        if (state.pairs[chainId]) {
            // just delete both keys if either exists
            delete state.pairs[chainId][pairKey(tokenAAddress, tokenBAddress)];
            delete state.pairs[chainId][pairKey(tokenBAddress, tokenAAddress)];
        }
        state.timestamp = currentTimestamp();
    }).addCase(user_actions/* muteAudio */.B8, (state)=>{
        state.audioPlay = false;
    }).addCase(user_actions/* unmuteAudio */.u7, (state)=>{
        state.audioPlay = true;
    })));

// EXTERNAL MODULE: ./state/transactions/actions.ts
var transactions_actions = __webpack_require__(5843);
;// CONCATENATED MODULE: ./state/transactions/reducer.ts


const now = ()=>new Date().getTime();
const transactions_reducer_initialState = {};
/* harmony default export */ const transactions_reducer = ((0,toolkit_.createReducer)(transactions_reducer_initialState, (builder)=>builder.addCase(transactions_actions/* addTransaction */.dT, (transactions, { payload: { chainId , from , hash , approval , summary  }  })=>{
        if (transactions[chainId]?.[hash]) {
            throw Error("Attempted to add existing transaction.");
        }
        const txs = transactions[chainId] ?? {};
        txs[hash] = {
            hash,
            approval,
            summary,
            from,
            addedTime: now()
        };
        transactions[chainId] = txs;
    }).addCase(transactions_actions/* clearAllTransactions */.fY, (transactions, { payload: { chainId  }  })=>{
        if (!transactions[chainId]) return;
        transactions[chainId] = {};
    }).addCase(transactions_actions/* checkedTransaction */.LN, (transactions, { payload: { chainId , hash , blockNumber  }  })=>{
        const tx = transactions[chainId]?.[hash];
        if (!tx) {
            return;
        }
        if (!tx.lastCheckedBlockNumber) {
            tx.lastCheckedBlockNumber = blockNumber;
        } else {
            tx.lastCheckedBlockNumber = Math.max(blockNumber, tx.lastCheckedBlockNumber);
        }
    }).addCase(transactions_actions/* finalizeTransaction */.Aw, (transactions, { payload: { hash , chainId , receipt  }  })=>{
        const tx = transactions[chainId]?.[hash];
        if (!tx) {
            return;
        }
        tx.receipt = receipt;
        tx.confirmedTime = now();
    })));

// EXTERNAL MODULE: ./state/swap/actions.ts
var swap_actions = __webpack_require__(9911);
;// CONCATENATED MODULE: ./state/swap/reducer.ts


const swap_reducer_initialState = {
    independentField: swap_actions/* Field.INPUT */.gN.INPUT,
    typedValue: "",
    [swap_actions/* Field.INPUT */.gN.INPUT]: {
        currencyId: ""
    },
    [swap_actions/* Field.OUTPUT */.gN.OUTPUT]: {
        currencyId: ""
    },
    recipient: null
};
/* harmony default export */ const swap_reducer = ((0,toolkit_.createReducer)(swap_reducer_initialState, (builder)=>builder.addCase(swap_actions/* replaceSwapState */.mV, (state, { payload: { typedValue , recipient , field , inputCurrencyId , outputCurrencyId  }  })=>{
        return {
            [swap_actions/* Field.INPUT */.gN.INPUT]: {
                currencyId: inputCurrencyId
            },
            [swap_actions/* Field.OUTPUT */.gN.OUTPUT]: {
                currencyId: outputCurrencyId
            },
            independentField: field,
            typedValue,
            recipient
        };
    }).addCase(swap_actions/* selectCurrency */.j, (state, { payload: { currencyId , field  }  })=>{
        const otherField = field === swap_actions/* Field.INPUT */.gN.INPUT ? swap_actions/* Field.OUTPUT */.gN.OUTPUT : swap_actions/* Field.INPUT */.gN.INPUT;
        if (currencyId === state[otherField].currencyId) {
            // the case where we have to swap the order 
            return {
                ...state,
                independentField: state.independentField === swap_actions/* Field.INPUT */.gN.INPUT ? swap_actions/* Field.OUTPUT */.gN.OUTPUT : swap_actions/* Field.INPUT */.gN.INPUT,
                [field]: {
                    currencyId
                },
                [otherField]: {
                    currencyId: state[field].currencyId
                }
            };
        }
        // the normal case 
        return {
            ...state,
            [field]: {
                currencyId
            }
        };
    }).addCase(swap_actions/* switchCurrencies */.KS, (state)=>{
        return {
            ...state,
            independentField: state.independentField === swap_actions/* Field.INPUT */.gN.INPUT ? swap_actions/* Field.OUTPUT */.gN.OUTPUT : swap_actions/* Field.INPUT */.gN.INPUT,
            [swap_actions/* Field.INPUT */.gN.INPUT]: {
                currencyId: state[swap_actions/* Field.OUTPUT */.gN.OUTPUT].currencyId
            },
            [swap_actions/* Field.OUTPUT */.gN.OUTPUT]: {
                currencyId: state[swap_actions/* Field.INPUT */.gN.INPUT].currencyId
            }
        };
    }).addCase(swap_actions/* typeInput */.LC, (state, { payload: { field , typedValue  }  })=>{
        return {
            ...state,
            independentField: field,
            typedValue
        };
    }).addCase(swap_actions/* setRecipient */.He, (state, { payload: { recipient  }  })=>{
        state.recipient = recipient;
    })));

// EXTERNAL MODULE: ./state/mint/actions.ts
var mint_actions = __webpack_require__(8149);
;// CONCATENATED MODULE: ./state/mint/reducer.ts


const mint_reducer_initialState = {
    independentField: mint_actions/* Field.CURRENCY_A */.gN.CURRENCY_A,
    typedValue: "",
    otherTypedValue: ""
};
/* harmony default export */ const mint_reducer = ((0,toolkit_.createReducer)(mint_reducer_initialState, (builder)=>builder.addCase(mint_actions/* resetMintState */.dA, ()=>mint_reducer_initialState).addCase(mint_actions/* typeInput */.LC, (state, { payload: { field , typedValue , noLiquidity  }  })=>{
        if (noLiquidity) {
            // they're typing into the field they've last typed in
            if (field === state.independentField) {
                return {
                    ...state,
                    independentField: field,
                    typedValue
                };
            }
            // they're typing into a new field, store the other value
            return {
                ...state,
                independentField: field,
                typedValue,
                otherTypedValue: state.typedValue
            };
        }
        return {
            ...state,
            independentField: field,
            typedValue,
            otherTypedValue: ""
        };
    })));

// EXTERNAL MODULE: external "@uniswap/token-lists"
var token_lists_ = __webpack_require__(1554);
// EXTERNAL MODULE: ./constants/lists.ts
var lists = __webpack_require__(7027);
// EXTERNAL MODULE: ./state/lists/actions.ts
var lists_actions = __webpack_require__(9775);
// EXTERNAL MODULE: ./constants/token/pancakeswap.json
var pancakeswap = __webpack_require__(7449);
;// CONCATENATED MODULE: ./state/lists/reducer.ts






const NEW_LIST_STATE = {
    error: null,
    current: null,
    loadingRequestId: null,
    pendingUpdate: null
};
const lists_reducer_initialState = {
    lastInitializedDefaultListOfLists: lists/* DEFAULT_LIST_OF_LISTS */.L,
    byUrl: {
        ...lists/* DEFAULT_LIST_OF_LISTS.reduce */.L.reduce((memo, listUrl)=>{
            memo[listUrl] = NEW_LIST_STATE;
            return memo;
        }, {}),
        [lists/* DEFAULT_TOKEN_LIST_URL */.$]: {
            error: null,
            current: pancakeswap,
            loadingRequestId: null,
            pendingUpdate: null
        }
    },
    selectedListUrl: lists/* DEFAULT_TOKEN_LIST_URL */.$
};
/* harmony default export */ const lists_reducer = ((0,toolkit_.createReducer)(lists_reducer_initialState, (builder)=>builder.addCase(lists_actions/* fetchTokenList.pending */.Dn.pending, (state, { payload: { requestId , url  }  })=>{
        state.byUrl[url] = {
            current: null,
            pendingUpdate: null,
            ...state.byUrl[url],
            loadingRequestId: requestId,
            error: null
        };
    }).addCase(lists_actions/* fetchTokenList.fulfilled */.Dn.fulfilled, (state, { payload: { requestId , tokenList , url  }  })=>{
        const current = state.byUrl[url]?.current;
        const loadingRequestId = state.byUrl[url]?.loadingRequestId;
        // no-op if update does nothing
        if (current) {
            const upgradeType = (0,token_lists_.getVersionUpgrade)(current.version, tokenList.version);
            if (upgradeType === token_lists_.VersionUpgrade.NONE) return;
            if (loadingRequestId === null || loadingRequestId === requestId) {
                state.byUrl[url] = {
                    ...state.byUrl[url],
                    loadingRequestId: null,
                    error: null,
                    current,
                    pendingUpdate: tokenList
                };
            }
        } else {
            state.byUrl[url] = {
                ...state.byUrl[url],
                loadingRequestId: null,
                error: null,
                current: tokenList,
                pendingUpdate: null
            };
        }
    }).addCase(lists_actions/* fetchTokenList.rejected */.Dn.rejected, (state, { payload: { url , requestId , errorMessage  }  })=>{
        if (state.byUrl[url]?.loadingRequestId !== requestId) {
            // no-op since it's not the latest request
            return;
        }
        state.byUrl[url] = {
            ...state.byUrl[url],
            loadingRequestId: null,
            error: errorMessage,
            current: null,
            pendingUpdate: null
        };
    }).addCase(lists_actions/* selectList */.Fz, (state, { payload: url  })=>{
        state.selectedListUrl = url;
        if (!state.byUrl[url]) {
            state.byUrl[url] = NEW_LIST_STATE;
        }
    }).addCase(lists_actions/* addList */.$8, (state, { payload: url  })=>{
        if (!state.byUrl[url]) {
            state.byUrl[url] = NEW_LIST_STATE;
        }
    }).addCase(lists_actions/* removeList */.J_, (state, { payload: url  })=>{
        if (state.byUrl[url]) {
            delete state.byUrl[url];
        }
        if (state.selectedListUrl === url) {
            state.selectedListUrl = Object.keys(state.byUrl)[0];
        }
    }).addCase(lists_actions/* acceptListUpdate */.xJ, (state, { payload: url  })=>{
        if (!state.byUrl[url]?.pendingUpdate) {
            throw new Error("accept list update called without pending update");
        }
        state.byUrl[url] = {
            ...state.byUrl[url],
            pendingUpdate: null,
            current: state.byUrl[url].pendingUpdate
        };
    }).addCase(updateVersion, (state)=>{
        // state loaded from localStorage, but new lists have never been initialized
        if (!state.lastInitializedDefaultListOfLists) {
            state.byUrl = lists_reducer_initialState.byUrl;
            state.selectedListUrl = undefined;
        } else if (state.lastInitializedDefaultListOfLists) {
            const lastInitializedSet = state.lastInitializedDefaultListOfLists.reduce((s, l)=>s.add(l), new Set());
            const newListOfListsSet = lists/* DEFAULT_LIST_OF_LISTS.reduce */.L.reduce((s, l)=>s.add(l), new Set());
            lists/* DEFAULT_LIST_OF_LISTS.forEach */.L.forEach((listUrl)=>{
                if (!lastInitializedSet.has(listUrl)) {
                    state.byUrl[listUrl] = NEW_LIST_STATE;
                }
            });
            state.lastInitializedDefaultListOfLists.forEach((listUrl)=>{
                if (!newListOfListsSet.has(listUrl)) {
                    delete state.byUrl[listUrl];
                }
            });
        }
        state.lastInitializedDefaultListOfLists = lists/* DEFAULT_LIST_OF_LISTS */.L;
    })));

// EXTERNAL MODULE: ./state/burn/actions.ts
var burn_actions = __webpack_require__(3828);
;// CONCATENATED MODULE: ./state/burn/reducer.ts


const burn_reducer_initialState = {
    independentField: burn_actions/* Field.LIQUIDITY_PERCENT */.g.LIQUIDITY_PERCENT,
    typedValue: "0"
};
/* harmony default export */ const burn_reducer = ((0,toolkit_.createReducer)(burn_reducer_initialState, (builder)=>builder.addCase(burn_actions/* typeInput */.L, (state, { payload: { field , typedValue  }  })=>{
        return {
            ...state,
            independentField: field,
            typedValue
        };
    })));

// EXTERNAL MODULE: ./state/multicall/actions.ts
var multicall_actions = __webpack_require__(3146);
;// CONCATENATED MODULE: ./state/multicall/reducer.ts


const multicall_reducer_initialState = {
    callResults: {}
};
/* harmony default export */ const multicall_reducer = ((0,toolkit_.createReducer)(multicall_reducer_initialState, (builder)=>builder.addCase(multicall_actions/* addMulticallListeners */.Dd, (state, { payload: { calls , chainId , options: { blocksPerFetch =1  } = {}  }  })=>{
        const listeners = state.callListeners ? state.callListeners : state.callListeners = {};
        listeners[chainId] = listeners[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            listeners[chainId][callKey] = listeners[chainId][callKey] ?? {};
            listeners[chainId][callKey][blocksPerFetch] = (listeners[chainId][callKey][blocksPerFetch] ?? 0) + 1;
        });
    }).addCase(multicall_actions/* removeMulticallListeners */.$x, (state, { payload: { chainId , calls , options: { blocksPerFetch =1  } = {}  }  })=>{
        const listeners = state.callListeners ? state.callListeners : state.callListeners = {};
        if (!listeners[chainId]) return;
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            if (!listeners[chainId][callKey]) return;
            if (!listeners[chainId][callKey][blocksPerFetch]) return;
            if (listeners[chainId][callKey][blocksPerFetch] === 1) {
                delete listeners[chainId][callKey][blocksPerFetch];
            } else {
                listeners[chainId][callKey][blocksPerFetch]--;
            }
        });
    }).addCase(multicall_actions/* fetchingMulticallResults */.nu, (state, { payload: { chainId , fetchingBlockNumber , calls  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            const current = state.callResults[chainId][callKey];
            if (!current) {
                state.callResults[chainId][callKey] = {
                    fetchingBlockNumber
                };
            } else {
                if ((current.fetchingBlockNumber ?? 0) >= fetchingBlockNumber) return;
                state.callResults[chainId][callKey].fetchingBlockNumber = fetchingBlockNumber;
            }
        });
    }).addCase(multicall_actions/* errorFetchingMulticallResults */.wC, (state, { payload: { fetchingBlockNumber , chainId , calls  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        calls.forEach((call)=>{
            const callKey = (0,multicall_actions/* toCallKey */.kG)(call);
            const current = state.callResults[chainId][callKey];
            if (!current) return; // only should be dispatched if we are already fetching
            if (current.fetchingBlockNumber === fetchingBlockNumber) {
                delete current.fetchingBlockNumber;
                current.data = null;
                current.blockNumber = fetchingBlockNumber;
            }
        });
    }).addCase(multicall_actions/* updateMulticallResults */.zT, (state, { payload: { chainId , results , blockNumber  }  })=>{
        state.callResults[chainId] = state.callResults[chainId] ?? {};
        Object.keys(results).forEach((callKey)=>{
            const current = state.callResults[chainId][callKey];
            if ((current?.blockNumber ?? 0) > blockNumber) return;
            state.callResults[chainId][callKey] = {
                data: results[callKey],
                blockNumber
            };
        });
    })));

// EXTERNAL MODULE: ./state/ylttoast/index.ts
var ylttoast = __webpack_require__(2684);
;// CONCATENATED MODULE: ./state/reducer.ts











const rootReducer = (0,toolkit_.combineReducers)({
    application: reducer,
    updateVersion: updateVersion,
    user: user_reducer,
    transactions: transactions_reducer,
    swap: swap_reducer,
    mint: mint_reducer,
    lists: lists_reducer,
    burn: burn_reducer,
    multicall: multicall_reducer,
    notification: ylttoast/* default */.Z
});
/* harmony default export */ const state_reducer = (rootReducer);

;// CONCATENATED MODULE: ./state/index.ts





// https://github.com/rt2zz/redux-persist/blob/master/docs/migrations.md#example-with-createmigrate
const migrations = {
    // @ts-ignore
    0: (state)=>{
        // migration clear out lists state
        return {
            ...state,
            lists: undefined
        };
    }
};
const PERSISTED_KEYS = [
    "user",
    "transactions",
    "lists",
    "slippage"
];
const persistConfig = {
    key: "root",
    whitelist: PERSISTED_KEYS,
    version: 0,
    storage: (storage_default()),
    migrate: (0,external_redux_persist_namespaceObject.createMigrate)(migrations, {
        debug: "production" === "development"
    })
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, state_reducer);
const store = (0,toolkit_.configureStore)({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            thunk: true,
            immutableCheck: true,
            serializableCheck: false
        }),
    devTools: "production" === "development"
});
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);
store.dispatch(updateVersion());
/* harmony default export */ const state = (store);


/***/ }),

/***/ 5216:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Updater)
/* harmony export */ });
/* harmony import */ var _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1554);
/* harmony import */ var _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5820);
/* harmony import */ var _hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9899);
/* harmony import */ var _hooks_useInterval__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(138);
/* harmony import */ var _hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9218);
/* harmony import */ var _application_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8887);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9775);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_3__, _hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks__WEBPACK_IMPORTED_MODULE_3__, _hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function Updater() {
    const { library  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActiveWeb3React */ .aQ)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const lists = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.lists.byUrl);
    const isWindowVisible = (0,_hooks_useIsWindowVisible__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const fetchList = (0,_hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_4__/* .useFetchListCallback */ .j)();
    const fetchAllListsCallback = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (!isWindowVisible) return;
        Object.keys(lists).forEach((url)=>fetchList(url).catch((error)=>console.error("interval list fetching error", error)));
    }, [
        fetchList,
        isWindowVisible,
        lists
    ]);
    // fetch all lists every 10 minutes, but only after we initialize library
    (0,_hooks_useInterval__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(fetchAllListsCallback, library ? 1000 * 60 * 10 : null);
    // whenever a list is not loaded and not loading, try again to load it
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        Object.keys(lists).forEach((listUrl)=>{
            const list = lists[listUrl];
            if (!list.current && !list.loadingRequestId && !list.error) {
                fetchList(listUrl).catch((error)=>console.error("list added fetching error", error));
            }
        });
    }, [
        dispatch,
        fetchList,
        library,
        lists
    ]);
    // automatically update lists if versions are minor/patch
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        Object.keys(lists).forEach((listUrl)=>{
            const list = lists[listUrl];
            if (list.current && list.pendingUpdate) {
                const bump = (0,_uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.getVersionUpgrade)(list.current.version, list.pendingUpdate.version);
                switch(bump){
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.VersionUpgrade.NONE:
                        throw new Error("unexpected no version bump");
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.VersionUpgrade.PATCH:
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.VersionUpgrade.MINOR:
                        const min = (0,_uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.minVersionBump)(list.current.tokens, list.pendingUpdate.tokens);
                        // automatically update minor/patch as long as bump matches the min update
                        if (bump >= min) {
                            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_8__/* .acceptListUpdate */ .xJ)(listUrl));
                            dispatch((0,_application_actions__WEBPACK_IMPORTED_MODULE_7__/* .addPopup */ .i8)({
                                key: listUrl,
                                content: {
                                    listUpdate: {
                                        listUrl,
                                        oldList: list.current,
                                        newList: list.pendingUpdate,
                                        auto: true
                                    }
                                }
                            }));
                        } else {
                            console.error(`List at url ${listUrl} could not automatically update because the version bump was only PATCH/MINOR while the update had breaking changes and should have been MAJOR`);
                        }
                        break;
                    case _uniswap_token_lists__WEBPACK_IMPORTED_MODULE_0__.VersionUpgrade.MAJOR:
                        dispatch((0,_application_actions__WEBPACK_IMPORTED_MODULE_7__/* .addPopup */ .i8)({
                            key: listUrl,
                            content: {
                                listUpdate: {
                                    listUrl,
                                    auto: false,
                                    oldList: list.current,
                                    newList: list.pendingUpdate
                                }
                            },
                            removeAfterMs: null
                        }));
                }
            }
        });
    }, [
        dispatch,
        lists
    ]);
    return null;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LC": () => (/* binding */ typeInput),
/* harmony export */   "dA": () => (/* binding */ resetMintState),
/* harmony export */   "gN": () => (/* binding */ Field)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

var Field;
(function(Field) {
    Field["CURRENCY_A"] = "CURRENCY_A";
    Field["CURRENCY_B"] = "CURRENCY_B";
})(Field || (Field = {}));
const typeInput = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("mint/typeInputMint");
const resetMintState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("mint/resetMintState");


/***/ }),

/***/ 2820:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ Updater)
/* harmony export */ });
/* unused harmony exports activeListeningKeys, outdatedListeningKeys */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
/* harmony import */ var _hooks_useDebounce__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4841);
/* harmony import */ var _utils_chunkArray__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7615);
/* harmony import */ var _utils_retry__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6190);
/* harmony import */ var _application_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9348);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3146);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__, _hooks_useContract__WEBPACK_IMPORTED_MODULE_3__, _application_hooks__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks__WEBPACK_IMPORTED_MODULE_2__, _hooks_useContract__WEBPACK_IMPORTED_MODULE_3__, _application_hooks__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// chunk calls so we do not exceed the gas limit
const CALL_CHUNK_SIZE = 500;
/**
 * Fetches a chunk of calls, enforcing a minimum block number constraint
 * @param multicallContract multicall contract to fetch against
 * @param chunk chunk of calls to make
 * @param minBlockNumber minimum block number of the result set
 */ async function fetchChunk(multicallContract, chunk, minBlockNumber) {
    let resultsBlockNumber;
    let returnData;
    try {
        [resultsBlockNumber, returnData] = await multicallContract.aggregate(chunk.map((obj)=>[
                obj.address,
                obj.callData
            ]));
    } catch (error) {
        console.info("Failed to fetch chunk inside retry", error);
        throw error;
    }
    if (resultsBlockNumber.toNumber() < minBlockNumber) {
        throw new _utils_retry__WEBPACK_IMPORTED_MODULE_5__/* .RetryableError */ .s1("Fetched for old block number");
    }
    return {
        results: returnData,
        blockNumber: resultsBlockNumber.toNumber()
    };
}
/**
 * From the current all listeners state, return each call key mapped to the
 * minimum number of blocks per fetch. This is how often each key must be fetched.
 * @param allListeners the all listeners state
 * @param chainId the current chain id
 */ function activeListeningKeys(allListeners, chainId) {
    if (!allListeners || !chainId) return {};
    const listeners = allListeners[chainId];
    if (!listeners) return {};
    return Object.keys(listeners).reduce((memo, callKey)=>{
        const keyListeners = listeners[callKey];
        memo[callKey] = Object.keys(keyListeners).filter((key)=>{
            const blocksPerFetch = parseInt(key);
            if (blocksPerFetch <= 0) return false;
            return keyListeners[blocksPerFetch] > 0;
        }).reduce((previousMin, current)=>{
            return Math.min(previousMin, parseInt(current));
        }, Infinity);
        return memo;
    }, {});
}
/**
 * Return the keys that need to be refetched
 * @param callResults current call result state
 * @param listeningKeys each call key mapped to how old the data can be in blocks
 * @param chainId the current chain id
 * @param latestBlockNumber the latest block number
 */ function outdatedListeningKeys(callResults, listeningKeys, chainId, latestBlockNumber) {
    if (!chainId || !latestBlockNumber) return [];
    const results = callResults[chainId];
    // no results at all, load everything
    if (!results) return Object.keys(listeningKeys);
    return Object.keys(listeningKeys).filter((callKey)=>{
        const blocksPerFetch = listeningKeys[callKey];
        const data = callResults[chainId][callKey];
        // no data, must fetch
        if (!data) return true;
        const minDataBlockNumber = latestBlockNumber - (blocksPerFetch - 1);
        // already fetching it for a recent enough block, don't refetch it
        if (data.fetchingBlockNumber && data.fetchingBlockNumber >= minDataBlockNumber) return false;
        // if data is older than minDataBlockNumber, fetch it
        return !data.blockNumber || data.blockNumber < minDataBlockNumber;
    });
}
function Updater() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const state = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((s)=>s.multicall);
    // wait for listeners to settle before triggering updates
    const debouncedListeners = (0,_hooks_useDebounce__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(state.callListeners, 100);
    const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useBlockNumber */ .Ov)();
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const multicallContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useMulticallContract */ .gq)();
    const cancellations = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    const listeningKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return activeListeningKeys(debouncedListeners, chainId);
    }, [
        debouncedListeners,
        chainId
    ]);
    const unserializedOutdatedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return outdatedListeningKeys(state.callResults, listeningKeys, chainId, latestBlockNumber);
    }, [
        chainId,
        state.callResults,
        listeningKeys,
        latestBlockNumber
    ]);
    const serializedOutdatedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>JSON.stringify(unserializedOutdatedCallKeys.sort()), [
        unserializedOutdatedCallKeys, 
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!latestBlockNumber || !chainId || !multicallContract) return;
        const outdatedCallKeys = JSON.parse(serializedOutdatedCallKeys);
        if (outdatedCallKeys.length === 0) return;
        const calls = outdatedCallKeys.map((key)=>(0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .parseCallKey */ .gl)(key));
        // .filter(item => item.address.toLowerCase() !== '0x5Fe5cC0122403f06abE2A75DBba1860Edb762985'.toLowerCase())
        const chunkedCalls = (0,_utils_chunkArray__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(calls, CALL_CHUNK_SIZE);
        if (cancellations.current?.blockNumber !== latestBlockNumber) {
            cancellations.current?.cancellations?.forEach((c)=>c());
        }
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .fetchingMulticallResults */ .nu)({
            calls,
            chainId,
            fetchingBlockNumber: latestBlockNumber
        }));
        cancellations.current = {
            blockNumber: latestBlockNumber,
            cancellations: chunkedCalls.map((chunk, index)=>{
                const { cancel , promise  } = (0,_utils_retry__WEBPACK_IMPORTED_MODULE_5__/* .retry */ .XD)(()=>fetchChunk(multicallContract, chunk, latestBlockNumber), {
                    n: Infinity,
                    minWait: 2500,
                    maxWait: 3500
                });
                promise.then(({ results: returnData , blockNumber: fetchBlockNumber  })=>{
                    cancellations.current = {
                        cancellations: [],
                        blockNumber: latestBlockNumber
                    };
                    // accumulates the length of all previous indices
                    const firstCallKeyIndex = chunkedCalls.slice(0, index).reduce((memo, curr)=>memo + curr.length, 0);
                    const lastCallKeyIndex = firstCallKeyIndex + returnData.length;
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateMulticallResults */ .zT)({
                        chainId,
                        results: outdatedCallKeys.slice(firstCallKeyIndex, lastCallKeyIndex).reduce((memo, callKey, i)=>{
                            memo[callKey] = returnData[i] ?? null;
                            return memo;
                        }, {}),
                        blockNumber: fetchBlockNumber
                    }));
                }).catch((error)=>{
                    if (error instanceof _utils_retry__WEBPACK_IMPORTED_MODULE_5__/* .CancelledError */ .p8) {
                        console.error("Cancelled fetch for blockNumber", latestBlockNumber);
                        return;
                    }
                    console.error("Failed to fetch multicall chunk", chunk, chainId, error);
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .errorFetchingMulticallResults */ .wC)({
                        calls: chunk,
                        chainId,
                        fetchingBlockNumber: latestBlockNumber
                    }));
                });
                return cancel;
            })
        };
    }, [
        chainId,
        multicallContract,
        dispatch,
        serializedOutdatedCallKeys,
        latestBlockNumber
    ]);
    return null;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8053:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Updater)
/* harmony export */ });
/* unused harmony export shouldCheck */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _application_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9348);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__, _application_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([_hooks__WEBPACK_IMPORTED_MODULE_2__, _application_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function shouldCheck(lastBlockNumber, tx) {
    if (tx.receipt) return false;
    if (!tx.lastCheckedBlockNumber) return true;
    const blocksSinceCheck = lastBlockNumber - tx.lastCheckedBlockNumber;
    if (blocksSinceCheck < 1) return false;
    const minutesPending = (new Date().getTime() - tx.addedTime) / 1000 / 60;
    if (minutesPending > 60) {
        // every 10 blocks if pending for longer than an hour
        return blocksSinceCheck > 9;
    }
    if (minutesPending > 5) {
        // every 3 blocks if pending more than 5 minutes
        return blocksSinceCheck > 2;
    }
    // otherwise every block
    return true;
}
function Updater() {
    const { chainId , library  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const lastBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useBlockNumber */ .Ov)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const state = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((s)=>s.transactions);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const transactions = chainId ? state[chainId] ?? {} : {};
    // show popup on confirm
    const addPopup = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useAddPopup */ .i$)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!chainId || !library || !lastBlockNumber) return;
        Object.keys(transactions).filter((hash)=>shouldCheck(lastBlockNumber, transactions[hash])).forEach((hash)=>{
            library.getTransactionReceipt(hash).then((receipt)=>{
                if (receipt) {
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .finalizeTransaction */ .Aw)({
                        chainId,
                        hash,
                        receipt: {
                            blockHash: receipt.blockHash,
                            blockNumber: receipt.blockNumber,
                            contractAddress: receipt.contractAddress,
                            from: receipt.from,
                            status: receipt.status,
                            to: receipt.to,
                            transactionHash: receipt.transactionHash,
                            transactionIndex: receipt.transactionIndex
                        }
                    }));
                    addPopup({
                        txn: {
                            hash,
                            success: receipt.status === 1,
                            summary: transactions[hash]?.summary
                        }
                    }, hash);
                } else {
                    dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .checkedTransaction */ .LN)({
                        chainId,
                        hash,
                        blockNumber: lastBlockNumber
                    }));
                }
            }).catch((error)=>{
                console.error(`failed to check transaction hash: ${hash}`, error);
            });
        });
    }, [
        chainId,
        library,
        transactions,
        lastBlockNumber,
        dispatch,
        addPopup
    ]);
    return null;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "s": () => (/* binding */ setNotification)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: {
        set: false,
        data: {}
    }
};
const notificationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "notification",
    initialState,
    reducers: {
        setNotification: (state, action)=>{
            state.value = action.payload;
        }
    }
});
const { setNotification  } = notificationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (notificationSlice.reducer);


/***/ }),

/***/ 159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ ThemeContextProvider)
/* harmony export */ });
/* unused harmony export ThemeContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);




const CACHE_KEY = "IS_DARK";
const ThemeContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({
    isDark: false,
    toggleTheme: ()=>null
});
const ThemeContextProvider = ({ children  })=>{
    const { 0: isDark , 1: setIsDark  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>{
        return false;
    });
    const toggleTheme = ()=>{
        setIsDark((prevState)=>{
            return !prevState;
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ThemeContext.Provider, {
        value: {
            isDark,
            toggleTheme
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components__WEBPACK_IMPORTED_MODULE_2__.ThemeProvider, {
            theme: isDark ? _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.dark : _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.light,
            children: children
        })
    });
};



/***/ }),

/***/ 7615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ chunkArray)
/* harmony export */ });
// chunks array into chunks of maximum size
// evenly distributes items among the chunks
function chunkArray(items, maxChunkSize) {
    if (maxChunkSize < 1) throw new Error("maxChunkSize must be gte 1");
    if (items.length <= maxChunkSize) return [
        items
    ];
    const numChunks = Math.ceil(items.length / maxChunkSize);
    const chunkSize = Math.ceil(items.length / numChunks);
    return Array.from(Array(numChunks).keys()).map((ix)=>items.slice(ix * chunkSize, ix * chunkSize + chunkSize));
};


/***/ }),

/***/ 6440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getLibrary)
/* harmony export */ });
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__);

function getLibrary(provider) {
    const library = new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_0__.Web3Provider(provider);
    library.pollingInterval = 15000;
    return library;
};


/***/ }),

/***/ 6190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "XD": () => (/* binding */ retry),
/* harmony export */   "p8": () => (/* binding */ CancelledError),
/* harmony export */   "s1": () => (/* binding */ RetryableError)
/* harmony export */ });
function wait(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
function waitRandom(min, max) {
    return wait(min + Math.round(Math.random() * Math.max(0, max - min)));
}
/**
 * This error is thrown if the function is cancelled before completing
 */ class CancelledError extends Error {
    constructor(){
        super("Cancelled");
    }
}
/**
 * Throw this error if the function should retry
 */ class RetryableError extends Error {
}
/**
 * Retries the function that returns the promise until the promise successfully resolves up to n retries
 * @param fn function to retry
 * @param n how many times to retry
 * @param minWait min wait between retries in ms
 * @param maxWait max wait between retries in ms
 */ function retry(fn, { n , minWait , maxWait  }) {
    let completed = false;
    let rejectCancelled;
    // eslint-disable-next-line no-async-promise-executor
    const promise = new Promise(async (resolve, reject)=>{
        rejectCancelled = reject;
        // eslint-disable-next-line no-constant-condition
        while(true){
            let result;
            try {
                result = await fn();
                if (!completed) {
                    resolve(result);
                    completed = true;
                }
                break;
            } catch (error) {
                if (completed) {
                    break;
                }
                if (n <= 0 || !(error instanceof RetryableError)) {
                    reject(error);
                    completed = true;
                    break;
                }
                n--;
            }
            await waitRandom(minWait, maxWait);
        }
    });
    return {
        promise,
        cancel: ()=>{
            if (completed) return;
            completed = true;
            rejectCancelled(new CancelledError());
        }
    };
}


/***/ }),

/***/ 8454:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 6187:
/***/ ((module) => {

module.exports = require("@ethersproject/abi");

/***/ }),

/***/ 1541:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 5757:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 6644:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 2792:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 7974:
/***/ ((module) => {

module.exports = require("@pancakeswap-libs/sdk");

/***/ }),

/***/ 3912:
/***/ ((module) => {

module.exports = require("@pancakeswap-libs/uikit");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1554:
/***/ ((module) => {

module.exports = require("@uniswap/token-lists");

/***/ }),

/***/ 3154:
/***/ ((module) => {

module.exports = require("@web3-react/abstract-connector");

/***/ }),

/***/ 8054:
/***/ ((module) => {

module.exports = require("@web3-react/core");

/***/ }),

/***/ 6590:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 9795:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 7738:
/***/ ((module) => {

module.exports = require("@web3-react/walletlink-connector");

/***/ }),

/***/ 5888:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 8729:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 2522:
/***/ ((module) => {

module.exports = require("ethers/lib/utils");

/***/ }),

/***/ 6677:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 3735:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 3599:
/***/ ((module) => {

module.exports = require("react-device-detect");

/***/ }),

/***/ 6921:
/***/ ((module) => {

module.exports = require("react-moralis");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 4281:
/***/ ((module) => {

module.exports = import("tiny-invariant");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1451,475,2021,1407,1238,4052,1134,9113,4380,9899], () => (__webpack_exec__(5656)));
module.exports = __webpack_exports__;

})();