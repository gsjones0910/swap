"use strict";
exports.id = 1238;
exports.ids = [1238];
exports.modules = {

/***/ 9397:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ NetworkConnector)
/* harmony export */ });
/* harmony import */ var _web3_react_abstract_connector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3154);
/* harmony import */ var _web3_react_abstract_connector__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web3_react_abstract_connector__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var tiny_invariant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4281);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([tiny_invariant__WEBPACK_IMPORTED_MODULE_1__]);
tiny_invariant__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


class RequestError extends Error {
    constructor(message, code, data){
        super(message);
        this.code = code;
        this.data = data;
    }
}
class MiniRpcProvider {
    isMetaMask = false;
    nextId = 1;
    batchTimeoutId = null;
    batch = [];
    constructor(chainId, url, batchWaitTimeMs){
        this.chainId = chainId;
        this.url = url;
        const parsed = new URL(url);
        this.host = parsed.host;
        this.path = parsed.pathname;
        // how long to wait to batch calls
        this.batchWaitTimeMs = batchWaitTimeMs ?? 50;
    }
    clearBatch = async ()=>{
        console.info("Clearing batch", this.batch);
        const { batch  } = this;
        this.batch = [];
        this.batchTimeoutId = null;
        let response;
        try {
            response = await fetch(this.url, {
                method: "POST",
                headers: {
                    "content-type": "application/json",
                    accept: "application/json"
                },
                body: JSON.stringify(batch.map((item)=>item.request))
            });
        } catch (error) {
            batch.forEach(({ reject  })=>reject(new Error("Failed to send batch call")));
            return;
        }
        if (!response.ok) {
            batch.forEach(({ reject  })=>reject(new RequestError(`${response.status}: ${response.statusText}`, -32000)));
            return;
        }
        let json;
        try {
            json = await response.json();
        } catch (error1) {
            batch.forEach(({ reject  })=>reject(new Error("Failed to parse JSON response")));
            return;
        }
        const byKey = batch.reduce((memo, current)=>{
            memo[current.request.id] = current;
            return memo;
        }, {});
        // eslint-disable-next-line no-restricted-syntax
        for (const result of json){
            const { resolve , reject , request: { method  } ,  } = byKey[result.id];
            if (resolve && reject) {
                if ("error" in result) {
                    reject(new RequestError(result?.error?.message, result?.error?.code, result?.error?.data));
                } else if ("result" in result) {
                    resolve(result.result);
                } else {
                    reject(new RequestError(`Received unexpected JSON-RPC response to ${method} request.`, -32000, result));
                }
            }
        }
    };
    sendAsync = (request, callback)=>{
        this.request(request.method, request.params).then((result)=>callback(null, {
                jsonrpc: "2.0",
                id: request.id,
                result
            })).catch((error)=>callback(error, null));
    };
    request = async (method, params)=>{
        if (typeof method !== "string") {
            return this.request(method.method, method.params);
        }
        if (method === "eth_chainId") {
            return `0x${this.chainId.toString(16)}`;
        }
        const promise = new Promise((resolve, reject)=>{
            this.batch.push({
                request: {
                    jsonrpc: "2.0",
                    id: this.nextId++,
                    method,
                    params
                },
                resolve,
                reject
            });
        });
        this.batchTimeoutId = this.batchTimeoutId ?? setTimeout(this.clearBatch, this.batchWaitTimeMs);
        return promise;
    };
}
class NetworkConnector extends _web3_react_abstract_connector__WEBPACK_IMPORTED_MODULE_0__.AbstractConnector {
    constructor({ urls , defaultChainId  }){
        (0,tiny_invariant__WEBPACK_IMPORTED_MODULE_1__["default"])(defaultChainId || Object.keys(urls).length === 1, "defaultChainId is a required argument with >1 url");
        super({
            supportedChainIds: Object.keys(urls).map((k)=>Number(k))
        });
        this.currentChainId = defaultChainId || Number(Object.keys(urls)[0]);
        this.providers = Object.keys(urls).reduce((accumulator, chainId)=>{
            accumulator[Number(chainId)] = new MiniRpcProvider(Number(chainId), urls[Number(chainId)]);
            return accumulator;
        }, {});
    }
    get provider() {
        return this.providers[this.currentChainId];
    }
    async activate() {
        return {
            provider: this.providers[this.currentChainId],
            chainId: this.currentChainId,
            account: null
        };
    }
    async getProvider() {
        return this.providers[this.currentChainId];
    }
    async getChainId() {
        return this.currentChainId;
    }
    async getAccount() {
        return null;
    }
    deactivate() {
        return null;
    }
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (NetworkConnector)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BA": () => (/* binding */ connectorsByName),
/* harmony export */   "K4": () => (/* binding */ NETWORK_CHAIN_ID),
/* harmony export */   "L5": () => (/* binding */ network),
/* harmony export */   "Lj": () => (/* binding */ injected),
/* harmony export */   "nM": () => (/* binding */ getNetworkLibrary)
/* harmony export */ });
/* unused harmony exports bscConnector, walletconnect, walletlink */
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6590);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9795);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _web3_react_walletlink_connector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7738);
/* harmony import */ var _web3_react_walletlink_connector__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_walletlink_connector__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8454);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _NetworkConnector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9397);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_NetworkConnector__WEBPACK_IMPORTED_MODULE_6__]);
_NetworkConnector__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const NETWORK_URL = "https://data-seed-prebsc-1-s1.binance.org:8545";
const NETWORK_CHAIN_ID = parseInt("0x61" ?? 0);
if (typeof NETWORK_URL === "undefined") {
    throw new Error(`NEXT_PUBLIC_NETWORK_URL must be a defined environment variable`);
}
const network = new _NetworkConnector__WEBPACK_IMPORTED_MODULE_6__/* .NetworkConnector */ .S({
    urls: {
        [NETWORK_CHAIN_ID]: NETWORK_URL
    }
});
let networkLibrary;
function getNetworkLibrary() {
    // eslint-disable-next-line no-return-assign
    return networkLibrary = networkLibrary ?? new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_1__.Web3Provider(network.provider);
}
const injected = new _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__.InjectedConnector({
    supportedChainIds: [
        97
    ]
});
const bscConnector = new _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_5__.BscConnector({
    supportedChainIds: [
        97
    ]
});
// mainnet only
const walletconnect = new _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_3__.WalletConnectConnector({
    rpc: {
        [NETWORK_CHAIN_ID]: NETWORK_URL
    },
    bridge: "https://bridge.walletconnect.org",
    qrcode: true,
    pollingInterval: 15000
});
// mainnet only
const walletlink = new _web3_react_walletlink_connector__WEBPACK_IMPORTED_MODULE_4__.WalletLinkConnector({
    url: NETWORK_URL,
    appName: "Uniswap",
    appLogoUrl: "https://mpng.pngfly.com/20181202/bex/kisspng-emoji-domain-unicorn-pin-badges-sticker-unicorn-tumblr-emoji-unicorn-iphoneemoji-5c046729264a77.5671679315437924251569.jpg"
});
const connectorsByName = {
    [_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__.ConnectorNames.Injected]: injected,
    [_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__.ConnectorNames.WalletConnect]: walletconnect,
    [_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__.ConnectorNames.BSC]: bscConnector
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Jz": () => (/* reexport */ erc20_bytes32_namespaceObject),
  "ZP": () => (/* binding */ abis_erc20)
});

// UNUSED EXPORTS: ERC20_ABI

// EXTERNAL MODULE: external "@ethersproject/abi"
var abi_ = __webpack_require__(6187);
// EXTERNAL MODULE: ./constants/abis/erc20.json
var erc20 = __webpack_require__(9422);
;// CONCATENATED MODULE: ./constants/abis/erc20_bytes32.json
const erc20_bytes32_namespaceObject = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./constants/abis/erc20.ts



const ERC20_INTERFACE = new abi_.Interface(erc20);
/* harmony default export */ const abis_erc20 = (ERC20_INTERFACE);



/***/ }),

/***/ 6451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ multicall)
});

// EXTERNAL MODULE: external "@pancakeswap-libs/sdk"
var sdk_ = __webpack_require__(7974);
;// CONCATENATED MODULE: ./constants/multicall/abi.json
const abi_namespaceObject = JSON.parse('[{"constant":true,"inputs":[],"name":"getCurrentBlockTimestamp","outputs":[{"name":"timestamp","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"components":[{"name":"target","type":"address"},{"name":"callData","type":"bytes"}],"name":"calls","type":"tuple[]"}],"name":"aggregate","outputs":[{"name":"blockNumber","type":"uint256"},{"name":"returnData","type":"bytes[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getLastBlockHash","outputs":[{"name":"blockHash","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"addr","type":"address"}],"name":"getEthBalance","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getCurrentBlockDifficulty","outputs":[{"name":"difficulty","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getCurrentBlockGasLimit","outputs":[{"name":"gaslimit","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getCurrentBlockCoinbase","outputs":[{"name":"coinbase","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"blockNumber","type":"uint256"}],"name":"getBlockHash","outputs":[{"name":"blockHash","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"}]');
;// CONCATENATED MODULE: ./constants/multicall/index.ts


const MULTICALL_NETWORKS = {
    [sdk_.ChainId.MAINNET]: "0x1Ee38d535d541c55C9dae27B12edf090C608E6Fb",
    [sdk_.ChainId.BSCTESTNET]: "0x301907b5835a2d723Fe3e9E8C5Bc5375d5c1236A"
};
/* harmony default export */ const multicall = ({
    MULTICALL_ABI: abi_namespaceObject,
    MULTICALL_NETWORKS
});


/***/ }),

/***/ 5820:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "aQ": () => (/* binding */ useActiveWeb3React),
/* harmony export */   "fJ": () => (/* binding */ useInactiveListener),
/* harmony export */   "yW": () => (/* binding */ useEagerConnect)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3599);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_device_detect__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _connectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3966);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1407);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_connectors__WEBPACK_IMPORTED_MODULE_4__]);
_connectors__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function useActiveWeb3React() {
    const context = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const contextNetwork = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)(_constants__WEBPACK_IMPORTED_MODULE_5__/* .NetworkContextName */ .AQ);
    return context.active ? context : contextNetwork;
}
function useEagerConnect() {
    const { activate , active  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)(); // specifically using useWeb3ReactCore because of what this hook does
    const { 0: tried , 1: setTried  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const wa = window;
        const { ethereum  } = wa;
        _connectors__WEBPACK_IMPORTED_MODULE_4__/* .injected.isAuthorized */ .Lj.isAuthorized().then((isAuthorized)=>{
            const hasSignedIn = window.localStorage.getItem(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_0__.connectorLocalStorageKey);
            if (isAuthorized && hasSignedIn) {
                activate(_connectors__WEBPACK_IMPORTED_MODULE_4__/* .injected */ .Lj, undefined, true).catch(()=>{
                    setTried(true);
                });
            } else if (react_device_detect__WEBPACK_IMPORTED_MODULE_3__.isMobile && ethereum && hasSignedIn) {
                activate(_connectors__WEBPACK_IMPORTED_MODULE_4__/* .injected */ .Lj, undefined, true).catch(()=>{
                    setTried(true);
                });
            } else {
                setTried(true);
            }
        });
    }, [
        activate
    ]); // intentionally only running on mount (make sure it's only mounted once :))
    // if the connection worked, wait until we get confirmation of that to flip the flag
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (active) {
            setTried(true);
        }
    }, [
        active
    ]);
    return tried;
}
/**
 * Use for network and injected - logs user in
 * and out after checking what network theyre on
 */ function useInactiveListener(suppress = false) {
    const { active , error , activate  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)(); // specifically using useWeb3React because of what this hook does
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const wa = window;
        const { ethereum  } = wa;
        if (ethereum && ethereum.on && !active && !error && !suppress) {
            const handleChainChanged = ()=>{
                // eat errors
                activate(_connectors__WEBPACK_IMPORTED_MODULE_4__/* .injected */ .Lj, undefined, true).catch((e)=>{
                    console.error("Failed to activate after chain changed", e);
                });
            };
            const handleAccountsChanged = (accounts)=>{
                if (accounts.length > 0) {
                    // eat errors
                    activate(_connectors__WEBPACK_IMPORTED_MODULE_4__/* .injected */ .Lj, undefined, true).catch((e)=>{
                        console.error("Failed to activate after accounts changed", e);
                    });
                }
            };
            ethereum.on("chainChanged", handleChainChanged);
            ethereum.on("accountsChanged", handleAccountsChanged);
            return ()=>{
                if (ethereum.removeListener) {
                    ethereum.removeListener("chainChanged", handleChainChanged);
                    ethereum.removeListener("accountsChanged", handleAccountsChanged);
                }
            };
        }
        return undefined;
    }, [
        active,
        error,
        suppress,
        activate
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5307:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hj": () => (/* binding */ useWETHContract),
/* harmony export */   "Ib": () => (/* binding */ useTokenContract),
/* harmony export */   "gq": () => (/* binding */ useMulticallContract),
/* harmony export */   "gs": () => (/* binding */ useBytes32TokenContract),
/* harmony export */   "t0": () => (/* binding */ usePairContract),
/* harmony export */   "uU": () => (/* binding */ useENSResolverContract),
/* harmony export */   "zb": () => (/* binding */ useENSRegistrarContract)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _uniswap_v2_core_build_IUniswapV2Pair_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6912);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants_abis_ens_registrar_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1561);
/* harmony import */ var _constants_abis_ens_public_resolver_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(892);
/* harmony import */ var _constants_abis_erc20__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7502);
/* harmony import */ var _constants_abis_erc20_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9422);
/* harmony import */ var _constants_abis_weth_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2253);
/* harmony import */ var _constants_multicall__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6451);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8847);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_index__WEBPACK_IMPORTED_MODULE_10__]);
_index__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











// returns null on errors
function useContract(address, ABI, withSignerIfPossible = true) {
    const { library , account  } = (0,_index__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!address || !ABI || !library) return null;
        try {
            return (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .getContract */ .uN)(address, ABI, library, withSignerIfPossible && account ? account : undefined);
        } catch (error) {
            console.error("Failed to get contract", error);
            return null;
        }
    }, [
        address,
        ABI,
        library,
        withSignerIfPossible,
        account
    ]);
}
function useTokenContract(tokenAddress, withSignerIfPossible) {
    return useContract(tokenAddress, _constants_abis_erc20_json__WEBPACK_IMPORTED_MODULE_6__, withSignerIfPossible);
}
function useWETHContract(withSignerIfPossible) {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    return useContract(chainId ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[chainId].address : undefined, _constants_abis_weth_json__WEBPACK_IMPORTED_MODULE_7__, withSignerIfPossible);
}
function useENSRegistrarContract(withSignerIfPossible) {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    let address;
    if (chainId) {
        switch(chainId){
            case _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET:
            case _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET:
        }
    }
    return useContract(address, _constants_abis_ens_registrar_json__WEBPACK_IMPORTED_MODULE_3__, withSignerIfPossible);
}
function useENSResolverContract(address, withSignerIfPossible) {
    return useContract(address, _constants_abis_ens_public_resolver_json__WEBPACK_IMPORTED_MODULE_4__, withSignerIfPossible);
}
function useBytes32TokenContract(tokenAddress, withSignerIfPossible) {
    return useContract(tokenAddress, _constants_abis_erc20__WEBPACK_IMPORTED_MODULE_5__/* .ERC20_BYTES32_ABI */ .Jz, withSignerIfPossible);
}
function usePairContract(pairAddress, withSignerIfPossible) {
    return useContract(pairAddress, _uniswap_v2_core_build_IUniswapV2Pair_json__WEBPACK_IMPORTED_MODULE_1__/* .abi */ .Mt, withSignerIfPossible);
}
function useMulticallContract() {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    return useContract(chainId && _constants_multicall__WEBPACK_IMPORTED_MODULE_8__/* ["default"].MULTICALL_NETWORKS */ .Z.MULTICALL_NETWORKS[chainId], _constants_multicall__WEBPACK_IMPORTED_MODULE_8__/* ["default"].MULTICALL_ABI */ .Z.MULTICALL_ABI, false);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pd": () => (/* binding */ toggleWalletModal),
/* harmony export */   "fG": () => (/* binding */ updateBlockNumber),
/* harmony export */   "hC": () => (/* binding */ removePopup),
/* harmony export */   "i8": () => (/* binding */ addPopup),
/* harmony export */   "mm": () => (/* binding */ toggleSettingsMenu)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const updateBlockNumber = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("app/updateBlockNumber");
const toggleWalletModal = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("app/toggleWalletModal");
const toggleSettingsMenu = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("app/toggleSettingsMenu");
const addPopup = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("app/addPopup");
const removePopup = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("app/removePopup");


/***/ }),

/***/ 9348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ov": () => (/* binding */ useBlockNumber),
/* harmony export */   "i$": () => (/* binding */ useAddPopup)
/* harmony export */ });
/* unused harmony exports useWalletModalOpen, useWalletModalToggle, useSettingsMenuOpen, useToggleSettingsMenu, useRemovePopup, useActivePopups */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8887);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__]);
_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function useBlockNumber() {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.application.blockNumber[chainId ?? -1]);
}
function useWalletModalOpen() {
    return useSelector((state)=>state.application.walletModalOpen);
}
function useWalletModalToggle() {
    const dispatch = useDispatch();
    return useCallback(()=>dispatch(toggleWalletModal()), [
        dispatch
    ]);
}
function useSettingsMenuOpen() {
    return useSelector((state)=>state.application.settingsMenuOpen);
}
function useToggleSettingsMenu() {
    const dispatch = useDispatch();
    return useCallback(()=>dispatch(toggleSettingsMenu()), [
        dispatch
    ]);
}
// returns a function that allows adding a popup
function useAddPopup() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((content, key)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_3__/* .addPopup */ .i8)({
            content,
            key
        }));
    }, [
        dispatch
    ]);
}
// returns a function that allows removing a popup via its key
function useRemovePopup() {
    const dispatch = useDispatch();
    return useCallback((key)=>{
        dispatch(removePopup({
            key
        }));
    }, [
        dispatch
    ]);
}
// get the list of active popups
function useActivePopups() {
    const list = useSelector((state)=>state.application.popupList);
    return useMemo(()=>list.filter((item)=>item.show), [
        list
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$x": () => (/* binding */ removeMulticallListeners),
/* harmony export */   "Dd": () => (/* binding */ addMulticallListeners),
/* harmony export */   "gl": () => (/* binding */ parseCallKey),
/* harmony export */   "kG": () => (/* binding */ toCallKey),
/* harmony export */   "nu": () => (/* binding */ fetchingMulticallResults),
/* harmony export */   "wC": () => (/* binding */ errorFetchingMulticallResults),
/* harmony export */   "zT": () => (/* binding */ updateMulticallResults)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const ADDRESS_REGEX = /^0x[a-fA-F0-9]{40}$/;
const LOWER_HEX_REGEX = /^0x[a-f0-9]*$/;
function toCallKey(call) {
    if (!ADDRESS_REGEX.test(call.address)) {
        throw new Error(`Invalid address: ${call.address}`);
    }
    if (!LOWER_HEX_REGEX.test(call.callData)) {
        throw new Error(`Invalid hex: ${call.callData}`);
    }
    return `${call.address}-${call.callData}`;
}
function parseCallKey(callKey) {
    const pcs = callKey.split("-");
    if (pcs.length !== 2) {
        throw new Error(`Invalid call key: ${callKey}`);
    }
    return {
        address: pcs[0],
        callData: pcs[1]
    };
}
const addMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("multicall/addMulticallListeners");
const removeMulticallListeners = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("multicall/removeMulticallListeners");
const fetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("multicall/fetchingMulticallResults");
const errorFetchingMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("multicall/errorFetchingMulticallResults");
const updateMulticallResults = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("multicall/updateMulticallResults");


/***/ }),

/***/ 8847:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P4": () => (/* binding */ basisPointsToPercent),
/* harmony export */   "UJ": () => (/* binding */ isAddress),
/* harmony export */   "Xn": () => (/* binding */ shortenAddress),
/* harmony export */   "hr": () => (/* binding */ escapeRegExp),
/* harmony export */   "iY": () => (/* binding */ getRouterContract),
/* harmony export */   "s6": () => (/* binding */ getBscScanLink),
/* harmony export */   "uN": () => (/* binding */ getContract),
/* harmony export */   "uc": () => (/* binding */ calculateSlippageAmount),
/* harmony export */   "wK": () => (/* binding */ isTokenOnList),
/* harmony export */   "yC": () => (/* binding */ calculateGasMargin)
/* harmony export */ });
/* unused harmony exports getSigner, getProviderOrSigner */
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2792);
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1541);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_address__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _uniswap_v2_periphery_build_IUniswapV2Router02_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4420);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1407);







// returns the checksummed address if the address is valid, otherwise returns false
function isAddress(value) {
    try {
        return (0,_ethersproject_address__WEBPACK_IMPORTED_MODULE_1__.getAddress)(value);
    } catch  {
        return false;
    }
}
const BSCSCAN_PREFIXES = {
    56: "",
    97: "testnet."
};
function getBscScanLink(chainId, data, type) {
    const prefix = `https://${BSCSCAN_PREFIXES[chainId] || BSCSCAN_PREFIXES[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.ChainId.MAINNET]}bscscan.com`;
    switch(type){
        case "transaction":
            {
                return `${prefix}/tx/${data}`;
            }
        case "token":
            {
                return `${prefix}/token/${data}`;
            }
        case "address":
        default:
            {
                return `${prefix}/address/${data}`;
            }
    }
}
// shorten the checksummed version of the input address to have 0x + 4 characters at start and end
function shortenAddress(address, chars = 4) {
    const parsed = isAddress(address);
    if (!parsed) {
        throw Error(`Invalid 'address' parameter '${address}'.`);
    }
    return `${parsed.substring(0, chars + 2)}...${parsed.substring(42 - chars)}`;
}
// add 10%
function calculateGasMargin(value) {
    return value.mul(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(10000).add(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(1000))).div(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(10000));
}
// converts a basis points value to a sdk percent
function basisPointsToPercent(num) {
    return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(Math.floor(num)), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10000));
}
function calculateSlippageAmount(value, slippage) {
    if (slippage < 0 || slippage > 10000) {
        throw Error(`Unexpected slippage value: ${slippage}`);
    }
    return [
        _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.divide(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.multiply(value.raw, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10000 - slippage)), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10000)),
        _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.divide(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.multiply(value.raw, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10000 + slippage)), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10000)), 
    ];
}
// account is not optional
function getSigner(library, account) {
    return library.getSigner(account).connectUnchecked();
}
// account is optional
function getProviderOrSigner(library, account) {
    return account ? getSigner(library, account) : library;
}
// account is optional
function getContract(address, ABI, library, account) {
    if (!isAddress(address) || address === _ethersproject_constants__WEBPACK_IMPORTED_MODULE_2__.AddressZero) {
        throw Error(`Invalid 'address' parameter '${address}'.`);
    }
    return new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__.Contract(address, ABI, getProviderOrSigner(library, account));
}
// account is optional
function getRouterContract(_, library, account) {
    return getContract(_constants__WEBPACK_IMPORTED_MODULE_6__/* .ROUTER_ADDRESS */ .bR, _uniswap_v2_periphery_build_IUniswapV2Router02_json__WEBPACK_IMPORTED_MODULE_4__/* .abi */ .Mt, library, account);
}
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& means the whole matched string
}
function isTokenOnList(defaultTokens, currency) {
    if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.ETHER) return true;
    return Boolean(currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_5__.Token && defaultTokens[currency.chainId]?.[currency.address]);
}


/***/ }),

/***/ 892:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[{"internalType":"contract ENS","name":"_ens","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"uint256","name":"contentType","type":"uint256"}],"name":"ABIChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"a","type":"address"}],"name":"AddrChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"uint256","name":"coinType","type":"uint256"},{"indexed":false,"internalType":"bytes","name":"newAddress","type":"bytes"}],"name":"AddressChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"target","type":"address"},{"indexed":false,"internalType":"bool","name":"isAuthorised","type":"bool"}],"name":"AuthorisationChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"hash","type":"bytes"}],"name":"ContenthashChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"name","type":"bytes"},{"indexed":false,"internalType":"uint16","name":"resource","type":"uint16"},{"indexed":false,"internalType":"bytes","name":"record","type":"bytes"}],"name":"DNSRecordChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes","name":"name","type":"bytes"},{"indexed":false,"internalType":"uint16","name":"resource","type":"uint16"}],"name":"DNSRecordDeleted","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"DNSZoneCleared","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"bytes4","name":"interfaceID","type":"bytes4"},{"indexed":false,"internalType":"address","name":"implementer","type":"address"}],"name":"InterfaceChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"string","name":"name","type":"string"}],"name":"NameChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"bytes32","name":"x","type":"bytes32"},{"indexed":false,"internalType":"bytes32","name":"y","type":"bytes32"}],"name":"PubkeyChanged","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"string","name":"indexedKey","type":"string"},{"indexed":false,"internalType":"string","name":"key","type":"string"}],"name":"TextChanged","type":"event"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"contentTypes","type":"uint256"}],"name":"ABI","outputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"addr","outputs":[{"internalType":"address payable","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"","type":"bytes32"},{"internalType":"address","name":"","type":"address"},{"internalType":"address","name":"","type":"address"}],"name":"authorisations","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"clearDNSZone","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"contenthash","outputs":[{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"name","type":"bytes32"},{"internalType":"uint16","name":"resource","type":"uint16"}],"name":"dnsRecord","outputs":[{"internalType":"bytes","name":"","type":"bytes"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"name","type":"bytes32"}],"name":"hasDNSRecords","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes4","name":"interfaceID","type":"bytes4"}],"name":"interfaceImplementer","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"pubkey","outputs":[{"internalType":"bytes32","name":"x","type":"bytes32"},{"internalType":"bytes32","name":"y","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"contentType","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"setABI","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint256","name":"coinType","type":"uint256"},{"internalType":"bytes","name":"a","type":"bytes"}],"name":"setAddr","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"a","type":"address"}],"name":"setAddr","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"target","type":"address"},{"internalType":"bool","name":"isAuthorised","type":"bool"}],"name":"setAuthorisation","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes","name":"hash","type":"bytes"}],"name":"setContenthash","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"setDNSRecords","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes4","name":"interfaceID","type":"bytes4"},{"internalType":"address","name":"implementer","type":"address"}],"name":"setInterface","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"name","type":"string"}],"name":"setName","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"x","type":"bytes32"},{"internalType":"bytes32","name":"y","type":"bytes32"}],"name":"setPubkey","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"key","type":"string"},{"internalType":"string","name":"value","type":"string"}],"name":"setText","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes4","name":"interfaceID","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"pure","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"string","name":"key","type":"string"}],"name":"text","outputs":[{"internalType":"string","name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"}]');

/***/ }),

/***/ 1561:
/***/ ((module) => {

module.exports = JSON.parse('[{"inputs":[{"internalType":"contract ENS","name":"_old","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":true,"internalType":"bytes32","name":"label","type":"bytes32"},{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"NewOwner","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"resolver","type":"address"}],"name":"NewResolver","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"NewTTL","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"bytes32","name":"node","type":"bytes32"},{"indexed":false,"internalType":"address","name":"owner","type":"address"}],"name":"Transfer","type":"event"},{"constant":true,"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"old","outputs":[{"internalType":"contract ENS","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"recordExists","outputs":[{"internalType":"bool","name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"resolver","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"}],"name":"setOwner","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"resolver","type":"address"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setRecord","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"address","name":"resolver","type":"address"}],"name":"setResolver","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"label","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"}],"name":"setSubnodeOwner","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"bytes32","name":"label","type":"bytes32"},{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"resolver","type":"address"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setSubnodeRecord","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"},{"internalType":"uint64","name":"ttl","type":"uint64"}],"name":"setTTL","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"internalType":"bytes32","name":"node","type":"bytes32"}],"name":"ttl","outputs":[{"internalType":"uint64","name":"","type":"uint64"}],"payable":false,"stateMutability":"view","type":"function"}]');

/***/ }),

/***/ 9422:
/***/ ((module) => {

module.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]');

/***/ }),

/***/ 2253:
/***/ ((module) => {

module.exports = JSON.parse('[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"guy","type":"address"},{"name":"wad","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"src","type":"address"},{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"wad","type":"uint256"}],"name":"withdraw","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"dst","type":"address"},{"name":"wad","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"deposit","outputs":[],"payable":true,"stateMutability":"payable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"guy","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"dst","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Deposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"src","type":"address"},{"indexed":false,"name":"wad","type":"uint256"}],"name":"Withdrawal","type":"event"}]');

/***/ })

};
;