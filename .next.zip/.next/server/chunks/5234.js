"use strict";
exports.id = 5234;
exports.ids = [5234];
exports.modules = {

/***/ 9794:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ FullPositionCard)
/* harmony export */ });
/* unused harmony exports FixedHeightRow, HoverCard, MinimalPositionCard */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2042);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(polished__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _data_TotalSupply__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6070);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5820);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1023);
/* harmony import */ var _utils_currencyId__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5450);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5354);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2882);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(247);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(817);
/* harmony import */ var _DoubleLogo__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3976);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(108);
/* harmony import */ var _swap_styleds__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5430);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_TotalSupply__WEBPACK_IMPORTED_MODULE_8__, _hooks__WEBPACK_IMPORTED_MODULE_9__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_10__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_15__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_16__]);
([_data_TotalSupply__WEBPACK_IMPORTED_MODULE_8__, _hooks__WEBPACK_IMPORTED_MODULE_9__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_10__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_15__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const FixedHeightRow = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowBetween */ .m0).withConfig({
    componentId: "sc-8d3452cb-0"
})`
  height: 24px;
`;
const HoverCard = styled_components__WEBPACK_IMPORTED_MODULE_7___default()(_Card__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP).withConfig({
    componentId: "sc-8d3452cb-1"
})`
  border: 1px solid ${({ theme  })=>theme.colors.invertedContrast};
  :hover {
    border: 1px solid ${({ theme  })=>(0,polished__WEBPACK_IMPORTED_MODULE_4__.darken)(0.06, theme.colors.invertedContrast)};
  }
`;
function MinimalPositionCard({ pair , showUnwrapped =false  }) {
    const { account  } = useActiveWeb3React();
    const currency0 = showUnwrapped ? pair.token0 : unwrappedToken(pair.token0);
    const currency1 = showUnwrapped ? pair.token1 : unwrappedToken(pair.token1);
    const { 0: showMore , 1: setShowMore  } = useState(false);
    const userPoolBalance = useTokenBalance(account ?? undefined, pair.liquidityToken);
    const totalPoolTokens = useTotalSupply(pair.liquidityToken);
    const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? [
        pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false),
        pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false), 
    ] : [
        undefined,
        undefined
    ];
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: userPoolBalance && /*#__PURE__*/ _jsx(UIKitCard, {
            children: /*#__PURE__*/ _jsx(CardBody, {
                children: /*#__PURE__*/ _jsxs(AutoColumn, {
                    gap: "12px",
                    children: [
                        /*#__PURE__*/ _jsx(FixedHeightRow, {
                            children: /*#__PURE__*/ _jsx(RowFixed, {
                                children: /*#__PURE__*/ _jsx(Text, {
                                    style: {
                                        textTransform: "uppercase",
                                        fontWeight: 600
                                    },
                                    fontSize: "14px",
                                    color: "textSubtle",
                                    children: "LP Tokens in your Wallet"
                                })
                            })
                        }),
                        /*#__PURE__*/ _jsxs(FixedHeightRow, {
                            onClick: ()=>setShowMore(!showMore),
                            children: [
                                /*#__PURE__*/ _jsxs(RowFixed, {
                                    children: [
                                        /*#__PURE__*/ _jsx(DoubleCurrencyLogo, {
                                            currency0: currency0,
                                            currency1: currency1,
                                            margin: true,
                                            size: 20
                                        }),
                                        /*#__PURE__*/ _jsxs(Text, {
                                            fontSize: "14px",
                                            children: [
                                                currency0.symbol,
                                                "/",
                                                currency1.symbol
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsx(RowFixed, {
                                    children: /*#__PURE__*/ _jsx(Text, {
                                        fontSize: "14px",
                                        children: userPoolBalance ? userPoolBalance.toSignificant(4) : "-"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs(AutoColumn, {
                            gap: "4px",
                            children: [
                                /*#__PURE__*/ _jsxs(FixedHeightRow, {
                                    children: [
                                        /*#__PURE__*/ _jsxs(Text, {
                                            fontSize: "14px",
                                            children: [
                                                currency0.symbol,
                                                ":"
                                            ]
                                        }),
                                        token0Deposited ? /*#__PURE__*/ _jsx(RowFixed, {
                                            children: /*#__PURE__*/ _jsx(Text, {
                                                ml: "6px",
                                                fontSize: "14px",
                                                children: token0Deposited?.toSignificant(6)
                                            })
                                        }) : "-"
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs(FixedHeightRow, {
                                    children: [
                                        /*#__PURE__*/ _jsxs(Text, {
                                            fontSize: "14px",
                                            children: [
                                                currency1.symbol,
                                                ":"
                                            ]
                                        }),
                                        token1Deposited ? /*#__PURE__*/ _jsx(RowFixed, {
                                            children: /*#__PURE__*/ _jsx(Text, {
                                                ml: "6px",
                                                fontSize: "14px",
                                                children: token1Deposited?.toSignificant(6)
                                            })
                                        }) : "-"
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}
function FullPositionCard({ pair  }) {
    const { account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .aQ)();
    const currency0 = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_12__/* .unwrappedToken */ .Bv)(pair.token0);
    const currency1 = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_12__/* .unwrappedToken */ .Bv)(pair.token1);
    const { 0: showMore , 1: setShowMore  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const userPoolBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useTokenBalance */ .mM)(account ?? undefined, pair.liquidityToken);
    const totalPoolTokens = (0,_data_TotalSupply__WEBPACK_IMPORTED_MODULE_8__/* .useTotalSupply */ .A)(pair.liquidityToken);
    const poolTokenPercentage = !!userPoolBalance && !!totalPoolTokens && _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2__.Percent(userPoolBalance.raw, totalPoolTokens.raw) : undefined;
    const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
    _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_2__.JSBI.greaterThanOrEqual(totalPoolTokens.raw, userPoolBalance.raw) ? [
        pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false),
        pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false), 
    ] : [
        undefined,
        undefined
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HoverCard, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_14__/* .AutoColumn */ .Tz, {
            gap: "12px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                    onClick: ()=>setShowMore(!showMore),
                    style: {
                        cursor: "pointer"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                            className: "gap-x-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: !currency0 || !currency1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_swap_styleds__WEBPACK_IMPORTED_MODULE_18__/* .Dots */ .bb, {
                                        children: "Loading"
                                    }) : `${currency0.symbol}/${currency1.symbol}`
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DoubleLogo__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                    currency0: currency0,
                                    currency1: currency1,
                                    size: 20
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                            children: showMore ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_5__.ChevronUp, {
                                size: "20",
                                style: {
                                    marginLeft: "10px"
                                }
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_5__.ChevronDown, {
                                size: "20",
                                style: {
                                    marginLeft: "10px"
                                }
                            })
                        })
                    ]
                }),
                showMore && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_14__/* .AutoColumn */ .Tz, {
                    gap: "8px",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        children: [
                                            "Pooled ",
                                            currency0.symbol,
                                            ":"
                                        ]
                                    })
                                }),
                                token0Deposited ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            ml: "6px",
                                            children: token0Deposited?.toSignificant(6)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            size: "20px",
                                            style: {
                                                marginLeft: "8px"
                                            },
                                            currency: currency0
                                        })
                                    ]
                                }) : "-"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        children: [
                                            "Pooled ",
                                            currency1.symbol,
                                            ":"
                                        ]
                                    })
                                }),
                                token1Deposited ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowFixed */ .DA, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                            ml: "6px",
                                            children: token1Deposited?.toSignificant(6)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            size: "20px",
                                            style: {
                                                marginLeft: "8px"
                                            },
                                            currency: currency1
                                        })
                                    ]
                                }) : "-"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: "Your pool tokens:"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: userPoolBalance ? userPoolBalance.toSignificant(4) : "-"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FixedHeightRow, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: "Your pool share:"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    children: poolTokenPercentage ? `${poolTokenPercentage.toFixed(2)}%` : "-"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_17__/* .RowBetween */ .m0, {
                            marginTop: "10px",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                    style: {
                                        width: "48%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: `/AddLiquidity/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_11__/* .currencyId */ .H)(currency0)}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_11__/* .currencyId */ .H)(currency1)}`,
                                        children: "Add"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                    style: {
                                        width: "48%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        href: `/RemoveLiquidity/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_11__/* .currencyId */ .H)(currency0)}/${(0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_11__/* .currencyId */ .H)(currency1)}`,
                                        children: "Remove"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useTotalSupply)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5307);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__]);
([_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// returns undefined if input token is undefined, or fails to get token contract,
// or contract total supply cannot be fetched
function useTotalSupply(token) {
    const contract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useTokenContract */ .Ib)(token?.address, false);
    const totalSupply = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(contract, "totalSupply")?.result?.[0];
    return token && totalSupply ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, totalSupply.toString()) : undefined;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useTotalSupply)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5234:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Pool)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_PositionCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9794);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1023);
/* harmony import */ var _components_Card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2882);
/* harmony import */ var _components_Row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(108);
/* harmony import */ var _components_Column__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(247);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5820);
/* harmony import */ var _data_Reserves__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4213);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1158);
/* harmony import */ var _components_swap_styleds__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5430);
/* harmony import */ var _components_PageHeader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7613);
/* harmony import */ var _AppBody__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4799);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_PositionCard__WEBPACK_IMPORTED_MODULE_5__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__, _hooks__WEBPACK_IMPORTED_MODULE_10__, _data_Reserves__WEBPACK_IMPORTED_MODULE_11__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_12__, _components_PageHeader__WEBPACK_IMPORTED_MODULE_14__]);
([_components_PositionCard__WEBPACK_IMPORTED_MODULE_5__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__, _hooks__WEBPACK_IMPORTED_MODULE_10__, _data_Reserves__WEBPACK_IMPORTED_MODULE_11__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_12__, _components_PageHeader__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const BUSDTokenAddress = "0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee";
const YLTTokenAddress = "0x275aF57B1Ff293684568d2FC1dCE04159F252D27";
function Pool() {
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(styled_components__WEBPACK_IMPORTED_MODULE_2__.ThemeContext);
    const { account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    // fetch the user's balances of all tracked V2 LP tokens
    const trackedTokenPairs = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useTrackedTokenPairs */ .B3)();
    const tokenPairsWithLiquidityTokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>trackedTokenPairs.map((tokens)=>({
                liquidityToken: (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_12__/* .toV2LiquidityToken */ .Ce)(tokens),
                tokens
            })), [
        trackedTokenPairs
    ]);
    const liquidityTokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>tokenPairsWithLiquidityTokens.map((tpwlt)=>tpwlt.liquidityToken), [
        tokenPairsWithLiquidityTokens, 
    ]);
    const [v2PairsBalances, fetchingV2PairBalances] = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTokenBalancesWithLoadingIndicator */ .v2)(account ?? undefined, liquidityTokens);
    // fetch the reserves for all V2 pools in which the user has a balance
    const liquidityTokensWithBalances = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>tokenPairsWithLiquidityTokens.filter(({ liquidityToken  })=>v2PairsBalances[liquidityToken.address]?.greaterThan("0")), [
        tokenPairsWithLiquidityTokens,
        v2PairsBalances
    ]);
    const v2Pairs = (0,_data_Reserves__WEBPACK_IMPORTED_MODULE_11__/* .usePairs */ .z$)(liquidityTokensWithBalances.map(({ tokens  })=>tokens));
    const v2IsLoading = fetchingV2PairBalances || v2Pairs?.length < liquidityTokensWithBalances.length || v2Pairs?.some((V2Pair)=>!V2Pair);
    const allV2PairsWithLiquidity = v2Pairs.map(([, pair])=>pair).filter((v2Pair)=>Boolean(v2Pair));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "px-2",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_AppBody__WEBPACK_IMPORTED_MODULE_15__["default"], {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PageHeader__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    title: "Liquidity",
                    description: "Add liquidity to receive LP tokens",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-[14px] mt-4 w-fit cursor-pointer",
                        id: "join-pool-button",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `AddLiquidity/${BUSDTokenAddress}/${YLTTokenAddress}`,
                            className: "text-white",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-white text-2xl rounded-lg bg-[#90E040] tracking-wider py-5 px-10",
                                children: "Add Liquidity"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                    className: "border-[3px] border-[#EBEBEB] w-full mt-[38px]"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                    gap: "lg",
                    justify: "center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.CardBody, {
                        style: {
                            width: "100%",
                            paddingLeft: 0,
                            paddingRight: 0
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_9__/* .AutoColumn */ .Tz, {
                            gap: "12px",
                            style: {
                                width: "100% !important"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Row__WEBPACK_IMPORTED_MODULE_8__/* .RowBetween */ .m0, {
                                    style: {
                                        paddingLeft: "30px",
                                        paddingRight: "30px"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "font-medium text-[14px]",
                                        children: "Your Liquidity"
                                    })
                                }),
                                !account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Card__WEBPACK_IMPORTED_MODULE_7__/* .LightCard */ .hl, {
                                    padding: "40px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textDisabled",
                                        textAlign: "center",
                                        children: "Connect to a wallet to view your liquidity."
                                    })
                                }) : v2IsLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Card__WEBPACK_IMPORTED_MODULE_7__/* .LightCard */ .hl, {
                                    padding: "40px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textDisabled",
                                        textAlign: "center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_swap_styleds__WEBPACK_IMPORTED_MODULE_13__/* .Dots */ .bb, {
                                            children: "Loading"
                                        })
                                    })
                                }) : allV2PairsWithLiquidity?.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: allV2PairsWithLiquidity.map((v2Pair)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PositionCard__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP, {
                                            pair: v2Pair
                                        }, v2Pair.liquidityToken.address))
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Card__WEBPACK_IMPORTED_MODULE_7__/* .LightCard */ .hl, {
                                    padding: "40px",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        color: "textDisabled",
                                        textAlign: "center",
                                        children: "No Liquiduty found"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ currencyId)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);

function currencyId(currency) {
    if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) return "BNB";
    if (currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token) return currency.address;
    throw new Error("invalid currency");
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (currencyId)));


/***/ })

};
;