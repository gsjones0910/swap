"use strict";
exports.id = 1407;
exports.ids = [1407];
exports.modules = {

/***/ 1407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AQ": () => (/* binding */ NetworkContextName),
/* harmony export */   "Bz": () => (/* binding */ ALLOWED_PRICE_IMPACT_LOW),
/* harmony export */   "EV": () => (/* binding */ PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN),
/* harmony export */   "HP": () => (/* binding */ MIN_ETH),
/* harmony export */   "IP": () => (/* binding */ CUSTOM_BASES),
/* harmony export */   "IS": () => (/* binding */ ONE_BIPS),
/* harmony export */   "PM": () => (/* binding */ BIPS_BASE),
/* harmony export */   "PY": () => (/* binding */ DEFAULT_DEADLINE_FROM_NOW),
/* harmony export */   "Q8": () => (/* binding */ PINNED_PAIRS),
/* harmony export */   "Uf": () => (/* binding */ ALLOWED_PRICE_IMPACT_HIGH),
/* harmony export */   "bR": () => (/* binding */ ROUTER_ADDRESS),
/* harmony export */   "gv": () => (/* binding */ INITIAL_ALLOWED_SLIPPAGE),
/* harmony export */   "kx": () => (/* binding */ SUGGESTED_BASES),
/* harmony export */   "lM": () => (/* binding */ BASES_TO_CHECK_TRADES_AGAINST),
/* harmony export */   "lN": () => (/* binding */ BLOCKED_PRICE_IMPACT_NON_EXPERT),
/* harmony export */   "p9": () => (/* binding */ ALLOWED_PRICE_IMPACT_MEDIUM),
/* harmony export */   "xu": () => (/* binding */ BASES_TO_TRACK_LIQUIDITY_FOR)
/* harmony export */ });
/* unused harmony exports CAKE, WBNB, BUSD, USDT, YLT */
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);

// export const ROUTER_ADDRESS = "0xDE2Db97D54a3c3B008a097B2260633E6cA7DB1AF";
const ROUTER_ADDRESS = "0x4939288787Fa692eD72f218330C988E98daD258d";
const CAKE = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, "0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82", 18, "CAKE", "PancakeSwap Token");
const WBNB = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET, "0x7Ba933056d8A09bFDcb8028334CbE710e9C34B72", 18, "WBNB", "Wrapped BNB");
const BUSD = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET, "0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee", 18, "BUSD", "Binance USD");
const USDT = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET, "0x337610d27c682E347C9cD60BD4b3b107C9d34dDd", 18, "USDT", "Tether USD");
const YLT = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(97, "0x275aF57B1Ff293684568d2FC1dCE04159F252D27", 18, "YLT", "YourLife Token");
const WETH_ONLY = {
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [
        _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]
    ],
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET]: [
        _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET]
    ]
};
// used to construct intermediary pairs for trading
const BASES_TO_CHECK_TRADES_AGAINST = {
    ...WETH_ONLY,
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [
        ...WETH_ONLY[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET],
        BUSD,
        USDT
    ]
};
/**
 * Some tokens can only be swapped via certain pairs, so we override the list of bases that are considered for these
 * tokens.
 */ const CUSTOM_BASES = {
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: {}
};
// used for display in the default list when adding liquidity
const SUGGESTED_BASES = {
    ...WETH_ONLY,
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [
        ...WETH_ONLY[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET],
        BUSD,
        USDT
    ]
};
// used to construct the list of all pairs we consider by default in the frontend
const BASES_TO_TRACK_LIQUIDITY_FOR = {
    ...WETH_ONLY,
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [
        ...WETH_ONLY[_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET],
        BUSD,
        USDT
    ]
};
const PINNED_PAIRS = {
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET]: [
        [
            BUSD,
            YLT
        ],
        [
            USDT,
            YLT
        ], 
    ]
};
const NetworkContextName = "NETWORK";
// default allowed slippage, in bips
const INITIAL_ALLOWED_SLIPPAGE = 80;
// 20 minutes, denominated in seconds
const DEFAULT_DEADLINE_FROM_NOW = 60 * 20;
// one basis point
const ONE_BIPS = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const BIPS_BASE = _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000);
// used for warning states
const ALLOWED_PRICE_IMPACT_LOW = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(100), BIPS_BASE); // 1%
const ALLOWED_PRICE_IMPACT_MEDIUM = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(300), BIPS_BASE); // 3%
const ALLOWED_PRICE_IMPACT_HIGH = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(500), BIPS_BASE); // 5%
// if the price slippage exceeds this number, force the user to type 'confirm' to execute
const PRICE_IMPACT_WITHOUT_FEE_CONFIRM_MIN = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1000), BIPS_BASE); // 10%
// for non expert mode disable swaps above this
const BLOCKED_PRICE_IMPACT_NON_EXPERT = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(1500), BIPS_BASE); // 15%
// used to ensure the user doesn't send so much ETH so they end up with <.01
const MIN_ETH = _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.exponentiate(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(16)); // .01 ETH


/***/ })

};
;