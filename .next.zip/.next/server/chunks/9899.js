"use strict";
exports.id = 9899;
exports.ids = [9899];
exports.modules = {

/***/ 7027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ DEFAULT_TOKEN_LIST_URL),
/* harmony export */   "L": () => (/* binding */ DEFAULT_LIST_OF_LISTS)
/* harmony export */ });
const DEFAULT_TOKEN_LIST_URL = "pancakeswap";
const DEFAULT_LIST_OF_LISTS = [
    DEFAULT_TOKEN_LIST_URL
];


/***/ }),

/***/ 9899:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ useFetchListCallback)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _connectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3966);
/* harmony import */ var _state_lists_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9775);
/* harmony import */ var _utils_getTokenList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(565);
/* harmony import */ var _utils_resolveENSContentHash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2636);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_connectors__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_8__]);
([_connectors__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









function useFetchListCallback() {
    const { chainId , library  } = (0,_index__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .aQ)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const ensResolver = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((ensName)=>{
        if (!library || chainId !== _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET) {
            if (_connectors__WEBPACK_IMPORTED_MODULE_4__/* .NETWORK_CHAIN_ID */ .K4 === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MAINNET) {
                const networkLibrary = (0,_connectors__WEBPACK_IMPORTED_MODULE_4__/* .getNetworkLibrary */ .nM)();
                if (networkLibrary) {
                    return (0,_utils_resolveENSContentHash__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(ensName, networkLibrary);
                }
            }
            throw new Error("Could not construct mainnet ENS resolver");
        }
        return (0,_utils_resolveENSContentHash__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(ensName, library);
    }, [
        chainId,
        library
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async (listUrl)=>{
        const requestId = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.nanoid)();
        dispatch(_state_lists_actions__WEBPACK_IMPORTED_MODULE_5__/* .fetchTokenList.pending */ .Dn.pending({
            requestId,
            url: listUrl
        }));
        return (0,_utils_getTokenList__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(listUrl, ensResolver).then((tokenList)=>{
            dispatch(_state_lists_actions__WEBPACK_IMPORTED_MODULE_5__/* .fetchTokenList.fulfilled */ .Dn.fulfilled({
                url: listUrl,
                tokenList,
                requestId
            }));
            return tokenList;
        }).catch((error)=>{
            console.error(`Failed to get list at url ${listUrl}`, error);
            dispatch(_state_lists_actions__WEBPACK_IMPORTED_MODULE_5__/* .fetchTokenList.rejected */ .Dn.rejected({
                url: listUrl,
                requestId,
                errorMessage: error.message
            }));
            throw error;
        });
    }, [
        dispatch,
        ensResolver
    ]);
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useFetchListCallback)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$8": () => (/* binding */ addList),
/* harmony export */   "Dn": () => (/* binding */ fetchTokenList),
/* harmony export */   "Fz": () => (/* binding */ selectList),
/* harmony export */   "J_": () => (/* binding */ removeList),
/* harmony export */   "xJ": () => (/* binding */ acceptListUpdate)
/* harmony export */ });
/* unused harmony export rejectVersionUpdate */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const fetchTokenList = {
    pending: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/fetchTokenList/pending"),
    fulfilled: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/fetchTokenList/fulfilled"),
    rejected: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/fetchTokenList/rejected")
};
const acceptListUpdate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/acceptListUpdate");
const addList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/addList");
const removeList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/removeList");
const selectList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/selectList");
const rejectVersionUpdate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("lists/rejectVersionUpdate");


/***/ }),

/***/ 565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getTokenList)
/* harmony export */ });
/* harmony import */ var _uniswap_token_lists_src_tokenlist_schema_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(475);
/* harmony import */ var ajv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5888);
/* harmony import */ var ajv__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ajv__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contenthashToUri__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2391);
/* harmony import */ var _parseENSAddress__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6298);
/* harmony import */ var _uriToHttp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7787);
/* harmony import */ var _constants_lists__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7027);
/* harmony import */ var _constants_token_pancakeswap_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7449);





// bakeryswap defaultTokenJson


const tokenListValidator = new (ajv__WEBPACK_IMPORTED_MODULE_1___default())({
    allErrors: true
}).compile(_uniswap_token_lists_src_tokenlist_schema_json__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Contains the logic for resolving a list URL to a validated token list
 * @param listUrl list url
 * @param resolveENSContentHash resolves an ens name to a contenthash
 */ async function getTokenList(listUrl, resolveENSContentHash) {
    if (listUrl === _constants_lists__WEBPACK_IMPORTED_MODULE_3__/* .DEFAULT_TOKEN_LIST_URL */ .$) {
        return _constants_token_pancakeswap_json__WEBPACK_IMPORTED_MODULE_4__;
    }
    const parsedENS = (0,_parseENSAddress__WEBPACK_IMPORTED_MODULE_5__/* .parseENSAddress */ .y)(listUrl);
    let urls;
    if (parsedENS) {
        let contentHashUri;
        try {
            contentHashUri = await resolveENSContentHash(parsedENS.ensName);
        } catch (error) {
            console.error(`Failed to resolve ENS name: ${parsedENS.ensName}`, error);
            throw new Error(`Failed to resolve ENS name: ${parsedENS.ensName}`);
        }
        let translatedUri;
        try {
            translatedUri = (0,_contenthashToUri__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(contentHashUri);
        } catch (error1) {
            console.error("Failed to translate contenthash to URI", contentHashUri);
            throw new Error(`Failed to translate contenthash to URI: ${contentHashUri}`);
        }
        urls = (0,_uriToHttp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(`${translatedUri}${parsedENS.ensPath ?? ""}`);
    } else {
        urls = (0,_uriToHttp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(listUrl);
    }
    for(let i = 0; i < urls.length; i++){
        const url = urls[i];
        const isLast = i === urls.length - 1;
        let response;
        try {
            response = await fetch(url);
        } catch (error2) {
            console.error("Failed to fetch list", listUrl, error2);
            if (isLast) throw new Error(`Failed to download list ${listUrl}`);
            continue;
        }
        if (!response.ok) {
            if (isLast) throw new Error(`Failed to download list ${listUrl}`);
            continue;
        }
        const json = await response.json();
        if (!tokenListValidator(json)) {
            const validationErrors = tokenListValidator.errors?.reduce((memo, error)=>{
                const add = `${error.dataPath} ${error.message ?? ""}`;
                return memo.length > 0 ? `${memo}; ${add}` : `${add}`;
            }, "") ?? "unknown error";
            throw new Error(`Token list failed validation: ${validationErrors}`);
        }
        return json;
    }
    throw new Error("Unrecognized list URL protocol.");
};


/***/ }),

/***/ 2636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ resolveENSContentHash)
/* harmony export */ });
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2792);
/* harmony import */ var _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2522);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__);


const REGISTRAR_ABI = [
    {
        constant: true,
        inputs: [
            {
                name: "node",
                type: "bytes32"
            }
        ],
        name: "resolver",
        outputs: [
            {
                name: "resolverAddress",
                type: "address"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    }
];
const REGISTRAR_ADDRESS = "0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e";
const RESOLVER_ABI = [
    {
        constant: true,
        inputs: [
            {
                internalType: "bytes32",
                name: "node",
                type: "bytes32"
            }
        ],
        name: "contenthash",
        outputs: [
            {
                internalType: "bytes",
                name: "",
                type: "bytes"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    }
];
// cache the resolver contracts since most of them are the public resolver
function resolverContract(resolverAddress, provider) {
    return new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__.Contract(resolverAddress, RESOLVER_ABI, provider);
}
/**
 * Fetches and decodes the result of an ENS contenthash lookup on mainnet to a URI
 * @param ensName to resolve
 * @param provider provider to use to fetch the data
 */ async function resolveENSContentHash(ensName, provider) {
    const ensRegistrarContract = new _ethersproject_contracts__WEBPACK_IMPORTED_MODULE_0__.Contract(REGISTRAR_ADDRESS, REGISTRAR_ABI, provider);
    const hash = (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_1__.namehash)(ensName);
    const resolverAddress = await ensRegistrarContract.resolver(hash);
    return resolverContract(resolverAddress, provider).contenthash(hash);
};


/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = JSON.parse('{"name":"PancakeSwap Default List","timestamp":"2021-03-17T09:56:23Z","version":{"major":2,"minor":10,"patch":0},"tags":{},"logoURI":"https://exchange.pancakeswap.finance/images/pancakeswap.png","keywords":["pancake","default"],"tokens":[{"name":"YourLife Token","symbol":"YLT","address":"0x7246e5d5c4368896f0dd07794380f7e627e9af78","chainId":97,"decimals":18,"logoURI":"/images/coins/ylt.png"},{"name":"Binance USD","symbol":"BUSD","address":"0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee","chainId":97,"decimals":18,"logoURI":"/images/coins/busd.png"},{"name":"USDT Token","symbol":"USDT","address":"0x337610d27c682E347C9cD60BD4b3b107C9d34dDd","chainId":97,"decimals":18,"logoURI":"/images/coins/usdt.png"}]}');

/***/ })

};
;