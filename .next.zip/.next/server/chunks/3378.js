"use strict";
exports.id = 3378;
exports.ids = [3378];
exports.modules = {

/***/ 7749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ TranslationsContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const defaultTranslationState = {
    translations: [],
    setTranslations: ()=>undefined
};
const TranslationsContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(defaultTranslationState);
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (TranslationsContext)));


/***/ }),

/***/ 3378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ TranslateString),
/* harmony export */   "i": () => (/* binding */ getTranslation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_TranslationsContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7749);


const variableRegex = /%(.*?)%/;
const replaceDynamicString = (foundTranslation, fallback)=>{
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const stringToReplace = variableRegex.exec(foundTranslation)[0];
    const indexToReplace = foundTranslation.split(" ").indexOf(stringToReplace);
    const fallbackValueAtIndex = fallback.split(" ")[indexToReplace];
    return foundTranslation.replace(stringToReplace, fallbackValueAtIndex);
};
const getTranslation = (translations, translationId, fallback)=>{
    const foundTranslation = translations.find((translation)=>{
        return translation.data.stringId === translationId;
    });
    if (foundTranslation) {
        const translatedString = foundTranslation.data.text;
        const includesVariable = translatedString.includes("%");
        if (includesVariable) {
            return replaceDynamicString(translatedString, fallback);
        }
        return translatedString;
    }
    return fallback;
};
const TranslateString = (translationId, fallback)=>{
    const { translations  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_hooks_TranslationsContext__WEBPACK_IMPORTED_MODULE_1__/* .TranslationsContext */ .y);
    if (translations[0] === "error") {
        return fallback;
    }
    if (translations.length > 0) {
        return getTranslation(translations, translationId, fallback);
    }
    return null;
};


/***/ })

};
;