"use strict";
exports.id = 457;
exports.ids = [457];
exports.modules = {

/***/ 7256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cm": () => (/* binding */ useSelectedTokenList),
/* harmony export */   "DT": () => (/* binding */ WrappedTokenInfo),
/* harmony export */   "LQ": () => (/* binding */ useSelectedListInfo),
/* harmony export */   "f5": () => (/* binding */ useSelectedListUrl)
/* harmony export */ });
/* unused harmony exports listToTokenMap, useTokenList, useAllLists */
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);



/**
 * Token instances created from token info.
 */ class WrappedTokenInfo extends _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token {
    constructor(tokenInfo, tags){
        super(tokenInfo.chainId, tokenInfo.address, tokenInfo.decimals, tokenInfo.symbol, tokenInfo.name);
        this.tokenInfo = tokenInfo;
        this.tags = tags;
    }
    get logoURI() {
        return this.tokenInfo.logoURI;
    }
}
/**
 * An empty result, useful as a default.
 */ const EMPTY_LIST = {
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: {},
    [_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSCTESTNET]: {}
};
const listCache = typeof WeakMap !== "undefined" ? new WeakMap() : null;
function listToTokenMap(list) {
    const result = listCache?.get(list);
    if (result) return result;
    const map = list.tokens.reduce((tokenMap, tokenInfo)=>{
        const tags = tokenInfo.tags?.map((tagId)=>{
            if (!list.tags?.[tagId]) return undefined;
            return {
                ...list.tags[tagId],
                id: tagId
            };
        })?.filter((x)=>Boolean(x)) ?? [];
        const token = new WrappedTokenInfo(tokenInfo, tags);
        if (tokenMap[token.chainId][token.address] !== undefined) throw Error("Duplicate tokens.");
        return {
            ...tokenMap,
            [token.chainId]: {
                ...tokenMap[token.chainId],
                [token.address]: token
            }
        };
    }, {
        ...EMPTY_LIST
    });
    listCache?.set(list, map);
    return map;
}
function useTokenList(url) {
    const lists = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.lists.byUrl);
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!url) return EMPTY_LIST;
        const current = lists[url]?.current;
        if (!current) return EMPTY_LIST;
        try {
            return listToTokenMap(current);
        } catch (error) {
            console.error("Could not show token list due to error", error);
            return EMPTY_LIST;
        }
    }, [
        lists,
        url
    ]);
}
function useSelectedListUrl() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.lists.selectedListUrl);
}
function useSelectedTokenList() {
    return useTokenList(useSelectedListUrl());
}
function useSelectedListInfo() {
    const selectedUrl = useSelectedListUrl();
    const listsByUrl = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.lists.byUrl);
    const list = selectedUrl ? listsByUrl[selectedUrl] : undefined;
    return {
        current: list?.current ?? null,
        pending: list?.pendingUpdate ?? null,
        loading: list?.loadingRequestId !== null
    };
}
// returns all downloaded current lists
function useAllLists() {
    const lists = useSelector((state)=>state.lists.byUrl);
    return useMemo(()=>Object.keys(lists).map((url)=>lists[url].current).filter((l)=>Boolean(l)), [
        lists
    ]);
}


/***/ }),

/***/ 8442:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DB": () => (/* binding */ NEVER_RELOAD),
/* harmony export */   "Wk": () => (/* binding */ useSingleCallResult),
/* harmony export */   "_Y": () => (/* binding */ useMultipleContractSingleData),
/* harmony export */   "es": () => (/* binding */ useSingleContractMultipleData)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _application_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9348);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3146);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__, _application_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([_hooks__WEBPACK_IMPORTED_MODULE_2__, _application_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function isMethodArg(x) {
    return [
        "string",
        "number"
    ].indexOf(typeof x) !== -1;
}
function isValidMethodArgs(x) {
    return x === undefined || Array.isArray(x) && x.every((xi)=>isMethodArg(xi) || Array.isArray(xi) && xi.every(isMethodArg));
}
const INVALID_RESULT = {
    valid: false,
    blockNumber: undefined,
    data: undefined
};
// use this options object
const NEVER_RELOAD = {
    blocksPerFetch: Infinity
};
// the lowest level call for subscribing to contract data
function useCallsData(calls, options) {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const callResults = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.multicall.callResults);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const serializedCallKeys = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>JSON.stringify(calls?.filter((c)=>Boolean(c))?.map(_actions__WEBPACK_IMPORTED_MODULE_4__/* .toCallKey */ .kG)?.sort() ?? []), [
        calls
    ]);
    // update listeners when there is an actual change that persists for at least 100ms
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const callKeys = JSON.parse(serializedCallKeys);
        if (!chainId || callKeys.length === 0) return undefined;
        const calls = callKeys.map((key)=>(0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .parseCallKey */ .gl)(key));
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .addMulticallListeners */ .Dd)({
            chainId,
            calls,
            options
        }));
        return ()=>{
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .removeMulticallListeners */ .$x)({
                chainId,
                calls,
                options
            }));
        };
    }, [
        chainId,
        dispatch,
        options,
        serializedCallKeys
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>// @ts-ignore
        calls.map((call)=>{
            if (!chainId || !call) return INVALID_RESULT;
            const result = callResults[chainId]?.[(0,_actions__WEBPACK_IMPORTED_MODULE_4__/* .toCallKey */ .kG)(call)];
            const data = result?.data && result?.data !== "0x" ? result.data : null;
            return {
                valid: true,
                data,
                blockNumber: result?.blockNumber
            };
        }), [
        callResults,
        calls,
        chainId
    ]);
}
const INVALID_CALL_STATE = {
    valid: false,
    result: undefined,
    loading: false,
    syncing: false,
    error: false
};
const LOADING_CALL_STATE = {
    valid: true,
    result: undefined,
    loading: true,
    syncing: true,
    error: false
};
function toCallState(callResult, contractInterface, fragment, latestBlockNumber) {
    if (!callResult) return INVALID_CALL_STATE;
    const { valid , data , blockNumber  } = callResult;
    if (!valid) return INVALID_CALL_STATE;
    if (valid && !blockNumber) return LOADING_CALL_STATE;
    if (!contractInterface || !fragment || !latestBlockNumber) return LOADING_CALL_STATE;
    const success = data && data.length > 2;
    const syncing = (blockNumber ?? 0) < latestBlockNumber;
    let result;
    if (success && data) {
        try {
            result = contractInterface.decodeFunctionResult(fragment, data);
        } catch (error) {
            console.error("Result data parsing failed", fragment, data);
            return {
                valid: true,
                loading: false,
                error: true,
                syncing,
                result
            };
        }
    }
    return {
        valid: true,
        loading: false,
        syncing,
        result,
        error: !success
    };
}
function useSingleContractMultipleData(contract, methodName, callInputs, options) {
    const fragment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>contract?.interface?.getFunction(methodName), [
        contract,
        methodName
    ]);
    const calls = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>contract && fragment && callInputs && callInputs.length > 0 ? callInputs.map((inputs)=>{
            return {
                address: contract.address,
                callData: contract.interface.encodeFunctionData(fragment, inputs)
            };
        }) : [], [
        callInputs,
        contract,
        fragment
    ]);
    const results = useCallsData(calls, options);
    const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useBlockNumber */ .Ov)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return results.map((result)=>toCallState(result, contract?.interface, fragment, latestBlockNumber));
    }, [
        fragment,
        contract,
        results,
        latestBlockNumber
    ]);
}
function useMultipleContractSingleData(addresses, contractInterface, methodName, callInputs, options) {
    const fragment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>contractInterface.getFunction(methodName), [
        contractInterface,
        methodName
    ]);
    const callData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>fragment && isValidMethodArgs(callInputs) ? contractInterface.encodeFunctionData(fragment, callInputs) : undefined, [
        callInputs,
        contractInterface,
        fragment
    ]);
    const calls = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>fragment && addresses && addresses.length > 0 && callData ? addresses.map((address)=>{
            return address && callData ? {
                address,
                callData
            } : undefined;
        }) : [], [
        addresses,
        callData,
        fragment
    ]);
    const results = useCallsData(calls, options);
    const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useBlockNumber */ .Ov)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return results.map((result)=>toCallState(result, contractInterface, fragment, latestBlockNumber));
    }, [
        fragment,
        results,
        contractInterface,
        latestBlockNumber
    ]);
}
function useSingleCallResult(contract, methodName, inputs, options) {
    const fragment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>contract?.interface?.getFunction(methodName), [
        contract,
        methodName
    ]);
    const calls = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return contract && fragment && isValidMethodArgs(inputs) ? [
            {
                address: contract.address,
                callData: contract.interface.encodeFunctionData(fragment, inputs)
            }, 
        ] : [];
    }, [
        contract,
        fragment,
        inputs
    ]);
    const result = useCallsData(calls, options)[0];
    const latestBlockNumber = (0,_application_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useBlockNumber */ .Ov)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return toCallState(result, contract?.interface, fragment, latestBlockNumber);
    }, [
        result,
        contract,
        fragment,
        latestBlockNumber
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ isZero)
/* harmony export */ });
/**
 * Returns true if the string value is zero in hex
 * @param hexNumberString
 */ function isZero(hexNumberString) {
    return /^0x0*$/.test(hexNumberString);
};


/***/ })

};
;