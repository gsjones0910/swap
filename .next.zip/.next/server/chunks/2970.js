"use strict";
exports.id = 2970;
exports.ids = [2970];
exports.modules = {

/***/ 2882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "h2": () => (/* binding */ GreyCard),
/* harmony export */   "hl": () => (/* binding */ LightCard)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Card = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-9d20f5ff-0"
})`
  width: 100%;
  border-radius: 16px;
  padding: 1.25rem;
  padding: ${({ padding  })=>padding};
  border: ${({ border  })=>border};
  border-radius: ${({ borderRadius  })=>borderRadius};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);
const LightCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-9d20f5ff-1"
})`
  border: 1px solid ${({ theme  })=>theme.colors.invertedContrast};
  background-color: ${({ theme  })=>theme.colors.invertedContrast};
`;
const GreyCard = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Card).withConfig({
    componentId: "sc-9d20f5ff-2"
})`
  background-color: ${({ theme  })=>theme.colors.tertiary};
`;


/***/ }),

/***/ 247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tz": () => (/* binding */ AutoColumn),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "lg": () => (/* binding */ ColumnCenter)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Column = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-c0d82adc-0"
})`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
const ColumnCenter = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Column).withConfig({
    componentId: "sc-c0d82adc-1"
})`
  width: 100%;
  align-items: center;
`;
const AutoColumn = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-c0d82adc-2"
})`
  display: grid;
  grid-auto-rows: auto;
  grid-row-gap: ${({ gap  })=>gap === "sm" && "8px" || gap === "md" && "12px" || gap === "lg" && "24px" || gap};
  justify-items: ${({ justify  })=>justify && justify};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Column);


/***/ }),

/***/ 3976:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(817);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__]);
_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-15b0c248-0"
})`
  position: relative;
  display: flex;
  flex-direction: row;
  margin-right: ${({ sizeraw , margin  })=>margin && `${(sizeraw / 3 + 8).toString()}px`};
`;
const HigherLogo = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z).withConfig({
    componentId: "sc-15b0c248-1"
})`
  z-index: 2;
`;
const CoveredLogo = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z).withConfig({
    componentId: "sc-15b0c248-2"
})`
  position: absolute;
  left: ${({ sizeraw  })=>`${(sizeraw / 2).toString()}px`};
`;
function DoubleCurrencyLogo({ currency0 , currency1 , size =16 , margin =false  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        sizeraw: size,
        margin: margin,
        children: [
            currency0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HigherLogo, {
                currency: currency0,
                size: `${size.toString()}px`
            }),
            currency1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoveredLogo, {
                currency: currency1,
                size: `${size.toString()}px`,
                sizeraw: size
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ QuestionHelper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Tooltip__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3044);





const QuestionWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-5ce8b13c-0"
})`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0.2rem;
  border: none;
  background: none;
  outline: none;
  cursor: default;
  border-radius: 36px;
  background-color: ${({ theme  })=>theme.colors.invertedContrast};
  color: ${({ theme  })=>theme.colors.textSubtle};

  :hover,
  :focus {
    opacity: 0.7;
  }
`;
function QuestionHelper({ text  }) {
    const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const open = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>setShow(true), [
        setShow
    ]);
    const close = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>setShow(false), [
        setShow
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        style: {
            marginLeft: 4
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            text: text,
            show: show,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuestionWrapper, {
                onClick: open,
                onMouseEnter: open,
                onMouseLeave: close,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_2__.HelpCircle, {
                    size: 16
                })
            })
        })
    });
};


/***/ }),

/***/ 3044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "u": () => (/* binding */ MouseoverTooltip),
  "Z": () => (/* binding */ Tooltip)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "polished"
var external_polished_ = __webpack_require__(2042);
// EXTERNAL MODULE: external "react-popper"
var external_react_popper_ = __webpack_require__(2932);
// EXTERNAL MODULE: external "@reach/portal"
var portal_ = __webpack_require__(9677);
var portal_default = /*#__PURE__*/__webpack_require__.n(portal_);
// EXTERNAL MODULE: ./hooks/useInterval.ts
var useInterval = __webpack_require__(138);
;// CONCATENATED MODULE: ./components/Popover/index.tsx







const PopoverContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-2f4cd253-0"
})`
  z-index: 9999;

  visibility: ${(props)=>props.show ? "visible" : "hidden"};
  opacity: ${(props)=>props.show ? 1 : 0};
  transition: visibility 150ms linear, opacity 150ms linear;

  background: ${({ theme  })=>theme.colors.invertedContrast};
  border: 1px solid ${({ theme  })=>theme.colors.tertiary};
  box-shadow: 0 4px 8px 0 ${(0,external_polished_.transparentize)(0.9, "#2F80ED")};
  color: ${({ theme  })=>theme.colors.textSubtle};
  border-radius: 8px;
`;
const ReferenceElement = external_styled_components_default().div.withConfig({
    componentId: "sc-2f4cd253-1"
})`
  display: inline-block;
`;
const Arrow = external_styled_components_default().div.withConfig({
    componentId: "sc-2f4cd253-2"
})`
  width: 8px;
  height: 8px;
  z-index: 9998;

  ::before {
    position: absolute;
    width: 8px;
    height: 8px;
    z-index: 9998;

    content: '';
    border: 1px solid ${({ theme  })=>theme.colors.tertiary};
    transform: rotate(45deg);
    background: ${({ theme  })=>theme.colors.invertedContrast};
  }

  &.arrow-top {
    bottom: -5px;
    ::before {
      border-top: none;
      border-left: none;
    }
  }

  &.arrow-bottom {
    top: -5px;
    ::before {
      border-bottom: none;
      border-right: none;
    }
  }

  &.arrow-left {
    right: -5px;

    ::before {
      border-bottom: none;
      border-left: none;
    }
  }

  &.arrow-right {
    left: -5px;
    ::before {
      border-right: none;
      border-top: none;
    }
  }
`;
function Popover({ content , show , children , placement ="auto"  }) {
    const { 0: referenceElement , 1: setReferenceElement  } = (0,external_react_.useState)(null);
    const { 0: popperElement , 1: setPopperElement  } = (0,external_react_.useState)(null);
    const { 0: arrowElement , 1: setArrowElement  } = (0,external_react_.useState)(null);
    const { styles , update , attributes  } = (0,external_react_popper_.usePopper)(referenceElement, popperElement, {
        placement,
        strategy: "fixed",
        modifiers: [
            {
                name: "offset",
                options: {
                    offset: [
                        8,
                        8
                    ]
                }
            },
            {
                name: "arrow",
                options: {
                    element: arrowElement
                }
            }, 
        ]
    });
    const updateCallback = (0,external_react_.useCallback)(()=>{
        if (update) {
            update();
        }
    }, [
        update
    ]);
    (0,useInterval/* default */.Z)(updateCallback, show ? 100 : null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ReferenceElement, {
                ref: setReferenceElement,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((portal_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PopoverContainer, {
                    show: show,
                    ref: setPopperElement,
                    style: styles.popper,
                    ...attributes.popper,
                    children: [
                        content,
                        /*#__PURE__*/ jsx_runtime_.jsx(Arrow, {
                            className: `arrow-${attributes.popper?.["data-popper-placement"] ?? ""}`,
                            ref: setArrowElement,
                            style: styles.arrow,
                            ...attributes.arrow
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Tooltip/index.tsx




const TooltipContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-71d5f1a8-0"
})`
  width: 228px;
  padding: 0.6rem 1rem;
  line-height: 150%;
  font-weight: 400;
`;
function Tooltip({ text , ...rest }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Popover, {
        content: /*#__PURE__*/ jsx_runtime_.jsx(TooltipContainer, {
            children: text
        }),
        ...rest
    });
};
function MouseoverTooltip({ children , ...rest }) {
    const { 0: show , 1: setShow  } = (0,external_react_.useState)(false);
    const open = (0,external_react_.useCallback)(()=>setShow(true), [
        setShow
    ]);
    const close = (0,external_react_.useCallback)(()=>setShow(false), [
        setShow
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Tooltip, {
        ...rest,
        show: show,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            onMouseEnter: open,
            onMouseLeave: close,
            children: children
        })
    });
}


/***/ }),

/***/ 4799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BodyWrapper": () => (/* binding */ BodyWrapper),
/* harmony export */   "default": () => (/* binding */ AppBody)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);




const BodyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Card).withConfig({
    componentId: "sc-7da776df-0"
})`
  position: relative;
  background: white;
  display: flex;
  flex-direction: column;
  border-radius: 1rem; /* 16px */
  padding-top: 40px;
  padding-bottom: 40px;
  margin-top: 1px;
  margin-top: 30px;
  margin-bottom: 30px;
  color: #242424;
`;
/**
 * The styled container element that wraps the content of most pages and the tabs.
 */ function AppBody({ children  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BodyWrapper, {
        className: "sm:w-[640px] sm:max-w-[640px] max-w-[460px] w-full",
        children: children
    });
};


/***/ })

};
;