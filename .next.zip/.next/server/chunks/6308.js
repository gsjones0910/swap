exports.id = 6308;
exports.ids = [6308];
exports.modules = {

/***/ 6675:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "w": () => (/* binding */ AddRemoveTabs)
});

// UNUSED EXPORTS: FindPoolTabs

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9101);
// EXTERNAL MODULE: ./components/Row/index.tsx
var Row = __webpack_require__(108);
// EXTERNAL MODULE: ./components/QuestionHelper/index.tsx
var components_QuestionHelper = __webpack_require__(3994);
;// CONCATENATED MODULE: ./assets/btn-arrow.svg
var _g, _defs;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBtnArrow = function SvgBtnArrow(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _g || (_g = /*#__PURE__*/external_react_.createElement("g", {
    clipPath: "url(#btn-arrow_svg__a)"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "m7.828 13 5.364 5.364-1.414 1.414L4 12l7.778-7.778 1.414 1.414L7.828 11H20v2H7.828Z",
    fill: "#3985F5"
  }))), _defs || (_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("clipPath", {
    id: "btn-arrow_svg__a"
  }, /*#__PURE__*/external_react_.createElement("path", {
    fill: "#fff",
    transform: "rotate(-180 12 12)",
    d: "M0 0h24v24H0z"
  })))));
};
/* harmony default export */ const btn_arrow = (SvgBtnArrow);
;// CONCATENATED MODULE: ./components/NavigationTabs/index.tsx








const Tabs = external_styled_components_default().div.withConfig({
    componentId: "sc-85821b8b-0"
})`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  border-radius: 3rem;
  justify-content: space-evenly;
`;
const ActiveText = external_styled_components_default().div.withConfig({
    componentId: "sc-85821b8b-1"
})`
  font-weight: 700;
  font-size: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  color: #242424;
`;
const StyledArrowLeft = external_styled_components_default()(external_react_feather_.ArrowLeft).withConfig({
    componentId: "sc-85821b8b-2"
})`
  color: ${({ theme  })=>theme.colors.text};
`;
function FindPoolTabs() {
    return /*#__PURE__*/ _jsx(Tabs, {
        children: /*#__PURE__*/ _jsxs(RowBetween, {
            style: {
                padding: "1rem"
            },
            children: [
                /*#__PURE__*/ _jsx(Link, {
                    href: "/liquidity",
                    children: /*#__PURE__*/ _jsx(StyledArrowLeft, {})
                }),
                /*#__PURE__*/ _jsx(ActiveText, {
                    children: "Import Pool"
                }),
                /*#__PURE__*/ _jsx(QuestionHelper, {
                    text: "Use this tool to find pairs that do not automatically appear in the interface."
                })
            ]
        })
    });
}
function AddRemoveTabs({ adding  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Tabs, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Row/* RowBetween */.m0, {
            style: {
                paddingLeft: "1rem",
                paddingRight: "1rem"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/liquidity",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute w-10 h-10 flex justify-center items-center left-5 rounded-full bg-[#F6F6F7] cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(btn_arrow, {})
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ActiveText, {
                    children: [
                        adding ? "ADD" : "REMOVE",
                        " LIQUIDITY"
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 6070:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useTotalSupply)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5307);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__]);
([_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// returns undefined if input token is undefined, or fails to get token contract,
// or contract total supply cannot be fetched
function useTotalSupply(token) {
    const contract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_1__/* .useTokenContract */ .Ib)(token?.address, false);
    const totalSupply = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(contract, "totalSupply")?.result?.[0];
    return token && totalSupply ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, totalSupply.toString()) : undefined;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useTotalSupply)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ currencyId)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);

function currencyId(currency) {
    if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) return "BNB";
    if (currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token) return currency.address;
    throw new Error("invalid currency");
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (currencyId)));


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;