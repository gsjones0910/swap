"use strict";
exports.id = 8298;
exports.ids = [8298];
exports.modules = {

/***/ 2524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useTradeExactIn),
/* harmony export */   "i": () => (/* binding */ useTradeExactOut)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_flatmap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5574);
/* harmony import */ var lodash_flatmap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_flatmap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1407);
/* harmony import */ var _data_Reserves__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4213);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5354);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_Reserves__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_6__]);
([_data_Reserves__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function useAllCommonPairs(currencyA, currencyB) {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_6__/* .useActiveWeb3React */ .aQ)();
    // Base tokens for building intermediary trading routes
    const bases = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>chainId ? _constants__WEBPACK_IMPORTED_MODULE_3__/* .BASES_TO_CHECK_TRADES_AGAINST */ .lM[chainId] : [], [
        chainId
    ]);
    // All pairs from base tokens
    const basePairs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>lodash_flatmap__WEBPACK_IMPORTED_MODULE_1___default()(bases, (base)=>bases.map((otherBase)=>[
                    base,
                    otherBase
                ])).filter(([t0, t1])=>t0.address !== t1.address), [
        bases
    ]);
    const [tokenA, tokenB] = chainId ? [
        (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_5__/* .wrappedCurrency */ .pu)(currencyA, chainId),
        (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_5__/* .wrappedCurrency */ .pu)(currencyB, chainId)
    ] : [
        undefined,
        undefined
    ];
    const allPairCombinations = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>tokenA && tokenB ? [
            // the direct pair
            [
                tokenA,
                tokenB
            ],
            // token A against all bases
            ...bases.map((base)=>[
                    tokenA,
                    base
                ]),
            // token B against all bases
            ...bases.map((base)=>[
                    tokenB,
                    base
                ]),
            // each base against all bases
            ...basePairs, 
        ].filter((tokens)=>Boolean(tokens[0] && tokens[1])).filter(([t0, t1])=>t0.address !== t1.address)// This filter will remove all the pairs that are not supported by the CUSTOM_BASES settings
        // This option is currently not used on Pancake swap
        .filter(([t0, t1])=>{
            if (!chainId) return true;
            const customBases = _constants__WEBPACK_IMPORTED_MODULE_3__/* .CUSTOM_BASES */ .IP[chainId];
            if (!customBases) return true;
            const customBasesA = customBases[t0.address];
            const customBasesB = customBases[t1.address];
            if (!customBasesA && !customBasesB) return true;
            if (customBasesA && !customBasesA.find((base)=>t1.equals(base))) return false;
            if (customBasesB && !customBasesB.find((base)=>t0.equals(base))) return false;
            return true;
        }) : [], [
        tokenA,
        tokenB,
        bases,
        basePairs,
        chainId
    ]);
    const allPairs = (0,_data_Reserves__WEBPACK_IMPORTED_MODULE_4__/* .usePairs */ .z$)(allPairCombinations);
    // only pass along valid pairs, non-duplicated pairs
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>Object.values(allPairs// filter out invalid pairs
        .filter((result)=>Boolean(result[0] === _data_Reserves__WEBPACK_IMPORTED_MODULE_4__/* .PairState.EXISTS */ ._G.EXISTS && result[1]))// filter out duplicated pairs
        .reduce((memo, [, curr])=>{
            memo[curr.liquidityToken.address] = memo[curr.liquidityToken.address] ?? curr;
            return memo;
        }, {})), [
        allPairs
    ]);
}
/**
 * Returns the best trade for the exact amount of tokens in to the given token out
 */ function useTradeExactIn(currencyAmountIn, currencyOut) {
    const allowedPairs = useAllCommonPairs(currencyAmountIn?.currency, currencyOut);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (currencyAmountIn && currencyOut && allowedPairs.length > 0) {
            return _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Trade.bestTradeExactIn(allowedPairs, currencyAmountIn, currencyOut, {
                maxHops: 3,
                maxNumResults: 1
            })[0] ?? null;
        }
        return null;
    }, [
        allowedPairs,
        currencyAmountIn,
        currencyOut
    ]);
}
/**
 * Returns the best trade for the token in to the exact amount of token out
 */ function useTradeExactOut(currencyIn, currencyAmountOut) {
    const allowedPairs = useAllCommonPairs(currencyIn, currencyAmountOut?.currency);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (currencyIn && currencyAmountOut && allowedPairs.length > 0) {
            return _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Trade.bestTradeExactOut(allowedPairs, currencyIn, currencyAmountOut, {
                maxHops: 3,
                maxNumResults: 1
            })[0] ?? null;
        }
        return null;
    }, [
        allowedPairs,
        currencyIn,
        currencyAmountOut
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4444:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useENS)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8847);
/* harmony import */ var _useENSAddress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(148);
/* harmony import */ var _useENSName__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2644);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useENSAddress__WEBPACK_IMPORTED_MODULE_1__, _useENSName__WEBPACK_IMPORTED_MODULE_2__]);
([_useENSAddress__WEBPACK_IMPORTED_MODULE_1__, _useENSName__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



/**
 * Given a name or address, does a lookup to resolve to an address and name
 * @param nameOrAddress ENS name or address
 */ function useENS(nameOrAddress) {
    const validated = (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(nameOrAddress);
    const reverseLookup = (0,_useENSName__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(validated || undefined);
    const lookup = (0,_useENSAddress__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(nameOrAddress);
    return {
        loading: reverseLookup.loading || lookup.loading,
        address: validated || lookup.address,
        name: reverseLookup.ENSName ? reverseLookup.ENSName : !validated && lookup.address ? nameOrAddress || null : null
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 148:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useENSAddress)
/* harmony export */ });
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2522);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _utils_isZero__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(720);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
/* harmony import */ var _useDebounce__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4841);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_3__]);
([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






/**
 * Does a lookup for an ENS name to find its address.
 */ function useENSAddress(ensName) {
    const debouncedName = (0,_useDebounce__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(ensName, 200);
    const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!debouncedName) return [
            undefined
        ];
        try {
            return debouncedName ? [
                (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.namehash)(debouncedName)
            ] : [
                undefined
            ];
        } catch (error) {
            return [
                undefined
            ];
        }
    }, [
        debouncedName
    ]);
    const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSRegistrarContract */ .zb)(false);
    const resolverAddress = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(registrarContract, "resolver", ensNodeArgument);
    const resolverAddressResult = resolverAddress.result?.[0];
    const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSResolverContract */ .uU)(resolverAddressResult && !(0,_utils_isZero__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(resolverAddressResult) ? resolverAddressResult : undefined, false);
    const addr = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(resolverContract, "addr", ensNodeArgument);
    const changed = debouncedName !== ensName;
    return {
        address: changed ? null : addr.result?.[0] ?? null,
        loading: changed || resolverAddress.loading || addr.loading
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2644:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useENSName)
/* harmony export */ });
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2522);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8847);
/* harmony import */ var _utils_isZero__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(720);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5307);
/* harmony import */ var _useDebounce__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4841);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_4__]);
([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







/**
 * Does a reverse lookup for an address to find its ENS name.
 * Note this is not the same as looking up an ENS name to find an address.
 */ function useENSName(address) {
    const debouncedAddress = (0,_useDebounce__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(address, 200);
    const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!debouncedAddress || !(0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .isAddress */ .UJ)(debouncedAddress)) return [
            undefined
        ];
        try {
            return debouncedAddress ? [
                (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.namehash)(`${debouncedAddress.toLowerCase().substr(2)}.addr.reverse`)
            ] : [
                undefined
            ];
        } catch (error) {
            return [
                undefined
            ];
        }
    }, [
        debouncedAddress
    ]);
    const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useENSRegistrarContract */ .zb)(false);
    const resolverAddress = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(registrarContract, "resolver", ensNodeArgument);
    const resolverAddressResult = resolverAddress.result?.[0];
    const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useENSResolverContract */ .uU)(resolverAddressResult && !(0,_utils_isZero__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(resolverAddressResult) ? resolverAddressResult : undefined, false);
    const name = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(resolverContract, "name", ensNodeArgument);
    const changed = debouncedAddress !== address;
    return {
        ENSName: changed ? null : name.result?.[0] ?? null,
        loading: changed || resolverAddress.loading || name.loading
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useParsedQueryString)
/* harmony export */ });
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7104);
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



function useParsedQueryString() {
    const { query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const search = JSON.stringify(query);
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>search && search.length > 1 ? (0,qs__WEBPACK_IMPORTED_MODULE_0__.parse)(search, {
            parseArrays: false,
            ignoreQueryPrefix: true
        }) : {}, [
        search
    ]);
};


/***/ }),

/***/ 8298:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SM": () => (/* binding */ useDerivedSwapInfo),
/* harmony export */   "_r": () => (/* binding */ useSwapActionHandlers),
/* harmony export */   "dU": () => (/* binding */ useSwapState),
/* harmony export */   "eo": () => (/* binding */ tryParseAmount),
/* harmony export */   "jj": () => (/* binding */ useDefaultsFromURLSearch)
/* harmony export */ });
/* unused harmony export queryParametersToSwapState */
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3138);
/* harmony import */ var _ethersproject_units__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_units__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useENS__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4444);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5820);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7411);
/* harmony import */ var _hooks_Trades__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2524);
/* harmony import */ var _hooks_useParsedQueryString__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2149);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8847);
/* harmony import */ var _wallet_hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1023);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9911);
/* harmony import */ var _user_hooks__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1158);
/* harmony import */ var _utils_prices__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9577);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useENS__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__, _hooks_Trades__WEBPACK_IMPORTED_MODULE_7__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_10__, _user_hooks__WEBPACK_IMPORTED_MODULE_12__]);
([_hooks_useENS__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__, _hooks_Trades__WEBPACK_IMPORTED_MODULE_7__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_10__, _user_hooks__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














function useSwapState() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.swap);
}
function useSwapActionHandlers() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const onCurrencySelection = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((field, currency)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_11__/* .selectCurrency */ .j)({
            field,
            //currencyId:
            // currency instanceof Token
            //   ? currency['address']
            //   : currency === ETHER
            //   ? "BNB"
            //   : "",
            currencyId: currency["address"]
        }));
    }, [
        dispatch
    ]);
    const onSwitchTokens = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_11__/* .switchCurrencies */ .KS)());
    }, [
        dispatch
    ]);
    const onUserInput = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((field, typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_11__/* .typeInput */ .LC)({
            field,
            typedValue
        }));
    }, [
        dispatch
    ]);
    const onChangeRecipient = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((recipient)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_11__/* .setRecipient */ .He)({
            recipient
        }));
    }, [
        dispatch
    ]);
    return {
        onSwitchTokens,
        onCurrencySelection,
        onUserInput,
        onChangeRecipient
    };
}
// try to parse a user entered amount for a given token
function tryParseAmount(value, currency) {
    if (!value || !currency) {
        return undefined;
    }
    try {
        const typedValueParsed = (0,_ethersproject_units__WEBPACK_IMPORTED_MODULE_0__.parseUnits)(value, currency.decimals).toString();
        if (typedValueParsed !== "0") {
            return currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.TokenAmount(currency, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(typedValueParsed)) : _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.CurrencyAmount.ether(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(typedValueParsed));
        }
    } catch (error) {
        // should fail if the user specifies too many decimal places of precision (or maybe exceed max uint?)
        console.info(`Failed to parse input amount: "${value}"`, error);
    }
    // necessary for all paths to return a value
    return undefined;
}
const BAD_RECIPIENT_ADDRESSES = [
    "0xaA2a96D0092c8700478924247fdeC47a1f271E45",
    "0x5E3Cae863a552DEf8e2a2749a5C65ecb21eCe841",
    "0xDE2Db97D54a3c3B008a097B2260633E6cA7DB1AF"
];
/**
 * Returns true if any of the pairs or tokens in a trade have the given checksummed address
 * @param trade to check for the given address
 * @param checksummedAddress address to check in the pairs and tokens
 */ function involvesAddress(trade, checksummedAddress) {
    return trade.route.path.some((token)=>token.address === checksummedAddress) || trade.route.pairs.some((pair)=>pair.liquidityToken.address === checksummedAddress);
}
// from the current swap inputs, compute the best trade and return it.
function useDerivedSwapInfo() {
    const { account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const { independentField , typedValue , [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT]: { currencyId: inputCurrencyId  } , [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT]: { currencyId: outputCurrencyId  } , recipient ,  } = useSwapState();
    const inputCurrency = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useCurrency */ .U8)(inputCurrencyId);
    const outputCurrency = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useCurrency */ .U8)(outputCurrencyId);
    const recipientLookup = (0,_hooks_useENS__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(recipient ?? undefined);
    const to = (recipient === null ? account : recipientLookup.address) ?? null;
    const relevantTokenBalances = (0,_wallet_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useCurrencyBalances */ .K5)(account ?? undefined, [
        inputCurrency ?? undefined,
        outputCurrency ?? undefined, 
    ]);
    const isExactIn = independentField === _actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT;
    const parsedAmount = tryParseAmount(typedValue, (isExactIn ? inputCurrency : outputCurrency) ?? undefined);
    const bestTradeExactIn = (0,_hooks_Trades__WEBPACK_IMPORTED_MODULE_7__/* .useTradeExactIn */ .A)(isExactIn ? parsedAmount : undefined, outputCurrency ?? undefined);
    const bestTradeExactOut = (0,_hooks_Trades__WEBPACK_IMPORTED_MODULE_7__/* .useTradeExactOut */ .i)(inputCurrency ?? undefined, !isExactIn ? parsedAmount : undefined);
    const v2Trade = isExactIn ? bestTradeExactIn : bestTradeExactOut;
    const currencyBalances = {
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT]: relevantTokenBalances[0],
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT]: relevantTokenBalances[1]
    };
    const currencies = {
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT]: inputCurrency ?? undefined,
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT]: outputCurrency ?? undefined
    };
    let inputError;
    if (!account) {
        inputError = "Connect Wallet";
    }
    if (!parsedAmount) {
        inputError = inputError ?? "Enter an amount";
    }
    if (!currencies[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT] || !currencies[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT]) {
        inputError = inputError ?? "Select a token";
    }
    const formattedTo = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(to);
    if (!to || !formattedTo) {
        inputError = inputError ?? "Enter a recipient";
    } else if (BAD_RECIPIENT_ADDRESSES.indexOf(formattedTo) !== -1 || bestTradeExactIn && involvesAddress(bestTradeExactIn, formattedTo) || bestTradeExactOut && involvesAddress(bestTradeExactOut, formattedTo)) {
        inputError = inputError ?? "Invalid recipient";
    }
    const [allowedSlippage] = (0,_user_hooks__WEBPACK_IMPORTED_MODULE_12__/* .useUserSlippageTolerance */ .$2)();
    const slippageAdjustedAmounts = v2Trade && allowedSlippage && (0,_utils_prices__WEBPACK_IMPORTED_MODULE_13__/* .computeSlippageAdjustedAmounts */ .b5)(v2Trade, allowedSlippage);
    // compare input balance to max input based on version
    const [balanceIn, amountIn] = [
        currencyBalances[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT],
        slippageAdjustedAmounts ? slippageAdjustedAmounts[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT] : null, 
    ];
    if (balanceIn && amountIn && balanceIn.lessThan(amountIn)) {
        inputError = `Insufficient ${amountIn.currency.symbol} balance`;
    }
    return {
        currencies,
        currencyBalances,
        parsedAmount,
        v2Trade: v2Trade ?? undefined,
        inputError
    };
}
function parseCurrencyFromURLParameter(urlParam) {
    if (typeof urlParam === "string") {
        const valid = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(urlParam);
        if (valid) return valid;
        if (urlParam.toUpperCase() === "BNB") return "BNB";
        if (valid === false) return "BNB";
    }
    return "BNB" ?? 0;
}
function parseTokenAmountURLParameter(urlParam) {
    // eslint-disable-next-line no-restricted-globals
    return typeof urlParam === "string" && !isNaN(parseFloat(urlParam)) ? urlParam : "";
}
function parseIndependentFieldURLParameter(urlParam) {
    return typeof urlParam === "string" && urlParam.toLowerCase() === "output" ? _actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT : _actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT;
}
const ENS_NAME_REGEX = /^[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)?$/;
const ADDRESS_REGEX = /^0x[a-fA-F0-9]{40}$/;
function validatedRecipient(recipient) {
    if (typeof recipient !== "string") return null;
    const address = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .isAddress */ .UJ)(recipient);
    if (address) return address;
    if (ENS_NAME_REGEX.test(recipient)) return recipient;
    if (ADDRESS_REGEX.test(recipient)) return recipient;
    return null;
}
function queryParametersToSwapState(parsedQs) {
    let inputCurrency = parseCurrencyFromURLParameter(parsedQs.inputCurrency);
    let outputCurrency = parseCurrencyFromURLParameter(parsedQs.outputCurrency);
    if (inputCurrency === outputCurrency) {
        if (typeof parsedQs.outputCurrency === "string") {
            inputCurrency = "";
        } else {
            outputCurrency = "";
        }
    }
    const recipient = validatedRecipient(parsedQs.recipient);
    return {
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT]: {
            currencyId: inputCurrency
        },
        [_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT]: {
            currencyId: outputCurrency
        },
        typedValue: parseTokenAmountURLParameter(parsedQs.exactAmount),
        independentField: parseIndependentFieldURLParameter(parsedQs.exactField),
        recipient
    };
}
// updates the swap state to use the defaults for a given network
function useDefaultsFromURLSearch() {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const parsedQs = (0,_hooks_useParsedQueryString__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { 0: result , 1: setResult  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!chainId) return;
        const parsed = queryParametersToSwapState(parsedQs);
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_11__/* .replaceSwapState */ .mV)({
            typedValue: parsed.typedValue,
            field: parsed.independentField,
            inputCurrencyId: parsed[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT].currencyId,
            outputCurrencyId: parsed[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT].currencyId,
            recipient: parsed.recipient
        }));
        setResult({
            inputCurrencyId: parsed[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.INPUT */ .gN.INPUT].currencyId,
            outputCurrencyId: parsed[_actions__WEBPACK_IMPORTED_MODULE_11__/* .Field.OUTPUT */ .gN.OUTPUT].currencyId
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        dispatch,
        chainId
    ]);
    return result;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kh": () => (/* binding */ formatExecutionPrice),
/* harmony export */   "U7": () => (/* binding */ computeTradePriceBreakdown),
/* harmony export */   "b5": () => (/* binding */ computeSlippageAdjustedAmounts),
/* harmony export */   "oX": () => (/* binding */ warningSeverity)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1407);
/* harmony import */ var _state_swap_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9911);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8847);




const BASE_FEE = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(20), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const ONE_HUNDRED_PERCENT = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000), _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(10000));
const INPUT_FRACTION_AFTER_FEE = ONE_HUNDRED_PERCENT.subtract(BASE_FEE);
// computes price breakdown for the trade
function computeTradePriceBreakdown(trade) {
    // for each hop in our trade, take away the x*y=k price impact from 0.2% fees
    // e.g. for 3 tokens/2 hops: 1 - ((1 - .02) * (1-.02))
    const realizedLPFee = !trade ? undefined : ONE_HUNDRED_PERCENT.subtract(trade.route.pairs.reduce((currentFee)=>currentFee.multiply(INPUT_FRACTION_AFTER_FEE), ONE_HUNDRED_PERCENT));
    // remove lp fees from price impact
    const priceImpactWithoutFeeFraction = trade && realizedLPFee ? trade.priceImpact.subtract(realizedLPFee) : undefined;
    // the x*y=k impact
    const priceImpactWithoutFeePercent = priceImpactWithoutFeeFraction ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(priceImpactWithoutFeeFraction?.numerator, priceImpactWithoutFeeFraction?.denominator) : undefined;
    // the amount of the input that accrues to LPs
    const realizedLPFeeAmount = realizedLPFee && trade && (trade.inputAmount instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(trade.inputAmount.token, realizedLPFee.multiply(trade.inputAmount.raw).quotient) : _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(realizedLPFee.multiply(trade.inputAmount.raw).quotient));
    return {
        priceImpactWithoutFee: priceImpactWithoutFeePercent,
        realizedLPFee: realizedLPFeeAmount
    };
}
// computes the minimum amount out and maximum amount in for a trade given a user specified allowed slippage in bips
function computeSlippageAdjustedAmounts(trade, allowedSlippage) {
    const pct = (0,_index__WEBPACK_IMPORTED_MODULE_3__/* .basisPointsToPercent */ .P4)(allowedSlippage);
    return {
        [_state_swap_actions__WEBPACK_IMPORTED_MODULE_2__/* .Field.INPUT */ .gN.INPUT]: trade?.maximumAmountIn(pct),
        [_state_swap_actions__WEBPACK_IMPORTED_MODULE_2__/* .Field.OUTPUT */ .gN.OUTPUT]: trade?.minimumAmountOut(pct)
    };
}
function warningSeverity(priceImpact) {
    if (!priceImpact?.lessThan(_constants__WEBPACK_IMPORTED_MODULE_1__/* .BLOCKED_PRICE_IMPACT_NON_EXPERT */ .lN)) return 4;
    if (!priceImpact?.lessThan(_constants__WEBPACK_IMPORTED_MODULE_1__/* .ALLOWED_PRICE_IMPACT_HIGH */ .Uf)) return 3;
    if (!priceImpact?.lessThan(_constants__WEBPACK_IMPORTED_MODULE_1__/* .ALLOWED_PRICE_IMPACT_MEDIUM */ .p9)) return 2;
    if (!priceImpact?.lessThan(_constants__WEBPACK_IMPORTED_MODULE_1__/* .ALLOWED_PRICE_IMPACT_LOW */ .Bz)) return 1;
    return 0;
}
function formatExecutionPrice(trade, inverted) {
    if (!trade) {
        return "";
    }
    return inverted ? `${trade.executionPrice.invert().toSignificant(6)} ${trade.inputAmount.currency.symbol} / ${trade.outputAmount.currency.symbol}` : `${trade.executionPrice.toSignificant(6)} ${trade.outputAmount.currency.symbol} / ${trade.inputAmount.currency.symbol}`;
}


/***/ })

};
;