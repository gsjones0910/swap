"use strict";
exports.id = 1134;
exports.ids = [1134];
exports.modules = {

/***/ 5843:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Aw": () => (/* binding */ finalizeTransaction),
/* harmony export */   "LN": () => (/* binding */ checkedTransaction),
/* harmony export */   "dT": () => (/* binding */ addTransaction),
/* harmony export */   "fY": () => (/* binding */ clearAllTransactions)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const addTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("transactions/addTransaction");
const clearAllTransactions = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("transactions/clearAllTransactions");
const finalizeTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("transactions/finalizeTransaction");
const checkedTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("transactions/checkedTransaction");


/***/ }),

/***/ 8652:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B8": () => (/* binding */ muteAudio),
/* harmony export */   "_I": () => (/* binding */ updateMatchesDarkMode),
/* harmony export */   "cd": () => (/* binding */ removeSerializedPair),
/* harmony export */   "eg": () => (/* binding */ addSerializedToken),
/* harmony export */   "f9": () => (/* binding */ addSerializedPair),
/* harmony export */   "gw": () => (/* binding */ updateUserDeadline),
/* harmony export */   "rQ": () => (/* binding */ updateUserSlippageTolerance),
/* harmony export */   "u7": () => (/* binding */ unmuteAudio),
/* harmony export */   "vP": () => (/* binding */ updateUserDarkMode),
/* harmony export */   "zQ": () => (/* binding */ removeSerializedToken),
/* harmony export */   "zv": () => (/* binding */ updateUserExpertMode)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const updateMatchesDarkMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/updateMatchesDarkMode");
const updateUserDarkMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/updateUserDarkMode");
const updateUserExpertMode = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/updateUserExpertMode");
const updateUserSlippageTolerance = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/updateUserSlippageTolerance");
const updateUserDeadline = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/updateUserDeadline");
const addSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/addSerializedToken");
const removeSerializedToken = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/removeSerializedToken");
const addSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/addSerializedPair");
const removeSerializedPair = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/removeSerializedPair");
const muteAudio = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/muteAudio");
const unmuteAudio = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("user/unmuteAudio");


/***/ })

};
;