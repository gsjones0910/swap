"use strict";
exports.id = 3545;
exports.ids = [3545];
exports.modules = {

/***/ 4213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_G": () => (/* binding */ PairState),
/* harmony export */   "yX": () => (/* binding */ usePair),
/* harmony export */   "z$": () => (/* binding */ usePairs)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _uniswap_v2_core_build_IUniswapV2Pair_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6912);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6187);
/* harmony import */ var _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5820);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8442);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5354);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_4__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks__WEBPACK_IMPORTED_MODULE_4__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const PAIR_INTERFACE = new _ethersproject_abi__WEBPACK_IMPORTED_MODULE_3__.Interface(_uniswap_v2_core_build_IUniswapV2Pair_json__WEBPACK_IMPORTED_MODULE_2__/* .abi */ .Mt);
var PairState;
(function(PairState) {
    PairState[PairState["LOADING"] = 0] = "LOADING";
    PairState[PairState["NOT_EXISTS"] = 1] = "NOT_EXISTS";
    PairState[PairState["EXISTS"] = 2] = "EXISTS";
    PairState[PairState["INVALID"] = 3] = "INVALID";
})(PairState || (PairState = {}));
function usePairs(currencies) {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useActiveWeb3React */ .aQ)();
    const tokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>currencies.map(([currencyA, currencyB])=>[
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__/* .wrappedCurrency */ .pu)(currencyA, chainId),
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_6__/* .wrappedCurrency */ .pu)(currencyB, chainId), 
            ]), [
        chainId,
        currencies
    ]);
    const pairAddresses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>tokens.map(([tokenA, tokenB])=>{
            return tokenA && tokenB && !tokenA.equals(tokenB) ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Pair.getAddress(tokenA, tokenB) : undefined;
        }), [
        tokens
    ]);
    const results = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useMultipleContractSingleData */ ._Y)(pairAddresses, PAIR_INTERFACE, "getReserves");
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return results.map((result, i)=>{
            const { result: reserves , loading  } = result;
            const tokenA = tokens[i][0];
            const tokenB = tokens[i][1];
            if (loading) return [
                PairState.LOADING,
                null
            ];
            if (!tokenA || !tokenB || tokenA.equals(tokenB)) return [
                PairState.INVALID,
                null
            ];
            if (!reserves) return [
                PairState.NOT_EXISTS,
                null
            ];
            const { reserve0 , reserve1  } = reserves;
            const [token0, token1] = tokenA.sortsBefore(tokenB) ? [
                tokenA,
                tokenB
            ] : [
                tokenB,
                tokenA
            ];
            return [
                PairState.EXISTS,
                new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Pair(new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token0, reserve0.toString()), new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token1, reserve1.toString())), 
            ];
        });
    }, [
        results,
        tokens
    ]);
}
function usePair(tokenA, tokenB) {
    return usePairs([
        [
            tokenA,
            tokenB
        ]
    ])[0];
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7411:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EH": () => (/* binding */ useIsUserAddedToken),
/* harmony export */   "U8": () => (/* binding */ useCurrency),
/* harmony export */   "dQ": () => (/* binding */ useToken),
/* harmony export */   "e_": () => (/* binding */ useAllTokens)
/* harmony export */ });
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9213);
/* harmony import */ var _ethersproject_strings__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_strings__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7256);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1158);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8847);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5820);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5307);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_5__, _index__WEBPACK_IMPORTED_MODULE_7__, _useContract__WEBPACK_IMPORTED_MODULE_8__]);
([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_5__, _index__WEBPACK_IMPORTED_MODULE_7__, _useContract__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// eslint-disable-next-line import/no-cycle




function useAllTokens() {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_7__/* .useActiveWeb3React */ .aQ)();
    const userAddedTokens = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useUserAddedTokens */ .em)();
    const allTokens = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useSelectedTokenList */ .Cm)();
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!chainId) return {};
        return userAddedTokens// reduce into all ALL_TOKENS filtered by the current chain
        .reduce((tokenMap, token)=>{
            tokenMap[token.address] = token;
            return tokenMap;
        }, // must make a copy because reduce modifies the map, and we do not
        // want to make a copy in every iteration
        {
            ...allTokens[chainId]
        });
    }, [
        chainId,
        userAddedTokens,
        allTokens
    ]);
}
// Check if currency is included in custom list from user storage
function useIsUserAddedToken(currency) {
    const userAddedTokens = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useUserAddedTokens */ .em)();
    return !!userAddedTokens.find((token)=>(0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.currencyEquals)(currency, token));
}
// parse a name or symbol from a token response
const BYTES32_REGEX = /^0x[a-fA-F0-9]{64}$/;
function parseStringOrBytes32(str, bytes32, defaultValue) {
    return str && str.length > 0 ? str : bytes32 && BYTES32_REGEX.test(bytes32) ? (0,_ethersproject_strings__WEBPACK_IMPORTED_MODULE_0__.parseBytes32String)(bytes32) : defaultValue;
}
// undefined if invalid or does not exist
// null if loading
// otherwise returns the token
function useToken(tokenAddress) {
    const { chainId  } = (0,_index__WEBPACK_IMPORTED_MODULE_7__/* .useActiveWeb3React */ .aQ)();
    const tokens = useAllTokens();
    const address = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .isAddress */ .UJ)(tokenAddress);
    const tokenContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_8__/* .useTokenContract */ .Ib)(address || undefined, false);
    const tokenContractBytes32 = (0,_useContract__WEBPACK_IMPORTED_MODULE_8__/* .useBytes32TokenContract */ .gs)(address || undefined, false);
    const token = address ? tokens[address] : undefined;
    const tokenName = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, "name", undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .NEVER_RELOAD */ .DB);
    const tokenNameBytes32 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContractBytes32, "name", undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .NEVER_RELOAD */ .DB);
    const symbol = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, "symbol", undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .NEVER_RELOAD */ .DB);
    const symbolBytes32 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContractBytes32, "symbol", undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .NEVER_RELOAD */ .DB);
    const decimals = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSingleCallResult */ .Wk)(token ? undefined : tokenContract, "decimals", undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_4__/* .NEVER_RELOAD */ .DB);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (token) return token;
        if (!chainId || !address) return undefined;
        if (decimals.loading || symbol.loading || tokenName.loading) return null;
        if (decimals.result) {
            return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token(chainId, address, decimals.result[0], parseStringOrBytes32(symbol.result?.[0], symbolBytes32.result?.[0], "UNKNOWN"), parseStringOrBytes32(tokenName.result?.[0], tokenNameBytes32.result?.[0], "Unknown Token"));
        }
        return undefined;
    }, [
        address,
        chainId,
        decimals.loading,
        decimals.result,
        symbol.loading,
        symbol.result,
        symbolBytes32.result,
        token,
        tokenName.loading,
        tokenName.result,
        tokenNameBytes32.result, 
    ]);
}
function useCurrency(currencyId) {
    const isBNB = currencyId?.toUpperCase() === "BNB";
    const token = useToken(isBNB ? undefined : currencyId);
    return isBNB ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER : token;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7507:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h7": () => (/* binding */ useTransactionAdder),
/* harmony export */   "kf": () => (/* binding */ useAllTransactions),
/* harmony export */   "mH": () => (/* binding */ isTransactionRecent),
/* harmony export */   "wB": () => (/* binding */ useHasPendingApproval)
/* harmony export */ });
/* unused harmony export useIsTransactionPending */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5820);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5843);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__]);
_hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// helper that can take a ethers library transaction response and add it to the list of transactions
function useTransactionAdder() {
    const { chainId , account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((response, { summary , approval  } = {})=>{
        if (!account) return;
        if (!chainId) return;
        const { hash  } = response;
        if (!hash) {
            throw Error("No transaction hash found.");
        }
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_3__/* .addTransaction */ .dT)({
            hash,
            from: account,
            chainId,
            approval,
            summary
        }));
    }, [
        dispatch,
        chainId,
        account
    ]);
}
// returns all the transactions for the current chain
function useAllTransactions() {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActiveWeb3React */ .aQ)();
    const state = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((s)=>s.transactions);
    return chainId ? state[chainId] ?? {} : {};
}
function useIsTransactionPending(transactionHash) {
    const transactions = useAllTransactions();
    if (!transactionHash || !transactions[transactionHash]) return false;
    return !transactions[transactionHash].receipt;
}
/**
 * Returns whether a transaction happened in the last day (86400 seconds * 1000 milliseconds / second)
 * @param tx to check for recency
 */ function isTransactionRecent(tx) {
    return new Date().getTime() - tx.addedTime < 86400000;
}
// returns whether a token has a pending approval transaction
function useHasPendingApproval(tokenAddress, spender) {
    const allTransactions = useAllTransactions();
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>typeof tokenAddress === "string" && typeof spender === "string" && Object.keys(allTransactions).some((hash)=>{
            const tx = allTransactions[hash];
            if (!tx) return false;
            if (tx.receipt) {
                return false;
            }
            const { approval  } = tx;
            if (!approval) return false;
            return approval.spender === spender && approval.tokenAddress === tokenAddress && isTransactionRecent(tx);
        }), [
        allTransactions,
        spender,
        tokenAddress
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1158:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$2": () => (/* binding */ useUserSlippageTolerance),
/* harmony export */   "B3": () => (/* binding */ useTrackedTokenPairs),
/* harmony export */   "Ce": () => (/* binding */ toV2LiquidityToken),
/* harmony export */   "DG": () => (/* binding */ useExpertModeManager),
/* harmony export */   "LO": () => (/* binding */ useIsExpertMode),
/* harmony export */   "QG": () => (/* binding */ useRemoveUserAddedToken),
/* harmony export */   "TO": () => (/* binding */ useAudioModeManager),
/* harmony export */   "Td": () => (/* binding */ useUserDeadline),
/* harmony export */   "_E": () => (/* binding */ useAddUserToken),
/* harmony export */   "em": () => (/* binding */ useUserAddedTokens)
/* harmony export */ });
/* unused harmony exports useIsDarkMode, useDarkModeManager, usePairAdder */
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_flatmap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5574);
/* harmony import */ var lodash_flatmap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_flatmap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1407);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5820);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7411);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8652);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_5__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks__WEBPACK_IMPORTED_MODULE_5__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// eslint-disable-next-line import/no-cycle



function serializeToken(token) {
    return {
        chainId: token.chainId,
        address: token.address,
        decimals: token.decimals,
        symbol: token.symbol,
        name: token.name
    };
}
function deserializeToken(serializedToken) {
    return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(serializedToken.chainId, serializedToken.address, serializedToken.decimals, serializedToken.symbol, serializedToken.name);
}
function useIsDarkMode() {
    const { userDarkMode , matchesDarkMode  } = useSelector(({ user: { matchesDarkMode , userDarkMode  }  })=>({
            userDarkMode,
            matchesDarkMode
        }), shallowEqual);
    return userDarkMode === null ? matchesDarkMode : userDarkMode;
}
function useDarkModeManager() {
    const dispatch = useDispatch();
    const { userDarkMode  } = useSelector(({ user: { userDarkMode  }  })=>({
            userDarkMode
        }), shallowEqual);
    const darkMode = useIsDarkMode();
    const toggleSetDarkMode = useCallback(()=>{
        setThemeCache(!userDarkMode);
        dispatch(updateUserDarkMode({
            userDarkMode: !userDarkMode
        }));
    }, [
        userDarkMode,
        dispatch
    ]);
    return [
        darkMode,
        toggleSetDarkMode
    ];
}
function useAudioModeManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const audioPlay = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.user.audioPlay);
    const toggleSetAudioMode = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        if (audioPlay) {
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .muteAudio */ .B8)());
        } else {
            dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .unmuteAudio */ .u7)());
        }
    }, [
        audioPlay,
        dispatch
    ]);
    return [
        audioPlay,
        toggleSetAudioMode
    ];
}
function useIsExpertMode() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.user.userExpertMode);
}
function useExpertModeManager() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const expertMode = useIsExpertMode();
    const toggleSetExpertMode = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateUserExpertMode */ .zv)({
            userExpertMode: !expertMode
        }));
    }, [
        expertMode,
        dispatch
    ]);
    return [
        expertMode,
        toggleSetExpertMode
    ];
}
function useUserSlippageTolerance() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const userSlippageTolerance = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>{
        return state.user.userSlippageTolerance;
    });
    const setUserSlippageTolerance = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((slippageTolerance)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateUserSlippageTolerance */ .rQ)({
            userSlippageTolerance: slippageTolerance
        }));
    }, [
        dispatch
    ]);
    return [
        userSlippageTolerance,
        setUserSlippageTolerance
    ];
}
function useUserDeadline() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const userDeadline = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>{
        return state.user.userDeadline;
    });
    const setUserDeadline = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((deadline)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateUserDeadline */ .gw)({
            userDeadline: deadline
        }));
    }, [
        dispatch
    ]);
    return [
        userDeadline,
        setUserDeadline
    ];
}
function useAddUserToken() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((token)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .addSerializedToken */ .eg)({
            serializedToken: serializeToken(token)
        }));
    }, [
        dispatch
    ]);
}
function useRemoveUserAddedToken() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((chainId, address)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_7__/* .removeSerializedToken */ .zQ)({
            chainId,
            address
        }));
    }, [
        dispatch
    ]);
}
function useUserAddedTokens() {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const serializedTokensMap = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(({ user: { tokens  }  })=>tokens);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!chainId) return [];
        return Object.values(serializedTokensMap[chainId] ?? {}).map(deserializeToken);
    }, [
        serializedTokensMap,
        chainId
    ]);
}
function serializePair(pair) {
    return {
        token0: serializeToken(pair.token0),
        token1: serializeToken(pair.token1)
    };
}
function usePairAdder() {
    const dispatch = useDispatch();
    return useCallback((pair)=>{
        dispatch(addSerializedPair({
            serializedPair: serializePair(pair)
        }));
    }, [
        dispatch
    ]);
}
/**
 * Given two tokens return the liquidity token that represents its liquidity shares
 * @param tokenA one of the two tokens
 * @param tokenB the other token
 */ function toV2LiquidityToken([tokenA, tokenB]) {
    return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token(tokenA.chainId, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Pair.getAddress(tokenA, tokenB), 18, "Cake-LP", "Pancake LPs");
}
/**
 * Returns all the pairs of tokens that are tracked by the user for the current chain ID.
 */ function useTrackedTokenPairs() {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const tokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useAllTokens */ .e_)();
    // pinned pairs
    const pinnedPairs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>chainId ? _constants__WEBPACK_IMPORTED_MODULE_4__/* .PINNED_PAIRS */ .Q8[chainId] ?? [] : [], [
        chainId
    ]);
    // pairs for every token against every base
    const generatedPairs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>chainId ? lodash_flatmap__WEBPACK_IMPORTED_MODULE_1___default()(Object.keys(tokens), (tokenAddress)=>{
            const token = tokens[tokenAddress];
            // for each token on the current chain,
            return(// loop though all bases on the current chain
            (_constants__WEBPACK_IMPORTED_MODULE_4__/* .BASES_TO_TRACK_LIQUIDITY_FOR */ .xu[chainId] ?? [])// to construct pairs of the given token with each base
            .map((base)=>{
                if (base.address === token.address) {
                    return null;
                }
                return [
                    base,
                    token
                ];
            }).filter((p)=>p !== null));
        }) : [], [
        tokens,
        chainId
    ]);
    // pairs saved by users
    const savedSerializedPairs = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(({ user: { pairs  }  })=>pairs);
    const userPairs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!chainId || !savedSerializedPairs) return [];
        const forChain = savedSerializedPairs[chainId];
        if (!forChain) return [];
        return Object.keys(forChain).map((pairId)=>{
            return [
                deserializeToken(forChain[pairId].token0),
                deserializeToken(forChain[pairId].token1)
            ];
        });
    }, [
        savedSerializedPairs,
        chainId
    ]);
    const combinedList = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>userPairs.concat(generatedPairs).concat(pinnedPairs), [
        generatedPairs,
        pinnedPairs,
        userPairs, 
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        // dedupes pairs of tokens in the combined list
        const keyed = combinedList.reduce((memo, [tokenA, tokenB])=>{
            const sorted = tokenA.sortsBefore(tokenB);
            const key = sorted ? `${tokenA.address}:${tokenB.address}` : `${tokenB.address}:${tokenA.address}`;
            if (memo[key]) return memo;
            memo[key] = sorted ? [
                tokenA,
                tokenB
            ] : [
                tokenB,
                tokenA
            ];
            return memo;
        }, {});
        return Object.keys(keyed).map((key)=>keyed[key]);
    }, [
        combinedList
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1023:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K5": () => (/* binding */ useCurrencyBalances),
/* harmony export */   "Z": () => (/* binding */ useTokenBalances),
/* harmony export */   "_h": () => (/* binding */ useCurrencyBalance),
/* harmony export */   "mM": () => (/* binding */ useTokenBalance),
/* harmony export */   "uD": () => (/* binding */ useAllTokenBalances),
/* harmony export */   "v2": () => (/* binding */ useTokenBalancesWithLoadingIndicator)
/* harmony export */ });
/* unused harmony export useETHBalances */
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_abis_erc20__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7502);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7411);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5820);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5307);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8847);
/* harmony import */ var _multicall_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8442);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_Tokens__WEBPACK_IMPORTED_MODULE_3__, _hooks__WEBPACK_IMPORTED_MODULE_4__, _hooks_useContract__WEBPACK_IMPORTED_MODULE_5__, _multicall_hooks__WEBPACK_IMPORTED_MODULE_7__]);
([_hooks_Tokens__WEBPACK_IMPORTED_MODULE_3__, _hooks__WEBPACK_IMPORTED_MODULE_4__, _hooks_useContract__WEBPACK_IMPORTED_MODULE_5__, _multicall_hooks__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








/**
 * Returns a map of the given addresses to their eventually consistent ETH balances.
 */ function useETHBalances(uncheckedAddresses) {
    const multicallContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_5__/* .useMulticallContract */ .gq)();
    const addresses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>uncheckedAddresses ? uncheckedAddresses.map(_utils__WEBPACK_IMPORTED_MODULE_6__/* .isAddress */ .UJ).filter((a)=>a !== false).sort() : [], [
        uncheckedAddresses
    ]);
    const results = (0,_multicall_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useSingleContractMultipleData */ .es)(multicallContract, "getEthBalance", addresses.map((address)=>[
            address
        ]));
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>addresses.reduce((memo, address, i)=>{
            const value = results?.[i]?.result?.[0];
            if (value) memo[address] = _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()));
            return memo;
        }, {}), [
        addresses,
        results
    ]);
}
/**
 * Returns a map of token addresses to their eventually consistent token balances for a single account.
 */ function useTokenBalancesWithLoadingIndicator(address, tokens) {
    const validatedTokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>tokens?.filter((t)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .isAddress */ .UJ)(t?.address) !== false) ?? [], [
        tokens
    ]);
    const validatedTokenAddresses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>validatedTokens.map((vt)=>vt.address), [
        validatedTokens
    ]);
    const balances = (0,_multicall_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useMultipleContractSingleData */ ._Y)(validatedTokenAddresses, _constants_abis_erc20__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, "balanceOf", [
        address
    ]);
    const anyLoading = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>balances.some((callState)=>callState.loading), [
        balances
    ]);
    return [
        (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>address && validatedTokens.length > 0 ? validatedTokens.reduce((memo, token, i)=>{
                const value = balances?.[i]?.result?.[0];
                const amount = value ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()) : undefined;
                if (amount) {
                    memo[token.address] = new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, amount);
                }
                return memo;
            }, {}) : {}, [
            address,
            validatedTokens,
            balances
        ]),
        anyLoading
    ];
}
function useTokenBalances(address, tokens) {
    return useTokenBalancesWithLoadingIndicator(address, tokens)[0];
}
// get the balance for a single token/account combo
function useTokenBalance(account, token) {
    const tokenBalances = useTokenBalances(account, [
        token
    ]);
    if (!token) return undefined;
    return tokenBalances[token.address];
}
function useCurrencyBalances(account, currencies) {
    const tokens = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>currencies?.filter((currency)=>currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token) ?? [], [
        currencies
    ]);
    const tokenBalances = useTokenBalances(account, tokens);
    const containsETH = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>currencies?.some((currency)=>currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) ?? false, [
        currencies
    ]);
    const ethBalance = useETHBalances(containsETH ? [
        account
    ] : []);
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>currencies?.map((currency)=>{
            if (!account || !currency) return undefined;
            if (currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token) return tokenBalances[currency.address];
            if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) return ethBalance[account];
            return undefined;
        }) ?? [], [
        account,
        currencies,
        ethBalance,
        tokenBalances
    ]);
}
function useCurrencyBalance(account, currency) {
    return useCurrencyBalances(account, [
        currency
    ])[0];
}
// mimics useAllBalances
function useAllTokenBalances() {
    const { account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useActiveWeb3React */ .aQ)();
    const allTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_3__/* .useAllTokens */ .e_)();
    const allTokensArray = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>Object.values(allTokens ?? {}), [
        allTokens
    ]);
    const balances = useTokenBalances(account ?? undefined, allTokensArray);
    return balances ?? {};
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bv": () => (/* binding */ unwrappedToken),
/* harmony export */   "N": () => (/* binding */ wrappedCurrencyAmount),
/* harmony export */   "pu": () => (/* binding */ wrappedCurrency)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);

function wrappedCurrency(currency, chainId) {
    // eslint-disable-next-line no-nested-ternary
    return chainId && currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[chainId] : currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Token ? currency : undefined;
}
function wrappedCurrencyAmount(currencyAmount, chainId) {
    const token = currencyAmount && chainId ? wrappedCurrency(currencyAmount.currency, chainId) : undefined;
    return token && currencyAmount ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, currencyAmount.raw) : undefined;
}
function unwrappedToken(token) {
    if (token.equals(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[token.chainId])) return _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER;
    return token;
}


/***/ })

};
;