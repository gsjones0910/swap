"use strict";
exports.id = 7613;
exports.ids = [7613];
exports.modules = {

/***/ 1845:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1158);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_user_hooks__WEBPACK_IMPORTED_MODULE_3__]);
_state_user_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AudioSetting = ({ translateString  })=>{
    const { isSm , isXs  } = (0,_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.useMatchBreakpoints)();
    const [audioPlay, toggleSetAudioMode] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useAudioModeManager */ .TO)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
        mb: "16px",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                alignItems: "center",
                mb: "8px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                    bold: true,
                    children: translateString(999, "Audio")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.PancakeToggle, {
                    scale: isSm || isXs ? "sm" : "md",
                    checked: audioPlay,
                    onChange: toggleSetAudioMode
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AudioSetting);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5015:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5820);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8847);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7507);
/* harmony import */ var _components_Loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9620);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_3__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks__WEBPACK_IMPORTED_MODULE_3__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// TODO: Fix UI Kit typings
const defaultOnDismiss = ()=>null;
const newTransactionsFirst = (a, b)=>b.addedTime - a.addedTime;
const getRowStatus = (sortedRecentTransaction)=>{
    const { hash , receipt  } = sortedRecentTransaction;
    if (!hash) {
        return {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            color: "text"
        };
    }
    if (hash && receipt?.status === 1) {
        return {
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.CheckmarkCircleIcon, {
                color: "success"
            }),
            color: "success"
        };
    }
    return {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.ErrorIcon, {
            color: "failure"
        }),
        color: "failure"
    };
};
const RecentTransactionsModal = ({ onDismiss =defaultOnDismiss , translateString  })=>{
    const { account , chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActiveWeb3React */ .aQ)();
    const allTransactions = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useAllTransactions */ .kf)();
    // Logic taken from Web3Status/index.tsx line 175
    const sortedRecentTransactions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const txs = Object.values(allTransactions);
        return txs.filter(_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_5__/* .isTransactionRecent */ .mH).sort(newTransactionsFirst);
    }, [
        allTransactions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: translateString(1202, "Recent transactions") + "sss",
        onDismiss: onDismiss,
        children: [
            !account && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        mb: "8px",
                        bold: true,
                        children: "Please connect your wallet to view your recent transactions"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "tertiary",
                        scale: "sm",
                        onClick: onDismiss,
                        children: "Close"
                    })
                ]
            }),
            account && chainId && sortedRecentTransactions.length === 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        mb: "8px",
                        bold: true,
                        children: "No recent transactions"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        variant: "tertiary",
                        scale: "sm",
                        onClick: onDismiss,
                        children: "Close"
                    })
                ]
            }),
            account && chainId && sortedRecentTransactions.map((sortedRecentTransaction)=>{
                const { hash , summary  } = sortedRecentTransaction;
                const { icon , color  } = getRowStatus(sortedRecentTransaction);
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                        alignItems: "center",
                        justifyContent: "space-between",
                        mb: "4px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.LinkExternal, {
                                href: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .getBscScanLink */ .s6)(chainId, hash, "transaction"),
                                color: color,
                                children: summary ?? hash
                            }),
                            icon
                        ]
                    }, hash)
                });
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RecentTransactionsModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5168:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SlippageToleranceSetting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7840);
/* harmony import */ var _TransactionDeadlineSetting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7864);
/* harmony import */ var _AudioSetting__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1845);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SlippageToleranceSetting__WEBPACK_IMPORTED_MODULE_3__, _TransactionDeadlineSetting__WEBPACK_IMPORTED_MODULE_4__, _AudioSetting__WEBPACK_IMPORTED_MODULE_5__]);
([_SlippageToleranceSetting__WEBPACK_IMPORTED_MODULE_3__, _TransactionDeadlineSetting__WEBPACK_IMPORTED_MODULE_4__, _AudioSetting__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// TODO: Fix UI Kit typings
const defaultOnDismiss = ()=>null;
const SettingsModal = ({ onDismiss =defaultOnDismiss , translateString  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Modal, {
        title: translateString(1200, "Settings"),
        onDismiss: onDismiss,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SlippageToleranceSetting__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                translateString: translateString
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TransactionDeadlineSetting__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                translateString: translateString
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AudioSetting__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                translateString: translateString
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7840:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1158);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3994);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__]);
_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const MAX_SLIPPAGE = 5000;
const RISKY_SLIPPAGE_LOW = 50;
const RISKY_SLIPPAGE_HIGH = 500;
const Option = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-a888737c-0"
})`
  padding: 0 4px;
`;
const Options = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-a888737c-1"
})`
  align-items: center;
  display: flex;
  flex-direction: column;

  ${Option}:first-child {
    padding-left: 0;
  }

  ${Option}:last-child {
    padding-right: 0;
  }

  ${({ theme  })=>theme.mediaQueries.sm} {
    flex-direction: row;
  }
`;
const predefinedValues = [
    {
        label: "0.1%",
        value: 0.1
    },
    {
        label: "0.5%",
        value: 0.5
    },
    {
        label: "1%",
        value: 1
    }, 
];
const SlippageToleranceSettings = ({ translateString  })=>{
    const [userSlippageTolerance, setUserslippageTolerance] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useUserSlippageTolerance */ .$2)();
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(userSlippageTolerance / 100);
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleChange = (evt)=>{
        const { value: inputValue  } = evt.target;
        setValue(parseFloat(inputValue));
    };
    // Updates local storage if value is valid
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        try {
            const rawValue = value * 100;
            if (!Number.isNaN(rawValue) && rawValue > 0 && rawValue < MAX_SLIPPAGE) {
                setUserslippageTolerance(rawValue);
                setError(null);
            } else {
                setError(translateString(1144, "Enter a valid slippage percentage"));
            }
        } catch  {
            setError(translateString(1144, "Enter a valid slippage percentage"));
        }
    }, [
        value,
        setError,
        setUserslippageTolerance,
        translateString
    ]);
    // Notify user if slippage is risky
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (userSlippageTolerance < RISKY_SLIPPAGE_LOW) {
            setError(translateString(1146, "Your transaction may fail"));
        } else if (userSlippageTolerance > RISKY_SLIPPAGE_HIGH) {
            setError(translateString(1148, "Your transaction may be frontrun"));
        }
    }, [
        userSlippageTolerance,
        setError,
        translateString
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        mb: "16px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                mb: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: translateString(88, "Slippage tolerance")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: translateString(186, "Your transaction will revert if the price changes unfavorably by more than this percentage.")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Options, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        mb: [
                            "8px",
                            "8px",
                            0
                        ],
                        mr: [
                            0,
                            0,
                            "8px"
                        ],
                        children: predefinedValues.map(({ label , value: predefinedValue  })=>{
                            const handleClick = ()=>setValue(predefinedValue);
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                    variant: value === predefinedValue ? "primary" : "tertiary",
                                    onClick: handleClick,
                                    children: label
                                })
                            }, predefinedValue);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                    type: "number",
                                    scale: "lg",
                                    step: 0.1,
                                    min: 0.1,
                                    placeholder: "5%",
                                    value: value,
                                    onChange: handleChange,
                                    isWarning: error !== null
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                    fontSize: "18px",
                                    children: "%"
                                })
                            })
                        ]
                    })
                ]
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                mt: "8px",
                color: "failure",
                children: error
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SlippageToleranceSettings);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7864:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1158);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3994);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__]);
_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Field = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-6ad45f51-0"
})`
  align-items: center;
  display: inline-flex;

  & > ${_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Input} {
    max-width: 100px;
  }
`;
const TransactionDeadlineSetting = ({ translateString  })=>{
    const [deadline, setDeadline] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useUserDeadline */ .Td)();
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(deadline / 60) // deadline in minutes
    ;
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleChange = (evt)=>{
        const { value: inputValue  } = evt.target;
        setValue(parseInt(inputValue, 10));
    };
    // Updates local storage if value is valid
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        try {
            const rawValue = value * 60;
            if (!Number.isNaN(rawValue) && rawValue > 0) {
                setDeadline(rawValue);
                setError(null);
            } else {
                setError(translateString(1150, "Enter a valid deadline"));
            }
        } catch  {
            setError(translateString(1150, "Enter a valid deadline"));
        }
    }, [
        value,
        setError,
        setDeadline,
        translateString
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Box, {
        mb: "16px",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                mb: "8px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        bold: true,
                        children: translateString(90, "Transaction deadline")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: translateString(188, "Your transaction will revert if it is pending for more than this long.")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Field, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Input, {
                        type: "number",
                        step: "1",
                        min: "1",
                        value: value,
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                        fontSize: "14px",
                        ml: "8px",
                        children: "Minutes"
                    })
                ]
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                mt: "8px",
                color: "failure",
                children: error
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionDeadlineSetting);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7613:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useI18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(117);
/* harmony import */ var _SettingsModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5168);
/* harmony import */ var _RecentTransactionsModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SettingsModal__WEBPACK_IMPORTED_MODULE_5__, _RecentTransactionsModal__WEBPACK_IMPORTED_MODULE_6__]);
([_SettingsModal__WEBPACK_IMPORTED_MODULE_5__, _RecentTransactionsModal__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const StyledPageHeader = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-81bd4b14-0"
})`
  max-width: 640px;
  padding-left: 30px;
  padding-right: 30px;

  width: 100%;
`;
const Details = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-81bd4b14-1"
})`
  flex: 1;
`;
const PageHeader = ({ title , description , children  })=>{
    const TranslateString = (0,_hooks_useI18n__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const [onPresentSettings] = (0,_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SettingsModal__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        translateString: TranslateString
    }));
    const [onPresentRecentTransactions] = (0,_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.useModal)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RecentTransactionsModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        translateString: TranslateString
    }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledPageHeader, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Flex, {
                alignItems: "center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Details, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-2xl tracking-tighter font-bold uppercase",
                            children: title
                        }),
                        description && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-[14px] font-medium mt-2",
                            children: description
                        })
                    ]
                })
            }),
            children && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                mt: "16px",
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageHeader);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_TranslationsContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7749);
/* harmony import */ var _utils_translateTextHelpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3378);



const useI18n = ()=>{
    const { translations  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_hooks_TranslationsContext__WEBPACK_IMPORTED_MODULE_1__/* .TranslationsContext */ .y);
    /**
   * As a temporary fix memoize the translation function so it can be used in an effect.
   * It appears the TranslationsContext is always empty and is not currently used
   * TODO: Figure out if the context is used and if not, remove it.
   */ return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((translationId, fallback)=>{
        if (translations[0] === "error") {
            return fallback;
        }
        if (translations.length > 0) {
            return (0,_utils_translateTextHelpers__WEBPACK_IMPORTED_MODULE_2__/* .getTranslation */ .i)(translations, translationId, fallback);
        }
        return fallback;
    }, [
        translations
    ]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useI18n);


/***/ })

};
;