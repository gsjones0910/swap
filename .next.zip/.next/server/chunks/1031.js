"use strict";
exports.id = 1031;
exports.ids = [1031];
exports.modules = {

/***/ 1031:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useWrapCallback),
/* harmony export */   "k": () => (/* binding */ WrapType)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_swap_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8298);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7507);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1023);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5820);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5307);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_swap_hooks__WEBPACK_IMPORTED_MODULE_2__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_3__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_5__, _useContract__WEBPACK_IMPORTED_MODULE_6__]);
([_state_swap_hooks__WEBPACK_IMPORTED_MODULE_2__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_3__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_4__, _index__WEBPACK_IMPORTED_MODULE_5__, _useContract__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







var WrapType;
(function(WrapType) {
    WrapType[WrapType["NOT_APPLICABLE"] = 0] = "NOT_APPLICABLE";
    WrapType[WrapType["WRAP"] = 1] = "WRAP";
    WrapType[WrapType["UNWRAP"] = 2] = "UNWRAP";
})(WrapType || (WrapType = {}));
const NOT_APPLICABLE = {
    wrapType: WrapType.NOT_APPLICABLE
};
/**
 * Given the selected input and output currency, return a wrap callback
 * @param inputCurrency the selected input currency
 * @param outputCurrency the selected output currency
 * @param typedValue the user input value
 */ function useWrapCallback(inputCurrency, outputCurrency, typedValue) {
    const { chainId , account  } = (0,_index__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const wethContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_6__/* .useWETHContract */ .Hj)();
    const balance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useCurrencyBalance */ ._h)(account ?? undefined, inputCurrency);
    // we can always parse the amount typed as the input currency, since wrapping is 1:1
    const inputAmount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>(0,_state_swap_hooks__WEBPACK_IMPORTED_MODULE_2__/* .tryParseAmount */ .eo)(typedValue, inputCurrency), [
        inputCurrency,
        typedValue
    ]);
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTransactionAdder */ .h7)();
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!wethContract || !chainId || !inputCurrency || !outputCurrency) return NOT_APPLICABLE;
        const sufficientBalance = inputAmount && balance && !balance.lessThan(inputAmount);
        if (inputCurrency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER && (0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.currencyEquals)(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[chainId], outputCurrency)) {
            return {
                wrapType: WrapType.WRAP,
                execute: sufficientBalance && inputAmount ? async ()=>{
                    try {
                        const txReceipt = await wethContract.deposit({
                            value: `0x${inputAmount.raw.toString(16)}`
                        });
                        addTransaction(txReceipt, {
                            summary: `Wrap ${inputAmount.toSignificant(6)} BNB to WBNB`
                        });
                    } catch (error) {
                        console.error("Could not deposit", error);
                    }
                } : undefined,
                inputError: sufficientBalance ? undefined : "Insufficient BNB balance"
            };
        }
        if ((0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.currencyEquals)(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.WETH[chainId], inputCurrency) && outputCurrency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) {
            return {
                wrapType: WrapType.UNWRAP,
                execute: sufficientBalance && inputAmount ? async ()=>{
                    try {
                        const txReceipt = await wethContract.withdraw(`0x${inputAmount.raw.toString(16)}`);
                        addTransaction(txReceipt, {
                            summary: `Unwrap ${inputAmount.toSignificant(6)} WBNB to BNB`
                        });
                    } catch (error) {
                        console.error("Could not withdraw", error);
                    }
                } : undefined,
                inputError: sufficientBalance ? undefined : "Insufficient WBNB balance"
            };
        }
        return NOT_APPLICABLE;
    }, [
        wethContract,
        chainId,
        inputCurrency,
        outputCurrency,
        inputAmount,
        balance,
        addTransaction
    ]);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;