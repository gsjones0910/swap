"use strict";
exports.id = 5430;
exports.ids = [5430];
exports.modules = {

/***/ 5430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JF": () => (/* binding */ SectionBreak),
/* harmony export */   "bb": () => (/* binding */ Dots),
/* harmony export */   "fv": () => (/* binding */ BottomGrouping),
/* harmony export */   "im": () => (/* binding */ Wrapper),
/* harmony export */   "k0": () => (/* binding */ StyledBalanceMaxMini),
/* harmony export */   "ly": () => (/* binding */ SwapShowAcceptChanges),
/* harmony export */   "nR": () => (/* binding */ ArrowWrapper),
/* harmony export */   "rn": () => (/* binding */ SwapCallbackError),
/* harmony export */   "y": () => (/* binding */ ErrorText)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2042);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(polished__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(247);







const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-0"
})`
  position: relative;
`;
const ArrowWrapper = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-1"
})`
  padding: 2px;

  ${({ clickable  })=>clickable ? styled_components__WEBPACK_IMPORTED_MODULE_5__.css`
          :hover {
            cursor: pointer;
            opacity: 0.8;
          }
        ` : null}
`;
const SectionBreak = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-2"
})`
  height: 1px;
  width: 100%;
  background-color: ${({ theme  })=>theme.colors.tertiary};
`;
const BottomGrouping = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-3"
})`
  margin-top: 1rem;
`;
const ErrorText = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text).withConfig({
    componentId: "sc-9bc2d81c-4"
})`
  color: ${({ theme , severity  })=>severity === 3 || severity === 4 ? theme.colors.failure : severity === 2 ? theme.colors.binance : severity === 1 ? theme.colors.text : theme.colors.success};
`;
const StyledBalanceMaxMini = styled_components__WEBPACK_IMPORTED_MODULE_5___default().button.withConfig({
    componentId: "sc-9bc2d81c-5"
})`
  height: 22px;
  width: 22px;
  background-color: ${({ theme  })=>theme.colors.invertedContrast};
  border: none;
  border-radius: 50%;
  padding: 0.2rem;
  font-size: 0.875rem;
  font-weight: 400;
  margin-left: 0.4rem;
  cursor: pointer;
  color: ${({ theme  })=>theme.colors.textSubtle};
  display: flex;
  justify-content: center;
  align-items: center;
  float: right;

  :hover {
    background-color: ${({ theme  })=>theme.colors.tertiary};
  }
  :focus {
    background-color: ${({ theme  })=>theme.colors.tertiary};
    outline: none;
  }
`;
// styles
const Dots = styled_components__WEBPACK_IMPORTED_MODULE_5___default().span.withConfig({
    componentId: "sc-9bc2d81c-6"
})`
  &::after {
    display: inline-block;
    animation: ellipsis 1.25s infinite;
    content: '.';
    width: 1em;
    text-align: left;
  }
  @keyframes ellipsis {
    0% {
      content: '.';
    }
    33% {
      content: '..';
    }
    66% {
      content: '...';
    }
  }
`;
const SwapCallbackErrorInner = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-7"
})`
  background-color: ${({ theme  })=>(0,polished__WEBPACK_IMPORTED_MODULE_1__.transparentize)(0.9, theme.colors.failure)};
  border-radius: 1rem;
  display: flex;
  align-items: center;
  font-size: 0.825rem;
  width: 100%;
  padding: 3rem 1.25rem 1rem 1rem;
  margin-top: -2rem;
  color: ${({ theme  })=>theme.colors.failure};
  z-index: -1;
  p {
    padding: 0;
    margin: 0;
    font-weight: 500;
  }
`;
const SwapCallbackErrorInnerAlertTriangle = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-9bc2d81c-8"
})`
  background-color: ${({ theme  })=>(0,polished__WEBPACK_IMPORTED_MODULE_1__.transparentize)(0.9, theme.colors.failure)};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  border-radius: 12px;
  min-width: 48px;
  height: 48px;
`;
function SwapCallbackError({ error  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SwapCallbackErrorInner, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SwapCallbackErrorInnerAlertTriangle, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_3__.AlertTriangle, {
                    size: 24
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: error
            })
        ]
    });
}
const SwapShowAcceptChanges = styled_components__WEBPACK_IMPORTED_MODULE_5___default()(_Column__WEBPACK_IMPORTED_MODULE_6__/* .AutoColumn */ .Tz).withConfig({
    componentId: "sc-9bc2d81c-9"
})`
  background-color: ${({ theme  })=>(0,polished__WEBPACK_IMPORTED_MODULE_1__.transparentize)(0.9, theme.colors.primary)};
  color: ${({ theme  })=>theme.colors.primary};
  padding: 0.5rem;
  border-radius: 12px;
  margin-top: 8px;
`;


/***/ })

};
;