"use strict";
exports.id = 3664;
exports.ids = [3664];
exports.modules = {

/***/ 9371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgViewscan = function SvgViewscan(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 10,
    height: 10,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M3.889 0v1.05H1.11v7.345H8.89V5.772H10V8.92a.51.51 0 0 1-.163.37.573.573 0 0 1-.393.154H.556a.573.573 0 0 1-.393-.153A.51.51 0 0 1 0 8.92V.525A.51.51 0 0 1 .163.154.573.573 0 0 1 .556 0h3.333Zm4.214 1.05H5.556V0H10v4.198H8.889V1.79L5 5.464l-.786-.742 3.89-3.673Z",
    fill: "#3985F5"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgViewscan);

/***/ }),

/***/ 3752:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Notification */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Notification = ({ children , show , setShow  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (show) setTimeout(()=>setShow(false), 2000);
    }, [
        show,
        setShow
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${show ? "opacity-100" : "opacity-0"} transition ease-in duration-500 mx-auto absolute top-[110px]`,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Notification);


/***/ }),

/***/ 4353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Pane = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-f840bac3-0"
})`
  border: 2px solid ${({ theme  })=>theme.colors.borderColor};
  border-radius: 16px;
  padding: 16px;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pane);


/***/ }),

/***/ 3664:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AddLiquidity)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5757);
/* harmony import */ var _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_Card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2882);
/* harmony import */ var _components_Column__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(247);
/* harmony import */ var _components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6002);
/* harmony import */ var _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9963);
/* harmony import */ var _components_DoubleLogo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3976);
/* harmony import */ var _components_NavigationTabs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_Row__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(108);
/* harmony import */ var _data_Reserves__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4213);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5820);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7411);
/* harmony import */ var _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2945);
/* harmony import */ var _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8149);
/* harmony import */ var _state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8731);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7507);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1158);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8847);
/* harmony import */ var _utils_maxAmountSpend__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9687);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(5354);
/* harmony import */ var _utils_currencyId__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(5450);
/* harmony import */ var _components_Pane__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4353);
/* harmony import */ var _components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(6089);
/* harmony import */ var _components_Notification__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(3752);
/* harmony import */ var _AppBody__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(4799);
/* harmony import */ var _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(5182);
/* harmony import */ var _PoolPriceBar__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(111);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(1407);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(6921);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _components_Scrolling__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(5791);
/* harmony import */ var _components_Navbar__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(8010);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(2604);
/* harmony import */ var _components_Preloader_Preloader__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(7590);
/* harmony import */ var _assets_viewscan_svg__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(9371);
/* harmony import */ var _components_RateSetModal__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(9296);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_8__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_9__, _components_DoubleLogo__WEBPACK_IMPORTED_MODULE_10__, _data_Reserves__WEBPACK_IMPORTED_MODULE_14__, _hooks__WEBPACK_IMPORTED_MODULE_15__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_16__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__, _state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_20__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_21__, _components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_27__, _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_30__, _components_Navbar__WEBPACK_IMPORTED_MODULE_36__]);
([_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_8__, _components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_9__, _components_DoubleLogo__WEBPACK_IMPORTED_MODULE_10__, _data_Reserves__WEBPACK_IMPORTED_MODULE_14__, _hooks__WEBPACK_IMPORTED_MODULE_15__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_16__, _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__, _state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_20__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_21__, _components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_27__, _ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_30__, _components_Navbar__WEBPACK_IMPORTED_MODULE_36__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









































const Dots = styled_components__WEBPACK_IMPORTED_MODULE_5___default().span.withConfig({
    componentId: "sc-3c841289-0"
})`
  &::after {
    display: inline-block;
    animation: ellipsis 1.25s infinite;
    content: '.';
    width: 1em;
    text-align: left;
  }
  @keyframes ellipsis {
    0% {
      content: '.';
    }
    33% {
      content: '..';
    }
    66% {
      content: '...';
    }
  }
`;
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_5___default().div.withConfig({
    componentId: "sc-3c841289-1"
})`
  position: relative;
`;
function AddLiquidity({ currencyIdA , currencyIdB  }) {
    const { account , chainId , library  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_15__/* .useActiveWeb3React */ .aQ)();
    const currencyA = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_16__/* .useCurrency */ .U8)(currencyIdA);
    const currencyB = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_16__/* .useCurrency */ .U8)(currencyIdB);
    const history = (0,next_router__WEBPACK_IMPORTED_MODULE_33__.useRouter)();
    const oneCurrencyIsWBNB = Boolean(chainId && (currencyA && (0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.currencyEquals)(currencyA, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.WETH[chainId]) || currencyB && (0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.currencyEquals)(currencyB, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.WETH[chainId])));
    const expertMode = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_21__/* .useIsExpertMode */ .LO)();
    // mint state
    const { independentField , typedValue , otherTypedValue  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__/* .useMintState */ .OY)();
    const { dependentField , currencies , pair , pairState , currencyBalances , parsedAmounts , price , noLiquidity , liquidityMinted , poolTokenPercentage , error ,  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__/* .useDerivedMintInfo */ .Qw)(currencyA ?? undefined, currencyB ?? undefined);
    const { onFieldAInput , onFieldBInput  } = (0,_state_mint_hooks__WEBPACK_IMPORTED_MODULE_19__/* .useMintActionHandlers */ .OA)(noLiquidity);
    const isValid = !error;
    // modal and loading
    const { 0: showConfirm , 1: setShowConfirm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: attemptingTxn , 1: setAttemptingTxn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false) // clicked confirm
    ;
    // txn values
    const [deadline] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_21__/* .useUserDeadline */ .Td)() // custom from users settings
    ;
    const [allowedSlippage] = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_21__/* .useUserSlippageTolerance */ .$2)() // custom from users
    ;
    const { 0: txHash , 1: setTxHash  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const { 0: eventsModalOpen , 1: setEventsModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const eventsModalOpenHandler = ()=>{
        setEventsModalOpen(true);
    };
    const eventsModalCloseHandler = ()=>{
        setEventsModalOpen(false);
    };
    // get formatted amounts
    const formattedAmounts = {
        [independentField]: typedValue,
        [dependentField]: noLiquidity ? otherTypedValue : parsedAmounts[dependentField]?.toSignificant(6) ?? ""
    };
    // get the max amounts user can add
    const maxAmounts = [
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B
    ].reduce((accumulator, field)=>{
        return {
            ...accumulator,
            [field]: (0,_utils_maxAmountSpend__WEBPACK_IMPORTED_MODULE_23__/* .maxAmountSpend */ .i)(currencyBalances[field])
        };
    }, {});
    const atMaxAmounts = [
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
        _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B
    ].reduce((accumulator, field)=>{
        return {
            ...accumulator,
            [field]: maxAmounts[field]?.equalTo(parsedAmounts[field] ?? "0")
        };
    }, {});
    // check whether the user has approved the router on the tokens
    const [approvalA, approveACallback] = (0,_hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .useApproveCallback */ .qL)(parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A], _constants__WEBPACK_IMPORTED_MODULE_32__/* .ROUTER_ADDRESS */ .bR);
    const [approvalB, approveBCallback] = (0,_hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .useApproveCallback */ .qL)(parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B], _constants__WEBPACK_IMPORTED_MODULE_32__/* .ROUTER_ADDRESS */ .bR);
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_20__/* .useTransactionAdder */ .h7)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED || approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED) setShow(true);
    }, [
        approvalA,
        approvalB
    ]);
    async function onAdd() {
        if (!chainId || !library || !account) return;
        const router = (0,_utils__WEBPACK_IMPORTED_MODULE_22__/* .getRouterContract */ .iY)(chainId, library, account);
        const { [_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: parsedAmountA , [_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: parsedAmountB  } = parsedAmounts;
        if (!parsedAmountA || !parsedAmountB || !currencyA || !currencyB) {
            return;
        }
        const amountsMin = {
            [_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: (0,_utils__WEBPACK_IMPORTED_MODULE_22__/* .calculateSlippageAmount */ .uc)(parsedAmountA, noLiquidity ? 0 : allowedSlippage)[0],
            [_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: (0,_utils__WEBPACK_IMPORTED_MODULE_22__/* .calculateSlippageAmount */ .uc)(parsedAmountB, noLiquidity ? 0 : allowedSlippage)[0]
        };
        const deadlineFromNow = Math.ceil(Date.now() / 1000) + deadline;
        let estimate;
        let method;
        let args;
        let value;
        if (currencyA === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER || currencyB === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER) {
            const tokenBIsBNB = currencyB === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER;
            estimate = router.estimateGas.addLiquidityETH;
            method = router.addLiquidityETH;
            args = [
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_24__/* .wrappedCurrency */ .pu)(tokenBIsBNB ? currencyA : currencyB, chainId)?.address ?? "",
                (tokenBIsBNB ? parsedAmountA : parsedAmountB).raw.toString(),
                amountsMin[tokenBIsBNB ? _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A : _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B].toString(),
                amountsMin[tokenBIsBNB ? _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B : _state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A].toString(),
                account,
                deadlineFromNow, 
            ];
            value = _ethersproject_bignumber__WEBPACK_IMPORTED_MODULE_2__.BigNumber.from((tokenBIsBNB ? parsedAmountB : parsedAmountA).raw.toString());
        } else {
            estimate = router.estimateGas.addLiquidity;
            method = router.addLiquidity;
            args = [
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_24__/* .wrappedCurrency */ .pu)(currencyA, chainId)?.address ?? "",
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_24__/* .wrappedCurrency */ .pu)(currencyB, chainId)?.address ?? "",
                parsedAmountA.raw.toString(),
                parsedAmountB.raw.toString(),
                amountsMin[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A].toString(),
                amountsMin[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B].toString(),
                account,
                deadlineFromNow, 
            ];
            value = null;
        }
        setAttemptingTxn(true);
        // const aa = await estimate(...args, value ? { value } : {})
        await estimate(...args, value ? {
            value
        } : {}).then((estimatedGasLimit)=>method(...args, {
                ...value ? {
                    value
                } : {},
                gasLimit: (0,_utils__WEBPACK_IMPORTED_MODULE_22__/* .calculateGasMargin */ .yC)(estimatedGasLimit)
            }).then((response)=>{
                setAttemptingTxn(false);
                addTransaction(response, {
                    summary: `Add ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toSignificant(3)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol} and ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toSignificant(3)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                });
                setTxHash(response.hash);
            })).catch((e)=>{
            setAttemptingTxn(false);
            // we only care if the error is something _other_ than the user rejected the tx
            if (e?.code !== 4001) {
                console.error(e);
            }
        });
    }
    const modalHeader = ()=>{
        return noLiquidity ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
            gap: "20px",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Card__WEBPACK_IMPORTED_MODULE_6__/* .LightCard */ .hl, {
                mt: "20px",
                borderRadius: "20px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFlat */ .v3, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            fontSize: "48px",
                            mr: "8px",
                            children: `${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}/${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DoubleLogo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            currency0: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                            currency1: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                            size: 30
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
            gap: "20px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFlat */ .v3, {
                    style: {
                        marginTop: "20px"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                            fontSize: "48px",
                            mr: "8px",
                            children: liquidityMinted?.toSignificant(6)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DoubleLogo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            currency0: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                            currency1: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                            size: 30
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Row__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                        fontSize: "24px",
                        children: `${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}/${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol} Pool Tokens`
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                    small: true,
                    textAlign: "left",
                    padding: "8px 0 0 0 ",
                    style: {
                        fontStyle: "italic"
                    },
                    children: `Output is estimated. If the price changes by more than ${allowedSlippage / 100}% your transaction will revert.`
                })
            ]
        });
    };
    const modalBottom = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ConfirmAddModalBottom__WEBPACK_IMPORTED_MODULE_30__.ConfirmAddModalBottom, {
            price: price,
            currencies: currencies,
            parsedAmounts: parsedAmounts,
            noLiquidity: noLiquidity,
            onAdd: onAdd,
            poolTokenPercentage: poolTokenPercentage
        });
    };
    const pendingText = `Supplying ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toSignificant(6)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol} and ${parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toSignificant(6)} ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`;
    const handleCurrencyASelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currA)=>{
        const newCurrencyIdA = (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_25__/* .currencyId */ .H)(currA);
        if (newCurrencyIdA === currencyIdB) {
            history.push(`/AddLiquidity/${currencyIdB}/${currencyIdA}`);
        } else {
            history.push(`/AddLiquidity/${newCurrencyIdA}/${currencyIdB}`);
        }
    }, [
        currencyIdB,
        history,
        currencyIdA
    ]);
    const handleCurrencyBSelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currB)=>{
        const newCurrencyIdB = (0,_utils_currencyId__WEBPACK_IMPORTED_MODULE_25__/* .currencyId */ .H)(currB);
        if (currencyIdA === newCurrencyIdB) {
            if (currencyIdB) {
                history.push(`/AddLiquidity/${currencyIdB}/${newCurrencyIdB}`);
            } else {
                history.push(`/AddLiquidity/${newCurrencyIdB}`);
            }
        } else {
            history.push(`/AddLiquidity/${currencyIdA || "BNB"}/${newCurrencyIdB}`);
        }
    }, [
        currencyIdA,
        history,
        currencyIdB
    ]);
    const handleDismissConfirmation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setShowConfirm(false);
        // if there was a tx hash, we want to clear the input
        if (txHash) {
            onFieldAInput("");
        }
        setTxHash("");
    }, [
        onFieldAInput,
        txHash
    ]);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { user  } = (0,react_moralis__WEBPACK_IMPORTED_MODULE_34__.useMoralis)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Preloader_Preloader__WEBPACK_IMPORTED_MODULE_38__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "lg:block hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Scrolling__WEBPACK_IMPORTED_MODULE_35__/* .Scrolling */ .P, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative flex flex-col items-center justify-between w-full min-h-screen pt-6 mx-auto overflow-x-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Navbar__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z, {
                        setIsLoading: setIsLoading
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full px-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "px-3 w-full",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "bg-[#ffffff] rounded-md px-5 pb-3 pt-3 stripe_rate_btn mt-7",
                                    onClick: eventsModalOpenHandler,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/assets/btn_stripe.png",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: " tracking-wide",
                                            children: "SET RATE FOR STRIPE"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "bg-[#ffffff] rounded-md px-5 pb-3 pt-3 stripe_rate_btn mt-2",
                                    onClick: eventsModalOpenHandler,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/assets/history.png",
                                            alt: "no image",
                                            className: "w-[26px] h-[22px]"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "tracking-wide",
                                            children: "TRANSACTION HISTORY"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-2 flex justify-center w-full xl:-mt-5 mt-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex bg-gray-300 rounded xl:-mt-5 mt-5 sm:max-w-screen-sm max-w-[460px] w-full sm:w-full border-4 border-[#BFBFD1]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center justify-center h-20 bg-#BFBFD1 rounded w-1/2 font-bold text-2xl text-white cursor-pointer uppercase",
                                        children: "Swap"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                                    href: "liquidity",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center justify-center h-20 rounded w-1/2 bg-white text-[#3985F5] font-bold text-2xl tracking-wider cursor-pointer uppercase",
                                        children: "Liquidity"
                                    })
                                })
                            ]
                        })
                    }),
                    user && user.attributes.isSuperAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_AppBody__WEBPACK_IMPORTED_MODULE_29__["default"], {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_NavigationTabs__WEBPACK_IMPORTED_MODULE_11__/* .AddRemoveTabs */ .w, {
                                    adding: true
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                                            isOpen: showConfirm,
                                            onDismiss: handleDismissConfirmation,
                                            attemptingTxn: attemptingTxn,
                                            hash: txHash,
                                            content: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_8__/* .ConfirmationModalContent */ .pM, {
                                                    title: noLiquidity ? "You are creating a pool" : "You will receive",
                                                    onDismiss: handleDismissConfirmation,
                                                    topContent: modalHeader,
                                                    bottomContent: modalBottom
                                                }),
                                            pendingText: pendingText
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.CardBody, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
                                                gap: "12px",
                                                children: [
                                                    noLiquidity && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .ColumnCenter */ .lg, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Pane__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
                                                                gap: "12px",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                                        color: "black",
                                                                        children: "You are the first liquidity provider."
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                                        color: "black",
                                                                        children: "The ratio of tokens you add will set the price of this pool."
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                                        color: "black",
                                                                        children: "Once you are happy with the rate click supply to review."
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        value: formattedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                                        onUserInput: onFieldAInput,
                                                        onMax: ()=>{
                                                            onFieldAInput(maxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.toExact() ?? "");
                                                        },
                                                        onCurrencySelect: handleCurrencyASelect,
                                                        showMaxButton: !atMaxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                                        currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
                                                        id: "add-liquidity-input-tokena",
                                                        showCommonBases: false
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .ColumnCenter */ .lg, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.AddIcon, {
                                                            color: "textSubtle"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyInputPanel__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                        value: formattedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                                        onUserInput: onFieldBInput,
                                                        onCurrencySelect: handleCurrencyBSelect,
                                                        onMax: ()=>{
                                                            onFieldBInput(maxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.toExact() ?? "");
                                                        },
                                                        showMaxButton: !atMaxAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                                        currency: currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B],
                                                        id: "add-liquidity-input-tokenb",
                                                        showCommonBases: false
                                                    }),
                                                    currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] && currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B] && pairState !== _data_Reserves__WEBPACK_IMPORTED_MODULE_14__/* .PairState.INVALID */ ._G.INVALID && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Text, {
                                                                style: {
                                                                    textTransform: "uppercase",
                                                                    fontWeight: 600
                                                                },
                                                                color: "textSubtle",
                                                                fontSize: "12px",
                                                                mb: "2px"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "px-1 py-5 bg-[#F6F6F7]",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PoolPriceBar__WEBPACK_IMPORTED_MODULE_31__.PoolPriceBar, {
                                                                    currencies: currencies,
                                                                    poolTokenPercentage: poolTokenPercentage,
                                                                    noLiquidity: noLiquidity,
                                                                    price: price
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    !account ? // <div>Connect Wallert Button</div>
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ConnectWalletButton__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                                        width: "100%"
                                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_7__/* .AutoColumn */ .Tz, {
                                                        gap: "md",
                                                        children: [
                                                            (approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.NOT_APPROVED */ .UK.NOT_APPROVED || approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING || approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.NOT_APPROVED */ .UK.NOT_APPROVED || approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING) && isValid && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowBetween */ .m0, {
                                                                children: [
                                                                    approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                                        onClick: approveACallback,
                                                                        disabled: approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING,
                                                                        className: "!bg-[#90E040] !shadow-none !rounded-md",
                                                                        style: {
                                                                            width: approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED ? "48%" : "100%"
                                                                        },
                                                                        children: approvalA === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Dots, {
                                                                            children: [
                                                                                "Approving ",
                                                                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
                                                                            ]
                                                                        }) : `Approve ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol}`
                                                                    }),
                                                                    approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                                        onClick: approveBCallback,
                                                                        disabled: approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING,
                                                                        className: "!bg-[#90E040] !shadow-none !rounded-md",
                                                                        style: {
                                                                            width: approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED ? "48%" : "100%"
                                                                        },
                                                                        children: approvalB === _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.PENDING */ .UK.PENDING ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Dots, {
                                                                            children: [
                                                                                "Approving ",
                                                                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
                                                                            ]
                                                                        }) : `Approve ${currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol}`
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                                onClick: ()=>{
                                                                    if (expertMode) {
                                                                        onAdd();
                                                                    } else {
                                                                        setShowConfirm(true);
                                                                    }
                                                                },
                                                                disabled: !isValid || approvalA !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED || approvalB !== _hooks_useApproveCallback__WEBPACK_IMPORTED_MODULE_17__/* .ApprovalState.APPROVED */ .UK.APPROVED,
                                                                className: `!text-white !shadow-none !rounded-md ${!isValid && !!parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] && !!parsedAmounts[_state_mint_actions__WEBPACK_IMPORTED_MODULE_18__/* .Field.CURRENCY_B */ .gN.CURRENCY_B] ? "!bg-[#ED4B9E]" : "!bg-[#90E040]"}`,
                                                                width: "100%",
                                                                children: error ?? "Supply"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                eventsModalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_RateSetModal__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .Z, {
                                    onClose: eventsModalCloseHandler
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Notification__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                                    setShow: setShow,
                                    show: show,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mx-auto transition duration-150 ease-in-out",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[296px] h-[75px] bg-white rounded-lg flex flex-col justify-center items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[#242424] text-[12px] font-medium tracking-wide uppercase",
                                                    children: "Transaction submitted"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex gap-x-3 items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "mt-1 text-[14px] font-bold text-[#3985F5] uppercase",
                                                            children: "view on bscscan"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_viewscan_svg__WEBPACK_IMPORTED_MODULE_39__/* ["default"] */ .Z, {
                                                            className: "w-[12px] h-[12px] mt-1"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8731:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OA": () => (/* binding */ useMintActionHandlers),
/* harmony export */   "OY": () => (/* binding */ useMintState),
/* harmony export */   "Qw": () => (/* binding */ useDerivedMintInfo)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _data_Reserves__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4213);
/* harmony import */ var _data_TotalSupply__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6070);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5820);
/* harmony import */ var _utils_translateTextHelpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3378);
/* harmony import */ var _utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5354);
/* harmony import */ var _swap_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8298);
/* harmony import */ var _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1023);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8149);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_Reserves__WEBPACK_IMPORTED_MODULE_3__, _data_TotalSupply__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__, _swap_hooks__WEBPACK_IMPORTED_MODULE_8__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__]);
([_data_Reserves__WEBPACK_IMPORTED_MODULE_3__, _data_TotalSupply__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_5__, _swap_hooks__WEBPACK_IMPORTED_MODULE_8__, _wallet_hooks__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ZERO = _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0);
function useMintState() {
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.mint);
}
function useDerivedMintInfo(currencyA, currencyB) {
    const { account , chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActiveWeb3React */ .aQ)();
    const { independentField , typedValue , otherTypedValue  } = useMintState();
    const dependentField = independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B : _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A;
    // tokens
    const currencies = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyA ?? undefined,
            [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyB ?? undefined
        }), [
        currencyA,
        currencyB
    ]);
    // pair
    const [pairState, pair] = (0,_data_Reserves__WEBPACK_IMPORTED_MODULE_3__/* .usePair */ .yX)(currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A], currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]);
    const totalSupply = (0,_data_TotalSupply__WEBPACK_IMPORTED_MODULE_4__/* .useTotalSupply */ .A)(pair?.liquidityToken);
    const noLiquidity = pairState === _data_Reserves__WEBPACK_IMPORTED_MODULE_3__/* .PairState.NOT_EXISTS */ ._G.NOT_EXISTS || Boolean(totalSupply && _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.equal(totalSupply.raw, ZERO));
    // balances
    const balances = (0,_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useCurrencyBalances */ .K5)(account ?? undefined, [
        currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A],
        currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B], 
    ]);
    const currencyBalances = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: balances[0],
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: balances[1]
    };
    // amounts
    const independentAmount = (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(typedValue, currencies[independentField]);
    const dependentAmount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (noLiquidity) {
            if (otherTypedValue && currencies[dependentField]) {
                return (0,_swap_hooks__WEBPACK_IMPORTED_MODULE_8__/* .tryParseAmount */ .eo)(otherTypedValue, currencies[dependentField]);
            }
            return undefined;
        }
        if (independentAmount) {
            // we wrap the currencies just to get the price in terms of the other token
            const wrappedIndependentAmount = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(independentAmount, chainId);
            const [tokenA, tokenB] = [
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyA, chainId),
                (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyB, chainId)
            ];
            if (tokenA && tokenB && wrappedIndependentAmount && pair) {
                const dependentCurrency = dependentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B ? currencyB : currencyA;
                const dependentTokenAmount = dependentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B ? pair.priceOf(tokenA).quote(wrappedIndependentAmount) : pair.priceOf(tokenB).quote(wrappedIndependentAmount);
                return dependentCurrency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER ? _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(dependentTokenAmount.raw) : dependentTokenAmount;
            }
            return undefined;
        }
        return undefined;
    }, [
        noLiquidity,
        otherTypedValue,
        currencies,
        dependentField,
        independentAmount,
        currencyA,
        chainId,
        currencyB,
        pair
    ]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const parsedAmounts = {
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? independentAmount : dependentAmount,
        [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: independentField === _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A ? dependentAmount : independentAmount
    };
    const price = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (noLiquidity) {
            const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount  } = parsedAmounts;
            if (currencyAAmount && currencyBAmount) {
                return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Price(currencyAAmount.currency, currencyBAmount.currency, currencyAAmount.raw, currencyBAmount.raw);
            }
            return undefined;
        }
        const wrappedCurrencyA = (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrency */ .pu)(currencyA, chainId);
        return pair && wrappedCurrencyA ? pair.priceOf(wrappedCurrencyA) : undefined;
    }, [
        chainId,
        currencyA,
        noLiquidity,
        pair,
        parsedAmounts
    ]);
    // liquidity minted
    const liquidityMinted = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount  } = parsedAmounts;
        const [tokenAmountA, tokenAmountB] = [
            (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(currencyAAmount, chainId),
            (0,_utils_wrappedCurrency__WEBPACK_IMPORTED_MODULE_7__/* .wrappedCurrencyAmount */ .N)(currencyBAmount, chainId), 
        ];
        if (pair && totalSupply && tokenAmountA && tokenAmountB) {
            return pair.getLiquidityMinted(totalSupply, tokenAmountA, tokenAmountB);
        }
        return undefined;
    }, [
        parsedAmounts,
        chainId,
        pair,
        totalSupply
    ]);
    const poolTokenPercentage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (liquidityMinted && totalSupply) {
            return new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.Percent(liquidityMinted.raw, totalSupply.add(liquidityMinted).raw);
        }
        return undefined;
    }, [
        liquidityMinted,
        totalSupply
    ]);
    let error;
    if (!account) {
        error = "Connect Wallet";
    }
    if (pairState === _data_Reserves__WEBPACK_IMPORTED_MODULE_3__/* .PairState.INVALID */ ._G.INVALID) {
        error = error ?? (0,_utils_translateTextHelpers__WEBPACK_IMPORTED_MODULE_6__/* .TranslateString */ .V)(136, "Invalid pair");
    }
    if (!parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A] || !parsedAmounts[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]) {
        error = error ?? (0,_utils_translateTextHelpers__WEBPACK_IMPORTED_MODULE_6__/* .TranslateString */ .V)(84, "Enter an amount");
    }
    const { [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]: currencyAAmount , [_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]: currencyBAmount  } = parsedAmounts;
    if (currencyAAmount && currencyBalances?.[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.lessThan(currencyAAmount)) {
        error = `Insufficient ${currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol} balance`;
    }
    if (currencyBAmount && currencyBalances?.[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.lessThan(currencyBAmount)) {
        error = `Insufficient ${currencies[_actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol} balance`;
    }
    return {
        dependentField,
        currencies,
        pair,
        pairState,
        currencyBalances,
        parsedAmounts,
        price,
        noLiquidity,
        liquidityMinted,
        poolTokenPercentage,
        error
    };
}
function useMintActionHandlers(noLiquidity) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const onFieldAInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .typeInput */ .LC)({
            field: _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_A */ .gN.CURRENCY_A,
            typedValue,
            noLiquidity: noLiquidity === true
        }));
    }, [
        dispatch,
        noLiquidity
    ]);
    const onFieldBInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((typedValue)=>{
        dispatch((0,_actions__WEBPACK_IMPORTED_MODULE_10__/* .typeInput */ .LC)({
            field: _actions__WEBPACK_IMPORTED_MODULE_10__/* .Field.CURRENCY_B */ .gN.CURRENCY_B,
            typedValue,
            noLiquidity: noLiquidity === true
        }));
    }, [
        dispatch,
        noLiquidity
    ]);
    return {
        onFieldAInput,
        onFieldBInput
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ maxAmountSpend)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1407);


/**
 * Given some token amount, return the max that can be spent of it
 * @param currencyAmount to return max of
 */ function maxAmountSpend(currencyAmount) {
    if (!currencyAmount) return undefined;
    if (currencyAmount.currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.ETHER) {
        if (_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.greaterThan(currencyAmount.raw, _constants__WEBPACK_IMPORTED_MODULE_1__/* .MIN_ETH */ .HP)) {
            return _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.subtract(currencyAmount.raw, _constants__WEBPACK_IMPORTED_MODULE_1__/* .MIN_ETH */ .HP));
        }
        return _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.ether(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(0));
    }
    return currencyAmount;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (maxAmountSpend)));


/***/ })

};
;