"use strict";
exports.id = 111;
exports.ids = [111];
exports.modules = {

/***/ 111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PoolPriceBar": () => (/* binding */ PoolPriceBar),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Column__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(247);
/* harmony import */ var _components_Row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(108);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1407);
/* harmony import */ var _state_mint_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8149);







function PoolPriceBar({ currencies , noLiquidity , poolTokenPercentage , price  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
        gap: "md",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_4__/* .AutoRow */ .BA, {
            justify: "space-around",
            gap: "4px",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "#3985F5",
                            children: price?.toSignificant(6) ?? "-"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            color: "#242424",
                            pt: 1,
                            children: [
                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol,
                                " per ",
                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "#3985F5",
                            children: price?.invert()?.toSignificant(6) ?? "-"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            color: "#242424",
                            pt: 1,
                            children: [
                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_A */ .gN.CURRENCY_A]?.symbol,
                                " per ",
                                currencies[_state_mint_actions__WEBPACK_IMPORTED_MODULE_6__/* .Field.CURRENCY_B */ .gN.CURRENCY_B]?.symbol
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
                    justify: "center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            color: "#3985F5",
                            children: [
                                noLiquidity && price ? "100" : (poolTokenPercentage?.lessThan(_constants__WEBPACK_IMPORTED_MODULE_5__/* .ONE_BIPS */ .IS) ? "<0.01" : poolTokenPercentage?.toFixed(2)) ?? "0",
                                "%"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                            fontSize: "14px",
                            pt: 1,
                            color: "#242424",
                            children: "Share of Pool"
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoolPriceBar);


/***/ })

};
;