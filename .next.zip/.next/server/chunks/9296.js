"use strict";
exports.id = 9296;
exports.ids = [9296];
exports.modules = {

/***/ 9296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RateSetModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6921);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6524);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__);
/* eslint-disable react-hooks/exhaustive-deps */ /* eslint-disable @next/next/no-img-element */ 






function RateSetModal({ onClose  }) {
    const scanUrl = "https://testnet.bscscan.com/tx/";
    const { 0: rate , 1: setRate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { isAuthenticated , Moralis  } = (0,react_moralis__WEBPACK_IMPORTED_MODULE_2__.useMoralis)();
    const { 0: swapTokenLogs , 1: setSwapTokenLogs  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: toggleFiltersModal , 1: setToggleFiltersModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: swapTokenLogsQuery , 1: setSwapTokenLogsQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: lastPage , 1: setLastPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: currentPage , 1: setCurrentPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    let perPage = 10;
    async function loadSwapTokenLogs() {
        const data = await fetchData();
        setSwapTokenLogsQuery(data);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fn = async ()=>{
            const value = await Moralis.Cloud.run("getStripeRate");
            setRate(value?.rate);
            loadSwapTokenLogs();
        };
        fn();
    }, [
        isAuthenticated
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLastPage(getLastPage(swapTokenLogsQuery));
        if (lastPage < currentPage) {
            setCurrentPage(1);
        }
        pagination();
    }, [
        currentPage,
        swapTokenLogsQuery
    ]);
    const handleRate = async (evt)=>{
        const value = evt.target.value;
        if (value >= 0) setRate(value);
    };
    const handleSaveRate = async ()=>{
        await Moralis.Cloud.run("setStripeRate", {
            rate
        });
        antd__WEBPACK_IMPORTED_MODULE_4__.Modal.success({
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__.ExclamationCircleOutlined, {}),
            content: "Saved!"
        });
    };
    async function fetchData() {
        let query = await Moralis.Cloud.run("getSwapTransfers", {
            searchKeyWord: ""
        });
        if (!query || query.length == 0) {
            return [];
        }
        query = query.filter((log, i)=>{
            return log;
        });
        return query.reverse();
    }
    const pagination = ()=>{
        if (swapTokenLogsQuery && swapTokenLogsQuery.length > 0) {
            setSwapTokenLogs(swapTokenLogsQuery.slice((currentPage - 1) * perPage, currentPage * perPage));
        } else {
            setSwapTokenLogs([]);
        }
    };
    const nextPage = ()=>{
        setCurrentPage(currentPage + 1);
    };
    const prevPage = ()=>{
        // let minPage = currentPage - 1;
        setCurrentPage(currentPage - 1);
    };
    function getLastPage(result) {
        if (!result || result.length < 0) {
            return 1;
        }
        return Math.ceil(result.length / perPage);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "fixed w-screen h-screen bg-[#242424] top-0 left-0 bg-opacity-50 flex justify-end z-20",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "hidden md:flex w-10 h-10 bg-[#f2f3f5] rounded-full justify-center items-center mr-8 mt-20",
                onClick: onClose,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    className: "w-5 h-5 stroke-[#242424]"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-2xl w-full h-screen bg-[#F2F3F5] opacity-100 shrink-0 pt-10 md:pt-20 px-10 overflow-y-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "flex md:hidden w-10 h-10 ml-auto bg-[#f2f3f5] rounded-full justify-center items-center mb-8",
                        onClick: onClose,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            className: "w-5 h-5 stroke-[#242424]"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-end justify-between mb-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-5xl font-bold uppercase",
                            children: "RATE FOR STRIPE"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "stripe-rate-header",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "stripe-rate-display",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "cus_d_flex",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "cus_d_flex_item_5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: "/assets/brand_token.svg",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "pl-5 cus_font",
                                                    children: rate
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "cus_d_flex_item_2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "pl-5 cus_font",
                                                children: "="
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "cus_d_flex_item_5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: "/assets/brand_usd.svg",
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "pl-5 cus_font",
                                                    children: "1"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "cus_rate_label",
                                    children: "current rate"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-8",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "stripe-input-title",
                                children: "Enter the rate (YLT per 1 USD)"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "stripe-input",
                                value: rate,
                                placeholder: "500",
                                type: "number",
                                onChange: handleRate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "stripe-set-btn",
                                onClick: handleSaveRate,
                                children: "SET RATE"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ })

};
;