"use strict";
exports.id = 817;
exports.ids = [817];
exports.modules = {

/***/ 817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7081);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7256);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8510);
/* harmony import */ var _pancake_CoinLogo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9850);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__]);
_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const getTokenLogoURL = (address)=>`https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/smartchain/assets/${address}/logo.png`;
const StyledBnbLogo = styled_components__WEBPACK_IMPORTED_MODULE_3___default().img.withConfig({
    componentId: "sc-20448e1a-0"
})`
  width: ${({ size  })=>size};
  height: ${({ size  })=>size};
  box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.075);
  border-radius: 24px;
`;
const StyledLogo = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_Logo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z).withConfig({
    componentId: "sc-20448e1a-1"
})`
  width: ${({ size  })=>size};
  height: ${({ size  })=>size};
`;
function CurrencyLogo({ currency , size ="24px" , style  }) {
    const uriLocations = (0,_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__/* .WrappedTokenInfo */ .DT ? currency.logoURI : undefined);
    const srcs = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) return [];
        if (currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token) {
            if (currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_5__/* .WrappedTokenInfo */ .DT) {
                return [
                    ...uriLocations,
                    `/images/coins/${currency?.address ?? "token"}.png`,
                    getTokenLogoURL(currency.address)
                ];
            }
            return [
                `/images/coins/${currency?.address ?? "token"}.png`,
                getTokenLogoURL(currency.address)
            ];
        }
        return [];
    }, [
        currency,
        uriLocations
    ]);
    if (currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBnbLogo, {
            src: "/images/coins/bnb.png",
            size: size,
            style: style
        });
    }
    return currency?.symbol ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancake_CoinLogo__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        size: size,
        srcs: srcs,
        alt: `${currency?.symbol ?? "token"} logo`,
        style: style
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledLogo, {
        size: size,
        srcs: srcs,
        alt: `${currency?.symbol ?? "token"} logo`,
        style: style
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_2__);



const BAD_SRCS = {};
/**
 * Renders an image by sequentially trying a list of URIs, and then eventually a fallback triangle alert
 */ function Logo({ srcs , alt , ...rest }) {
    const { 1: refresh  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const src = srcs.find((s)=>!BAD_SRCS[s]);
    if (src) {
        return(// eslint-disable-next-line @next/next/no-img-element
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            ...rest,
            alt: alt,
            src: src,
            onError: ()=>{
                if (src) BAD_SRCS[src] = true;
                refresh((i)=>i + 1);
            }
        }));
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_2__.HelpCircle, {
        ...rest
    });
};


/***/ }),

/***/ 9850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8510);


const CoinLogo = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Logo__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).withConfig({
    componentId: "sc-a7a49345-0"
})`
  width: ${({ size  })=>size};
  height: ${({ size  })=>size};
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CoinLogo);


/***/ }),

/***/ 6163:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useENSContentHash)
/* harmony export */ });
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2522);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _utils_isZero__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(720);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5307);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_3__]);
([_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__, _useContract__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





/**
 * Does a lookup for an ENS name to find its contenthash.
 */ function useENSContentHash(ensName) {
    const ensNodeArgument = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (!ensName) return [
            undefined
        ];
        try {
            return ensName ? [
                (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.namehash)(ensName)
            ] : [
                undefined
            ];
        } catch (error) {
            return [
                undefined
            ];
        }
    }, [
        ensName
    ]);
    const registrarContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSRegistrarContract */ .zb)(false);
    const resolverAddressResult = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(registrarContract, "resolver", ensNodeArgument);
    const resolverAddress = resolverAddressResult.result?.[0];
    const resolverContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_3__/* .useENSResolverContract */ .uU)(resolverAddress && (0,_utils_isZero__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(resolverAddress) ? undefined : resolverAddress, false);
    const contenthash = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(resolverContract, "contenthash", ensNodeArgument);
    return {
        contenthash: contenthash.result?.[0] ?? null,
        loading: resolverAddressResult.loading || contenthash.loading
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7081:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useHttpLocations)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_contenthashToUri__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2391);
/* harmony import */ var _utils_parseENSAddress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6298);
/* harmony import */ var _utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7787);
/* harmony import */ var _useENSContentHash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6163);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__]);
_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function useHttpLocations(uri) {
    const ens = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>uri ? (0,_utils_parseENSAddress__WEBPACK_IMPORTED_MODULE_3__/* .parseENSAddress */ .y)(uri) : undefined, [
        uri
    ]);
    const resolvedContentHash = (0,_useENSContentHash__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(ens?.ensName);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (ens) {
            return resolvedContentHash.contenthash ? (0,_utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)((0,_utils_contenthashToUri__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(resolvedContentHash.contenthash)) : [];
        }
        return uri ? (0,_utils_uriToHttp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(uri) : [];
    }, [
        ens,
        resolvedContentHash.contenthash,
        uri
    ]);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;