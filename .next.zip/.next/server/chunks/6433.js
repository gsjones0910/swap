"use strict";
exports.id = 6433;
exports.ids = [6433];
exports.modules = {

/***/ 6089:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2501);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const UnlockButton = (props)=>{
    const { login , logout  } = (0,_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { onPresentConnectModal  } = (0,_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.useWalletModal)(login, logout);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
        className: "bg-[white]",
        onClick: onPresentConnectModal,
        ...props,
        children: "Unlock Wallet"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnlockButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9963:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyInputPanel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2042);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(polished__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1023);
/* harmony import */ var _TokenSelectModal_TokenModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(375);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(817);
/* harmony import */ var _DoubleLogo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3976);
/* harmony import */ var _NumericalInput__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9767);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_5__, _TokenSelectModal_TokenModal__WEBPACK_IMPORTED_MODULE_6__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_8__, _hooks__WEBPACK_IMPORTED_MODULE_10__]);
([_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_5__, _TokenSelectModal_TokenModal__WEBPACK_IMPORTED_MODULE_6__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__, _DoubleLogo__WEBPACK_IMPORTED_MODULE_8__, _hooks__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const InputRow = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-aa00e22b-0"
})`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  padding: ${({ selected  })=>selected ? "0.75rem 0.5rem 0.75rem 1rem" : "0.75rem 0.75rem 0.75rem 1rem"};
`;
const CurrencySelect = styled_components__WEBPACK_IMPORTED_MODULE_3___default().button.withConfig({
    componentId: "sc-aa00e22b-1"
})`
  align-items: center;
  height: 34px;
  font-size: 16px;
  font-weight: 500;
  background-color: transparent;
  color: ${({ selected , theme  })=>selected ? theme.colors.text : "#FFFFFF"};
  border-radius: 12px;
  outline: none;
  cursor: pointer;
  user-select: none;
  border: none;
  padding: 0 0.5rem;
  :focus,
`;
const LabelRow = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-aa00e22b-2"
})`
  display: flex;
  flex-flow: row nowrap;
  align-items: center;
  color: ${({ theme  })=>theme.colors.text};
  font-size: 0.75rem;
  line-height: 1rem;
  padding: 0.75rem 1rem 0 1rem;
  span:hover {
    cursor: pointer;
    color: ${({ theme  })=>(0,polished__WEBPACK_IMPORTED_MODULE_4__.darken)(0.2, theme.colors.textSubtle)};
  }
`;
const Aligner = styled_components__WEBPACK_IMPORTED_MODULE_3___default().span.withConfig({
    componentId: "sc-aa00e22b-3"
})`
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: rgba(144, 224, 64, 0.5);
  border-radius: 8px;
  padding: 6px;
`;
const InputPanel = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-aa00e22b-4"
})`
  display: flex;
  flex-flow: column nowrap;
  position: relative;
  background: #F6F6F7;
  border-radius: 8px;
  z-index: 1;
`;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-aa00e22b-5"
})`
  border-radius: 16px;
`;
function CurrencyInputPanel({ value , onUserInput , onMax , showMaxButton , label , onCurrencySelect , currency , disableCurrencySelect =false , hideBalance =false , pair =null , hideInput =false , otherCurrency , id , showCommonBases  }) {
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { account  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    const selectedCurrencyBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useCurrencyBalance */ ._h)(account ?? undefined, currency ?? undefined);
    const translatedLabel = label || "Input";
    const handleDismissSearch = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setModalOpen(false);
    }, [
        setModalOpen
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InputPanel, {
                id: id,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
                    hideInput: hideInput,
                    children: [
                        !hideInput && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LabelRow, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full flex justify-end",
                                children: account && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    onClick: onMax,
                                    style: {
                                        display: "inline",
                                        cursor: "pointer",
                                        color: "#242424"
                                    },
                                    children: !hideBalance && !!currency && selectedCurrencyBalance ? `Balance: ${selectedCurrencyBalance?.toSignificant(6)}` : " -"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InputRow, {
                            style: hideInput ? {
                                padding: "0",
                                borderRadius: "8px"
                            } : {},
                            selected: disableCurrencySelect,
                            children: [
                                !hideInput && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NumericalInput__WEBPACK_IMPORTED_MODULE_9__/* .Input */ .I, {
                                            className: "token-amount-input",
                                            value: value,
                                            onUserInput: (val)=>{
                                                onUserInput(val);
                                            }
                                        }),
                                        account && currency && showMaxButton && label !== "To" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                            onClick: onMax,
                                            scale: "sm",
                                            variant: "text",
                                            children: "MAX"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col justify-between items-end",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CurrencySelect, {
                                        selected: !!currency,
                                        className: "open-currency-select-button",
                                        onClick: ()=>{
                                            if (!disableCurrencySelect) {
                                                setModalOpen(true);
                                            }
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Aligner, {
                                            children: [
                                                pair ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DoubleLogo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                    currency0: pair.token0,
                                                    currency1: pair.token1,
                                                    size: 16,
                                                    margin: true
                                                }) : currency ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    currency: currency,
                                                    size: "24px",
                                                    style: {
                                                        marginRight: "8px"
                                                    }
                                                }) : null,
                                                pair ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                    id: "pair",
                                                    color: "#242424;",
                                                    children: [
                                                        pair?.token0.symbol,
                                                        ":",
                                                        pair?.token1.symbol
                                                    ]
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                    id: "pair",
                                                    style: {
                                                        color: "#242424"
                                                    },
                                                    children: (currency && currency.symbol && currency.symbol.length > 20 ? `${currency.symbol.slice(0, 4)}...${currency.symbol.slice(currency.symbol.length - 5, currency.symbol.length)}` : currency?.symbol) || "Select a currency"
                                                }),
                                                !disableCurrencySelect && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.ChevronDownIcon, {})
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            !disableCurrencySelect && onCurrencySelect && modalOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TokenSelectModal_TokenModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                isOpen: modalOpen,
                onDismiss: handleDismissSearch,
                onCurrencySelect: onCurrencySelect,
                selectedCurrency: currency,
                otherSelectedCurrency: otherCurrency,
                showCommonBases: showCommonBases
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7491:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ListLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7081);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const StyledListLogo = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Logo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z).withConfig({
    componentId: "sc-255b9f7d-0"
})`
  width: ${({ size  })=>size};
  height: ${({ size  })=>size};
`;
function ListLogo({ logoURI , style , size ="24px" , alt  }) {
    const srcs = (0,_hooks_useHttpLocations__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(logoURI);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledListLogo, {
        alt: alt,
        size: size,
        srcs: srcs,
        style: style
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4417);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reach_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7372);
/* harmony import */ var _reach_dialog__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_reach_dialog__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3599);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_device_detect__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2042);
/* harmony import */ var polished__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(polished__WEBPACK_IMPORTED_MODULE_6__);








const AnimatedDialogOverlay = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.animated)(_reach_dialog__WEBPACK_IMPORTED_MODULE_4__.DialogOverlay);
const StyledDialogOverlay = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(AnimatedDialogOverlay).withConfig({
    componentId: "sc-bc972d0-0"
})`
  &[data-reach-dialog-overlay] {
    z-index: 6;
    background-color: transparent;
    overflow: hidden;

    display: flex;
    align-items: center;
    justify-content: center;

    background-color: rgba(0, 0, 0, 0.3);
  }
`;
const AnimatedDialogContent = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.animated)(_reach_dialog__WEBPACK_IMPORTED_MODULE_4__.DialogContent);
// destructure to not pass custom props to Dialog DOM element
const StyledDialogContent = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(({ minHeight , maxHeight , mobile , isOpen , ...rest })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AnimatedDialogContent, {
        ...rest
    })).attrs({
    "aria-label": "dialog"
}).withConfig({
    componentId: "sc-bc972d0-1"
})`
  &[data-reach-dialog-content] {
    margin: 0 0 2rem 0;
    border: 1px solid ${({ theme  })=>theme.colors.invertedContrast};
    background-color: ${({ theme  })=>theme.colors.invertedContrast};
    box-shadow: 0 4px 8px 0 ${(0,polished__WEBPACK_IMPORTED_MODULE_6__.transparentize)(0.95, "#191326")};
    padding: 0px;
    width: 80%;
    overflow: hidden;

    align-self: ${({ mobile  })=>mobile ? "flex-end" : "center"};

    max-width: 420px;
    ${({ maxHeight  })=>maxHeight && styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
        max-height: ${maxHeight}vh;
      `}
    ${({ minHeight  })=>minHeight && styled_components__WEBPACK_IMPORTED_MODULE_2__.css`
        min-height: ${minHeight}vh;
      `}
    display: flex;
    border-radius: 20px;

    ${({ theme  })=>theme.mediaQueries.lg} {
      width: 65vw;
    }
    ${({ theme  })=>theme.mediaQueries.sm} {
      width: 85vw;
    }
  }
`;
function Modal({ isOpen , onDismiss , minHeight =false , maxHeight =50 , initialFocusRef , children  }) {
    const fadeTransition = (0,react_spring__WEBPACK_IMPORTED_MODULE_3__.useTransition)(isOpen, null, {
        config: {
            duration: 200
        },
        from: {
            opacity: 0
        },
        enter: {
            opacity: 1
        },
        leave: {
            opacity: 0
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: fadeTransition.map(({ item , key , props  })=>item && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledDialogOverlay, {
                style: props,
                onDismiss: onDismiss,
                initialFocusRef: initialFocusRef,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledDialogContent, {
                    "aria-label": "dialog content",
                    minHeight: minHeight,
                    maxHeight: maxHeight,
                    mobile: react_device_detect__WEBPACK_IMPORTED_MODULE_5__.isMobile,
                    children: [
                        !initialFocusRef && react_device_detect__WEBPACK_IMPORTED_MODULE_5__.isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            tabIndex: 1
                        }) : null,
                        children
                    ]
                })
            }, key))
    });
};


/***/ }),

/***/ 9767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8847);




const StyledInput = styled_components__WEBPACK_IMPORTED_MODULE_2___default().input.withConfig({
    componentId: "sc-81bd752-0"
})`
  color: ${({ error , theme  })=>error ? theme.colors.failure : theme.colors.text};
  width: 0;
  position: relative;
  outline: none;
  border: none;
  flex: 1 1 auto;
  background-color: transparent;
  text-align: ${({ align  })=>align && align};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0px;
  -webkit-appearance: textfield;
  font-family: 'IBM Plex Mono';
  font-style: normal;
  font-weight: 700;
  font-size: 48px;
  line-height: 40px;
  color: #242424;
  ::-webkit-input-placeholder { /* WebKit, Blink, Edge */
    color:    #242424;
  }
  :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color:    #242424;
    opacity:  1;
  }
  ::-moz-placeholder { /* Mozilla Firefox 19+ */
    color:    #242424;
    opacity:  1;
  }
  :-ms-input-placeholder { /* Internet Explorer 10-11 */
    color:    #242424;
  }
  ::-ms-input-placeholder { /* Microsoft Edge */
    color:    #242424;
  }

  ::placeholder { /* Most modern browsers support this now. */
    color:    #242424;
  }
`;
const inputRegex = RegExp(`^\\d*(?:\\\\[.])?\\d*$`) // match escaped "." characters via in a non-capturing group
;
const Input = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().memo(function InnerInput({ value , onUserInput , placeholder , ...rest }) {
    const enforcer = (nextUserInput)=>{
        if (nextUserInput === "" || inputRegex.test((0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .escapeRegExp */ .hr)(nextUserInput))) {
            onUserInput(nextUserInput);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledInput, {
        ...rest,
        value: value,
        onChange: (event)=>{
            // replace commas with periods, because uniswap exclusively uses period as the decimal separator
            enforcer(event.target.value.replace(/,/g, "."));
        },
        // universal input options
        inputMode: "decimal",
        title: "Token Amount",
        autoComplete: "off",
        autoCorrect: "off",
        // text-specific options
        type: "text",
        pattern: "^[0-9]*[.,]?[0-9]*$",
        placeholder: placeholder || "0.0",
        minLength: 1,
        maxLength: 79,
        spellCheck: "false"
    });
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Input)));


/***/ }),

/***/ 6964:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CommonBases)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1407);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(247);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3994);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(108);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(817);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CurrencyLogo__WEBPACK_IMPORTED_MODULE_9__]);
_CurrencyLogo__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const BaseWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-170057e0-0"
})`
  border: 1px solid ${({ theme , disable  })=>disable ? "transparent" : theme.colors.tertiary};
  border-radius: 10px;
  display: flex;
  padding: 6px;

  align-items: center;
  :hover {
    cursor: ${({ disable  })=>!disable && "pointer"};
    background-color: ${({ theme , disable  })=>!disable && theme.colors.invertedContrast};
  }

  background-color: ${({ theme , disable  })=>disable && theme.colors.tertiary};
  opacity: ${({ disable  })=>disable && "0.4"};
`;
function CommonBases({ chainId , onSelect , selectedCurrency  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_6__/* .AutoColumn */ .Tz, {
        gap: "md",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_8__/* .AutoRow */ .BA, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                        fontSize: "14px",
                        children: "Common bases"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        text: "These tokens are commonly paired with other tokens."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_8__/* .AutoRow */ .BA, {
                gap: "4px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BaseWrapper, {
                        onClick: ()=>{
                            if (!selectedCurrency || !(0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.currencyEquals)(selectedCurrency, _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER)) {
                                onSelect(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER);
                            }
                        },
                        disable: selectedCurrency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                currency: _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.ETHER,
                                style: {
                                    marginRight: 8
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                children: "BNB"
                            })
                        ]
                    }),
                    (chainId ? _constants__WEBPACK_IMPORTED_MODULE_5__/* .SUGGESTED_BASES */ .kx[chainId] : []).map((token)=>{
                        const selected = selectedCurrency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_3__.Token && selectedCurrency.address === token.address;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BaseWrapper, {
                            onClick: ()=>!selected && onSelect(token),
                            disable: selected,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    currency: token,
                                    style: {
                                        marginRight: 8
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    children: token.symbol
                                })
                            ]
                        }, token.address);
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3229:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CurrencyList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(551);
/* harmony import */ var react_window__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_window__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5820);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7256);
/* harmony import */ var _state_user_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1158);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1023);
/* harmony import */ var _Shared__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8306);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7411);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(247);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(108);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(817);
/* harmony import */ var _Tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3044);
/* harmony import */ var _styleds__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7770);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9620);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8847);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_6__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_8__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_11__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__]);
([_hooks__WEBPACK_IMPORTED_MODULE_6__, _state_user_hooks__WEBPACK_IMPORTED_MODULE_8__, _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_11__, _CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















function currencyKey(currency) {
    return currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token ? currency.address : currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER ? "ETHER" : "";
}
const StyledBalanceText = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text).withConfig({
    componentId: "sc-39372e27-0"
})`
  white-space: nowrap;
  overflow: hidden;
  max-width: 5rem;
  text-overflow: ellipsis;
`;
const Tag = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-39372e27-1"
})`
  background-color: ${({ theme  })=>theme.colors.tertiary};
  color: ${({ theme  })=>theme.colors.textSubtle};
  font-size: 14px;
  border-radius: 4px;
  padding: 0.25rem 0.3rem 0.25rem 0.3rem;
  max-width: 6rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  justify-self: flex-end;
  margin-right: 4px;
`;
function Balance({ balance  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledBalanceText, {
        title: balance.toExact(),
        children: balance.toSignificant(4)
    });
}
const TagContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-39372e27-2"
})`
  display: flex;
  justify-content: flex-end;
`;
function TokenTags({ currency  }) {
    if (!(currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__/* .WrappedTokenInfo */ .DT)) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    }
    const { tags  } = currency;
    if (!tags || tags.length === 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {});
    const tag = tags[0];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TagContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_15__/* .MouseoverTooltip */ .u, {
                text: tag.description,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tag, {
                    children: tag.name
                }, tag.id)
            }),
            tags.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Tooltip__WEBPACK_IMPORTED_MODULE_15__/* .MouseoverTooltip */ .u, {
                text: tags.slice(1).map(({ name , description  })=>`${name}: ${description}`).join("; \n"),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tag, {
                    children: "..."
                })
            }) : null
        ]
    });
}
function CurrencyRow({ currency , onSelect , isSelected , otherSelected , style  }) {
    const { account , chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useActiveWeb3React */ .aQ)();
    const key = currencyKey(currency);
    const selectedTokenList = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useSelectedTokenList */ .Cm)();
    const isOnSelectedList = (0,_utils__WEBPACK_IMPORTED_MODULE_18__/* .isTokenOnList */ .wK)(selectedTokenList, currency);
    const customAdded = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_11__/* .useIsUserAddedToken */ .EH)(currency);
    const balance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useCurrencyBalance */ ._h)(account ?? undefined, currency);
    const removeToken = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useRemoveUserAddedToken */ .QG)();
    const addToken = (0,_state_user_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useAddUserToken */ ._E)();
    // only show add or remove buttons if not on selected list
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styleds__WEBPACK_IMPORTED_MODULE_16__/* .MenuItem */ .sN, {
        style: style,
        className: `token-item-${key}`,
        onClick: ()=>isSelected ? null : onSelect(),
        disabled: isSelected,
        selected: otherSelected,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                currency: currency,
                size: "24px"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        title: currency.name,
                        children: currency.symbol
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styleds__WEBPACK_IMPORTED_MODULE_16__/* .FadedSpan */ .$3, {
                        children: [
                            !isOnSelectedList && customAdded && !(currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__/* .WrappedTokenInfo */ .DT) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                children: [
                                    "Added by user",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Shared__WEBPACK_IMPORTED_MODULE_10__/* .LinkStyledButton */ .W1, {
                                        onClick: (event)=>{
                                            event.stopPropagation();
                                            if (chainId && currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token) removeToken(chainId, currency.address);
                                        },
                                        children: "(Remove)"
                                    })
                                ]
                            }) : null,
                            !isOnSelectedList && !customAdded && !(currency instanceof _state_lists_hooks__WEBPACK_IMPORTED_MODULE_7__/* .WrappedTokenInfo */ .DT) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                                children: [
                                    "Found by address",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Shared__WEBPACK_IMPORTED_MODULE_10__/* .LinkStyledButton */ .W1, {
                                        onClick: (event)=>{
                                            event.stopPropagation();
                                            if (currency instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Token) addToken(currency);
                                        },
                                        children: "(Add)"
                                    })
                                ]
                            }) : null
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenTags, {
                currency: currency
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_13__/* .RowFixed */ .DA, {
                style: {
                    justifySelf: "flex-end"
                },
                children: balance ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Balance, {
                    balance: balance
                }) : account ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}) : null
            })
        ]
    });
}
function CurrencyList({ height , currencies , selectedCurrency , onCurrencySelect , otherCurrency , fixedListRef , showETH  }) {
    const itemData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>showETH ? [
            _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.Currency.ETHER,
            ...currencies
        ] : [
            ...currencies
        ], [
        currencies,
        showETH
    ]);
    const Row = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(({ data , index , style  })=>{
        const currency = data[index];
        const isSelected = Boolean(selectedCurrency && (0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.currencyEquals)(selectedCurrency, currency));
        const otherSelected = Boolean(otherCurrency && (0,_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.currencyEquals)(otherCurrency, currency));
        const handleSelect = ()=>onCurrencySelect(currency);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CurrencyRow, {
            style: style,
            currency: currency,
            isSelected: isSelected,
            onSelect: handleSelect,
            otherSelected: otherSelected
        });
    }, [
        onCurrencySelect,
        otherCurrency,
        selectedCurrency
    ]);
    const itemKey = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((index, data)=>currencyKey(data[index]), []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_window__WEBPACK_IMPORTED_MODULE_3__.FixedSizeList, {
        height: height,
        ref: fixedListRef,
        width: "100%",
        itemData: itemData,
        itemCount: itemData.length,
        itemSize: 56,
        itemKey: itemKey,
        children: Row
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7609:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ CurrencySearch)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8041);
/* harmony import */ var react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5820);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7411);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7256);
/* harmony import */ var _Shared__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8306);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8847);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2882);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(247);
/* harmony import */ var _ListLogo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7491);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(108);
/* harmony import */ var _CommonBases__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6964);
/* harmony import */ var _CurrencyList__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3229);
/* harmony import */ var _filtering__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2937);
/* harmony import */ var _SortButton__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4778);
/* harmony import */ var _sorting__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5335);
/* harmony import */ var _styleds__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7770);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_7__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__, _ListLogo__WEBPACK_IMPORTED_MODULE_14__, _CommonBases__WEBPACK_IMPORTED_MODULE_16__, _CurrencyList__WEBPACK_IMPORTED_MODULE_17__, _sorting__WEBPACK_IMPORTED_MODULE_20__]);
([_hooks__WEBPACK_IMPORTED_MODULE_7__, _hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__, _ListLogo__WEBPACK_IMPORTED_MODULE_14__, _CommonBases__WEBPACK_IMPORTED_MODULE_16__, _CurrencyList__WEBPACK_IMPORTED_MODULE_17__, _sorting__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















function CurrencySearch({ selectedCurrency , onCurrencySelect , otherSelectedCurrency , showCommonBases , onDismiss , isOpen , onChangeList  }) {
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_7__/* .useActiveWeb3React */ .aQ)();
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(styled_components__WEBPACK_IMPORTED_MODULE_5__.ThemeContext);
    const fixedList = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const { 0: searchQuery , 1: setSearchQuery  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: invertSearchOrder , 1: setInvertSearchOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const allTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useAllTokens */ .e_)();
    const tokensBySelect = Object.values(allTokens).filter((token)=>selectedCurrency.symbol === "YLT" ? token.address === "0x275aF57B1Ff293684568d2FC1dCE04159F252D27" : token.address !== "0x275aF57B1Ff293684568d2FC1dCE04159F252D27");
    // if they input an address, use it
    const isAddressSearch = (0,_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAddress */ .UJ)(searchQuery);
    const searchToken = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_8__/* .useToken */ .dQ)(searchQuery);
    const showETH = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const s = searchQuery.toLowerCase().trim();
        return s === "" || s === "b" || s === "bn" || s === "bnb";
    }, [
        searchQuery
    ]);
    const tokenComparator = (0,_sorting__WEBPACK_IMPORTED_MODULE_20__/* .useTokenComparator */ .k)(invertSearchOrder);
    const audioPlay = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.user.audioPlay);
    const filteredTokens = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (isAddressSearch) return searchToken ? [
            searchToken
        ] : [];
        return (0,_filtering__WEBPACK_IMPORTED_MODULE_18__/* .filterTokens */ .l)(Object.values(tokensBySelect), searchQuery);
    }, [
        isAddressSearch,
        searchToken,
        tokensBySelect,
        searchQuery
    ]);
    const filteredSortedTokens = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (searchToken) return [
            searchToken
        ];
        const sorted = filteredTokens.sort(tokenComparator);
        const symbolMatch = searchQuery.toLowerCase().split(/\s+/).filter((s)=>s.length > 0);
        if (symbolMatch.length > 1) return sorted;
        return [
            ...searchToken ? [
                searchToken
            ] : [],
            // sort any exact symbol matches first
            ...sorted.filter((token)=>token.symbol?.toLowerCase() === symbolMatch[0]),
            ...sorted.filter((token)=>token.symbol?.toLowerCase() !== symbolMatch[0]), 
        ];
    }, [
        filteredTokens,
        searchQuery,
        searchToken,
        tokenComparator
    ]);
    const handleCurrencySelect = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((currency)=>{
        onCurrencySelect(currency);
        onDismiss();
        if (audioPlay) {
            const audio = document.getElementById("bgMusic");
            if (audio) {
                audio.play();
            }
        }
    }, [
        onDismiss,
        onCurrencySelect,
        audioPlay
    ]);
    // clear the input on open
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (isOpen) setSearchQuery("");
    }, [
        isOpen
    ]);
    // manage focus on modal show
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((event)=>{
        const input = event.target.value;
        const checksummedInput = (0,_utils__WEBPACK_IMPORTED_MODULE_11__/* .isAddress */ .UJ)(input);
        setSearchQuery(checksummedInput || input);
        fixedList.current?.scrollTo(0);
    }, []);
    const handleEnter = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((e)=>{
        if (e.key === "Enter") {
            const s = searchQuery.toLowerCase().trim();
            if (s === "bnb") {
                handleCurrencySelect(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER);
            } else if (filteredSortedTokens.length > 0) {
                if (filteredSortedTokens[0].symbol?.toLowerCase() === searchQuery.trim().toLowerCase() || filteredSortedTokens.length === 1) {
                    handleCurrencySelect(filteredSortedTokens[0]);
                }
            }
        }
    }, [
        filteredSortedTokens,
        handleCurrencySelect,
        searchQuery
    ]);
    const selectedListInfo = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_9__/* .useSelectedListInfo */ .LQ)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
        style: {
            width: "100%"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styleds__WEBPACK_IMPORTED_MODULE_21__/* .PaddedColumn */ .AC, {
                gap: "14px",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_21__/* .SearchInput */ .Mj, {
                        type: "text",
                        id: "token-search-input",
                        placeholder: "Search name or paste address",
                        value: searchQuery,
                        ref: inputRef,
                        onChange: handleInput,
                        onKeyDown: handleEnter
                    }),
                    showCommonBases && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommonBases__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        chainId: chainId,
                        onSelect: handleCurrencySelect,
                        selectedCurrency: selectedCurrency
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_15__/* .RowBetween */ .m0, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                fontSize: "text-lg font-medium",
                                children: "Token name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SortButton__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                ascending: invertSearchOrder,
                                toggleSortOrder: ()=>setInvertSearchOrder((iso)=>!iso)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_21__/* .Separator */ .Z0, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "min-h-[600px]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_virtualized_auto_sizer__WEBPACK_IMPORTED_MODULE_6___default()), {
                    disableWidth: true,
                    children: ({ height  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyList__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                            height: height,
                            showETH: false,
                            currencies: filteredSortedTokens,
                            onCurrencySelect: handleCurrencySelect,
                            otherCurrency: otherSelectedCurrency,
                            selectedCurrency: selectedCurrency,
                            fixedListRef: fixedList
                        })
                })
            }),
            null && /*#__PURE__*/ 0
        ]
    });
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CurrencySearch)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 424:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ ListSelect)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_popper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2932);
/* harmony import */ var react_popper__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_popper__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9899);
/* harmony import */ var _hooks_useOnClickOutside__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5345);
/* harmony import */ var _hooks_useToggle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5392);
/* harmony import */ var _state_lists_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9775);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7256);
/* harmony import */ var _Shared__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8306);
/* harmony import */ var _utils_listVersionLabel__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7930);
/* harmony import */ var _utils_parseENSAddress__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6298);
/* harmony import */ var _utils_uriToHttp__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(7787);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(247);
/* harmony import */ var _ListLogo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7491);
/* harmony import */ var _QuestionHelper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3994);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(108);
/* harmony import */ var _styleds__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7770);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__, _ListLogo__WEBPACK_IMPORTED_MODULE_14__]);
([_hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__, _ListLogo__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const UnpaddedLinkStyledButton = styled_components__WEBPACK_IMPORTED_MODULE_6___default()(_Shared__WEBPACK_IMPORTED_MODULE_12__/* .LinkStyledButton */ .W1).withConfig({
    componentId: "sc-c54bfb02-0"
})`
  padding: 0;
  font-size: 1rem;
  opacity: ${({ disabled  })=>disabled ? "0.4" : "1"};
`;
const PopoverContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
    componentId: "sc-c54bfb02-1"
})`
  z-index: 100;
  visibility: ${(props)=>props.show ? "visible" : "hidden"};
  opacity: ${(props)=>props.show ? 1 : 0};
  transition: visibility 150ms linear, opacity 150ms linear;
  background: ${({ theme  })=>theme.colors.invertedContrast};
  border: 1px solid ${({ theme  })=>theme.colors.tertiary};
  box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.01), 0px 4px 8px rgba(0, 0, 0, 0.04), 0px 16px 24px rgba(0, 0, 0, 0.04),
    0px 24px 32px rgba(0, 0, 0, 0.01);
  color: ${({ theme  })=>theme.colors.textSubtle};
  border-radius: 0.5rem;
  padding: 1rem;
  display: grid;
  grid-template-rows: 1fr;
  grid-gap: 8px;
  font-size: 1rem;
  text-align: left;
`;
const StyledMenu = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
    componentId: "sc-c54bfb02-2"
})`
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  border: none;
`;
const StyledListUrlText = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
    componentId: "sc-c54bfb02-3"
})`
  max-width: 160px;
  opacity: 0.6;
  margin-right: 0.5rem;
  font-size: 14px;
  overflow: hidden;
  text-overflow: ellipsis;
`;
function ListOrigin({ listUrl  }) {
    const ensName = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>(0,_utils_parseENSAddress__WEBPACK_IMPORTED_MODULE_18__/* .parseENSAddress */ .y)(listUrl)?.ensName, [
        listUrl
    ]);
    const host = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (ensName) return undefined;
        const lowerListUrl = listUrl.toLowerCase();
        if (lowerListUrl.startsWith("ipfs://") || lowerListUrl.startsWith("ipns://")) {
            return listUrl;
        }
        try {
            const url = new URL(listUrl);
            return url.host;
        } catch (error) {
            return undefined;
        }
    }, [
        listUrl,
        ensName
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: ensName ?? host
    });
}
function listUrlRowHTMLId(listUrl) {
    return `list-row-${listUrl.replace(/\./g, "-")}`;
}
const ListRow = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(function ListRow({ listUrl , onBack  }) {
    const listsByUrl = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lists.byUrl);
    const selectedListUrl = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useSelectedListUrl */ .f5)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const { current: list , pendingUpdate: pending  } = listsByUrl[listUrl];
    const isSelected = listUrl === selectedListUrl;
    const [open, toggle] = (0,_hooks_useToggle__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(false);
    const node = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { 0: referenceElement , 1: setReferenceElement  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: popperElement , 1: setPopperElement  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { styles , attributes  } = (0,react_popper__WEBPACK_IMPORTED_MODULE_3__.usePopper)(referenceElement, popperElement, {
        placement: "auto",
        strategy: "fixed",
        modifiers: [
            {
                name: "offset",
                options: {
                    offset: [
                        8,
                        8
                    ]
                }
            }
        ]
    });
    (0,_hooks_useOnClickOutside__WEBPACK_IMPORTED_MODULE_8__/* .useOnClickOutside */ .t)(node, open ? toggle : undefined);
    const selectThisList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (isSelected) return;
        dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_10__/* .selectList */ .Fz)(listUrl));
        onBack();
    }, [
        dispatch,
        isSelected,
        listUrl,
        onBack
    ]);
    const handleAcceptListUpdate = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (!pending) return;
        dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_10__/* .acceptListUpdate */ .xJ)(listUrl));
    }, [
        dispatch,
        listUrl,
        pending
    ]);
    const handleRemoveList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (window.prompt(`Please confirm you would like to remove this list by typing REMOVE`) === `REMOVE`) {
            dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_10__/* .removeList */ .J_)(listUrl));
        }
    }, [
        dispatch,
        listUrl
    ]);
    if (!list) return null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .ZP, {
        align: "center",
        padding: "16px",
        id: listUrlRowHTMLId(listUrl),
        children: [
            list.logoURI ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListLogo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                style: {
                    marginRight: "1rem"
                },
                logoURI: list.logoURI,
                alt: `${list.name} list logo`
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    width: "24px",
                    height: "24px",
                    marginRight: "1rem"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
                style: {
                    flex: "1"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .ZP, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                            bold: isSelected,
                            fontSize: "16px",
                            style: {
                                overflow: "hidden",
                                textOverflow: "ellipsis"
                            },
                            children: list.name
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .ZP, {
                        style: {
                            marginTop: "4px"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledListUrlText, {
                            title: listUrl,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListOrigin, {
                                listUrl: listUrl
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledMenu, {
                ref: node,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            display: "inline-block"
                        },
                        ref: setReferenceElement,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                            style: {
                                width: "32px",
                                marginRight: "8px"
                            },
                            onClick: toggle,
                            variant: "secondary",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.ChevronDownIcon, {})
                        })
                    }),
                    open && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PopoverContainer, {
                        show: true,
                        ref: setPopperElement,
                        style: styles.popper,
                        ...attributes.popper,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: list && (0,_utils_listVersionLabel__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z)(list.version)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .SeparatorDark */ .zm, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Shared__WEBPACK_IMPORTED_MODULE_12__/* .ExternalLink */ .dL, {
                                href: `https://tokenlists.org/token-list?url=${listUrl}`,
                                children: "View list"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UnpaddedLinkStyledButton, {
                                onClick: handleRemoveList,
                                disabled: Object.keys(listsByUrl).length === 1,
                                children: "Remove list"
                            }),
                            pending && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UnpaddedLinkStyledButton, {
                                onClick: handleAcceptListUpdate,
                                children: "Update list"
                            })
                        ]
                    })
                ]
            }),
            isSelected ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                disabled: true,
                style: {
                    width: "5rem",
                    minWidth: "5rem"
                },
                children: "Selected"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                    className: "select-button",
                    style: {
                        width: "5rem",
                        minWidth: "4.5rem"
                    },
                    onClick: selectThisList,
                    children: "Select"
                })
            })
        ]
    }, listUrl);
});
const ListContainer = styled_components__WEBPACK_IMPORTED_MODULE_6___default().div.withConfig({
    componentId: "sc-c54bfb02-4"
})`
  flex: 1;
  overflow: auto;
`;
function ListSelect({ onDismiss , onBack  }) {
    const { 0: listUrlInput , 1: setListUrlInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const lists = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lists.byUrl);
    const adding = Boolean(lists[listUrlInput]?.loadingRequestId);
    const { 0: addError , 1: setAddError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleInput = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setListUrlInput(e.target.value);
        setAddError(null);
    }, []);
    const fetchList = (0,_hooks_useFetchListCallback__WEBPACK_IMPORTED_MODULE_7__/* .useFetchListCallback */ .j)();
    const handleAddList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        if (adding) return;
        setAddError(null);
        fetchList(listUrlInput).then(()=>{
            setListUrlInput("");
        }).catch((error)=>{
            setAddError(error.message);
            dispatch((0,_state_lists_actions__WEBPACK_IMPORTED_MODULE_10__/* .removeList */ .J_)(listUrlInput));
        });
    }, [
        adding,
        dispatch,
        fetchList,
        listUrlInput
    ]);
    const validUrl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_utils_uriToHttp__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z)(listUrlInput).length > 0 || Boolean((0,_utils_parseENSAddress__WEBPACK_IMPORTED_MODULE_18__/* .parseENSAddress */ .y)(listUrlInput));
    }, [
        listUrlInput
    ]);
    const handleEnterKey = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        if (validUrl && e.key === "Enter") {
            handleAddList();
        }
    }, [
        handleAddList,
        validUrl
    ]);
    const sortedLists = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const listUrls = Object.keys(lists);
        return listUrls.filter((listUrl)=>{
            return Boolean(lists[listUrl].current);
        }).sort((u1, u2)=>{
            const { current: l1  } = lists[u1];
            const { current: l2  } = lists[u2];
            if (l1 && l2) {
                return l1.name.toLowerCase() < l2.name.toLowerCase() ? -1 : l1.name.toLowerCase() === l2.name.toLowerCase() ? 0 : 1;
            }
            if (l1) return -1;
            if (l2) return 1;
            return 0;
        });
    }, [
        lists
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP, {
        style: {
            width: "100%",
            flex: "1 1"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .PaddedColumn */ .AC, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_16__/* .RowBetween */ .m0, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_2__.ArrowLeft, {
                                style: {
                                    cursor: "pointer"
                                },
                                onClick: onBack
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                            fontSize: "20px",
                            children: "Manage Lists"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.CloseIcon, {
                            onClick: onDismiss
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .Separator */ .Z0, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .PaddedColumn */ .AC, {
                gap: "14px",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        bold: true,
                        children: [
                            "Add a list",
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuestionHelper__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                text: "Token lists are an open specification for lists of BEP20 tokens. You can use any token list by entering its URL below. Beware that third party token lists can contain fake or malicious BEP20 tokens."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Row__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .ZP, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .SearchInput */ .Mj, {
                                type: "text",
                                id: "list-add-input",
                                placeholder: "https:// or ipfs:// or ENS name",
                                value: listUrlInput,
                                onChange: handleInput,
                                onKeyDown: handleEnterKey,
                                style: {
                                    height: "2.75rem",
                                    borderRadius: 12,
                                    padding: "12px"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                onClick: handleAddList,
                                style: {
                                    maxWidth: "4em",
                                    marginLeft: "1em"
                                },
                                disabled: !validUrl,
                                children: "Add"
                            })
                        ]
                    }),
                    addError ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.Text, {
                        color: "failure",
                        title: addError,
                        style: {
                            textOverflow: "ellipsis",
                            overflow: "hidden"
                        },
                        children: addError
                    }) : null
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .Separator */ .Z0, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListContainer, {
                children: sortedLists.map((listUrl)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListRow, {
                        listUrl: listUrl,
                        onBack: onBack
                    }, listUrl))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleds__WEBPACK_IMPORTED_MODULE_17__/* .Separator */ .Z0, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    padding: "16px",
                    textAlign: "center"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Shared__WEBPACK_IMPORTED_MODULE_12__/* .ExternalLink */ .dL, {
                    href: "https://tokenlists.org",
                    children: "Browse lists"
                })
            })
        ]
    });
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ListSelect)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SortButton)
});

// UNUSED EXPORTS: FilterWrapper

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./components/Row/index.tsx
var Row = __webpack_require__(108);
;// CONCATENATED MODULE: ./assets/btn-arrow-down.svg
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBtnArrowDown = function SvgBtnArrowDown(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 26,
    height: 26,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "m14.263 19.78 8.717-8.717 2.297 2.298L12.638 26-.002 13.36l2.299-2.297 8.716 8.716V0h3.25v19.78Z",
    fill: "#3985F5"
  })));
};
/* harmony default export */ const btn_arrow_down = (SvgBtnArrowDown);
;// CONCATENATED MODULE: ./components/SearchModal/SortButton.tsx





const FilterWrapper = external_styled_components_default()(Row/* RowFixed */.DA).withConfig({
    componentId: "sc-a928f65e-0"
})`
  padding: 4px;
  color: ${({ theme  })=>theme.colors.text};
  border-radius: 8px;
  user-select: none;
  & > * {
    user-select: none;
  }
  :hover {
    cursor: pointer;
  }
`;
function SortButton({ toggleSortOrder , ascending  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(FilterWrapper, {
        onClick: toggleSortOrder,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "rounded-full",
            children: ascending ? /*#__PURE__*/ jsx_runtime_.jsx(btn_arrow_down, {
                className: "rotate-180 w-8 h-8"
            }) : /*#__PURE__*/ jsx_runtime_.jsx(btn_arrow_down, {})
        })
    });
};


/***/ }),

/***/ 2937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ filterTokens)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8847);

function filterTokens(tokens, search) {
    if (search.length === 0) return tokens;
    const searchingAddress = (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .isAddress */ .UJ)(search);
    if (searchingAddress) {
        return tokens.filter((token)=>token.address === searchingAddress);
    }
    const lowerSearchParts = search.toLowerCase().split(/\s+/).filter((s)=>s.length > 0);
    if (lowerSearchParts.length === 0) {
        return tokens;
    }
    const matchesSearch = (s)=>{
        const sParts = s.toLowerCase().split(/\s+/).filter((str)=>str.length > 0);
        return lowerSearchParts.every((p)=>p.length === 0 || sParts.some((sp)=>sp.startsWith(p) || sp.endsWith(p)));
    };
    return tokens.filter((token)=>{
        const { symbol , name  } = token;
        return symbol && matchesSearch(symbol) || name && matchesSearch(name);
    });
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (filterTokens)));


/***/ }),

/***/ 5335:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useTokenComparator)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1023);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__]);
_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// compare two token amounts with highest one coming first
function balanceComparator(balanceA, balanceB) {
    if (balanceA && balanceB) {
        return balanceA.greaterThan(balanceB) ? -1 : balanceA.equalTo(balanceB) ? 0 : 1;
    }
    if (balanceA && balanceA.greaterThan("0")) {
        return -1;
    }
    if (balanceB && balanceB.greaterThan("0")) {
        return 1;
    }
    return 0;
}
function getTokenComparator(balances) {
    return function sortTokens(tokenA, tokenB) {
        // -1 = a is first
        // 1 = b is first
        // sort by balances
        const balanceA = balances[tokenA.address];
        const balanceB = balances[tokenB.address];
        const balanceComp = balanceComparator(balanceA, balanceB);
        if (balanceComp !== 0) return balanceComp;
        if (tokenA.symbol && tokenB.symbol) {
            // sort by symbol
            return tokenA.symbol.toLowerCase() < tokenB.symbol.toLowerCase() ? -1 : 1;
        }
        return tokenA.symbol ? -1 : tokenB.symbol ? -1 : 0;
    };
}
function useTokenComparator(inverted) {
    const balances = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAllTokenBalances */ .uD)();
    const comparator = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>getTokenComparator(balances ?? {}), [
        balances
    ]);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (inverted) {
            return (tokenA, tokenB)=>comparator(tokenA, tokenB) * -1;
        }
        return comparator;
    }, [
        inverted,
        comparator
    ]);
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useTokenComparator)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$3": () => (/* binding */ FadedSpan),
/* harmony export */   "AC": () => (/* binding */ PaddedColumn),
/* harmony export */   "Mj": () => (/* binding */ SearchInput),
/* harmony export */   "Z0": () => (/* binding */ Separator),
/* harmony export */   "sN": () => (/* binding */ MenuItem),
/* harmony export */   "zm": () => (/* binding */ SeparatorDark)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(247);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(108);



const FadedSpan = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Row__WEBPACK_IMPORTED_MODULE_2__/* .RowFixed */ .DA).withConfig({
    componentId: "sc-d7164b3e-0"
})`
  color: ${({ theme  })=>theme.colors.primary};
  font-size: 14px;
`;
const PaddedColumn = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Column__WEBPACK_IMPORTED_MODULE_1__/* .AutoColumn */ .Tz).withConfig({
    componentId: "sc-d7164b3e-1"
})`
  // padding: 20px;
  padding-bottom: 12px;
`;
const MenuItem = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Row__WEBPACK_IMPORTED_MODULE_2__/* .RowBetween */ .m0).withConfig({
    componentId: "sc-d7164b3e-2"
})`
  padding: 4px 20px;
  height: 56px;
  display: grid;
  grid-template-columns: auto minmax(auto, 1fr) auto minmax(0, 72px);
  grid-gap: 16px;
  cursor: ${({ disabled  })=>!disabled && "pointer"};
  pointer-events: ${({ disabled  })=>disabled && "none"};
  :hover {
    background-color: ${({ theme , disabled  })=>!disabled && theme.colors.invertedContrast};
  }
  opacity: ${({ disabled , selected  })=>disabled || selected ? 0.5 : 1};
`;
const SearchInput = styled_components__WEBPACK_IMPORTED_MODULE_0___default().input.withConfig({
    componentId: "sc-d7164b3e-3"
})`
  position: relative;
  display: flex;
  padding: 16px;
  align-items: center;
  width: 100%;
  white-space: nowrap;
  background: #DEDEDE;
  border: none;
  outline: none;
  focus:outline: none;
  
  border-radius: 8px;
  color: ${({ theme  })=>theme.colors.text};
  border-style: solid;
  border: 1px solid ${({ theme  })=>theme.colors.tertiary};
  -webkit-appearance: none;

  font-size: 18px;

  ::placeholder {
    color: ${({ theme  })=>theme.colors.textDisabled};
  }
  transition: border 100ms;
  :focus {
    // border: 1px solid ${({ theme  })=>theme.colors.primary};
    outline: none;
  }
`;
const Separator = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-d7164b3e-4"
})`
  width: 100%;
  height: 1px;
  background-color: ${({ theme  })=>theme.colors.invertedContrast};
`;
const SeparatorDark = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-d7164b3e-5"
})`
  width: 100%;
  height: 1px;
  background-color: ${({ theme  })=>theme.colors.tertiary};
`;


/***/ }),

/***/ 8306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "dL": () => (/* reexport */ ExternalLink),
  "W1": () => (/* reexport */ LinkStyledButton),
  "$j": () => (/* reexport */ Spinner),
  "m_": () => (/* reexport */ StyledInternalLink)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/Shared/Common.tsx




// A button that triggers some onClick result, but looks like a link.
const LinkStyledButton = external_styled_components_default().button.withConfig({
    componentId: "sc-2a22a0da-0"
})`
  border: none;
  text-decoration: none;
  background: none;

  cursor: ${({ disabled  })=>disabled ? "default" : "pointer"};
  color: ${({ theme , disabled  })=>disabled ? theme.colors.textSubtle : theme.colors.primary};
  font-weight: 500;

  :hover {
    text-decoration: ${({ disabled  })=>disabled ? null : "underline"};
  }

  :focus {
    outline: none;
    text-decoration: ${({ disabled  })=>disabled ? null : "underline"};
  }

  :active {
    text-decoration: none;
  }
`;
// An internal link from the react-router-dom library that is correctly styled
const StyledInternalLink = external_styled_components_default()((link_default())).withConfig({
    componentId: "sc-2a22a0da-1"
})`
  text-decoration: none;
  cursor: pointer;
  color: ${({ theme  })=>theme.colors.primary};
  font-weight: 500;

  :hover {
    text-decoration: underline;
  }

  :focus {
    outline: none;
    text-decoration: underline;
  }

  :active {
    text-decoration: none;
  }
`;
const StyledLink = external_styled_components_default().a.withConfig({
    componentId: "sc-2a22a0da-2"
})`
  text-decoration: none;
  cursor: pointer;
  color: ${({ theme  })=>theme.colors.primary};
  font-weight: 500;

  :hover {
    text-decoration: underline;
  }

  :focus {
    outline: none;
    text-decoration: underline;
  }

  :active {
    text-decoration: none;
  }
`;
/**
 * Outbound link that handles firing google analytics events
 */ function ExternalLink({ target ="_blank" , href , rel ="noopener noreferrer" , ...rest }) {
    const handleClick = (0,external_react_.useCallback)((event)=>{
        if (!(target === "_blank" || event.ctrlKey || event.metaKey)) {
            event.preventDefault();
        }
    }, [
        target
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(StyledLink, {
        target: target,
        rel: rel,
        href: href,
        onClick: handleClick,
        ...rest
    });
}
const rotate = external_styled_components_.keyframes`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`;
const Spinner = external_styled_components_default().img.withConfig({
    componentId: "sc-2a22a0da-3"
})`
  animation: 2s ${rotate} linear infinite;
  width: 16px;
  height: 16px;
`;

;// CONCATENATED MODULE: ./components/Shared/index.tsx



/***/ }),

/***/ 375:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TokenModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6921);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6524);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _SearchModal_ListSelect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(424);
/* harmony import */ var _SearchModal_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7609);
/* harmony import */ var _hooks_useLast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7036);
/* harmony import */ var _state_lists_hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7256);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SearchModal_ListSelect__WEBPACK_IMPORTED_MODULE_5__, _SearchModal_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__]);
([_SearchModal_ListSelect__WEBPACK_IMPORTED_MODULE_5__, _SearchModal_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react-hooks/exhaustive-deps */ /* eslint-disable @next/next/no-img-element */ 









function TokenModal({ isOpen , onDismiss , onCurrencySelect , selectedCurrency , otherSelectedCurrency , showCommonBases  }) {
    const { 0: listView , 1: setListView  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const lastOpen = (0,_hooks_useLast__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(isOpen);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isOpen && !lastOpen) {
            setListView(false);
        }
    }, [
        isOpen,
        lastOpen
    ]);
    const handleCurrencySelect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((currency)=>{
        onCurrencySelect(currency);
        onDismiss();
    }, [
        onDismiss,
        onCurrencySelect
    ]);
    const handleClickChangeList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setListView(true);
    }, []);
    const handleClickBack = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setListView(false);
    }, []);
    const selectedListUrl = (0,_state_lists_hooks__WEBPACK_IMPORTED_MODULE_8__/* .useSelectedListUrl */ .f5)();
    const noListSelected = !selectedListUrl;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "fixed w-screen h-screen bg-[#242424] top-0 left-0 bg-opacity-50 flex justify-end z-20",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "hidden md:flex w-10 h-10 bg-[#f2f3f5] rounded-full justify-center items-center mr-8 mt-20",
                onClick: onDismiss,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    className: "w-5 h-5 stroke-[#242424]"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-2xl w-full h-screen bg-[#F2F3F5] opacity-100 shrink-0 pt-10 md:pt-20 px-10 overflow-y-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "flex md:hidden w-10 h-10 ml-auto bg-[#f2f3f5] rounded-full justify-center items-center mb-8",
                        onClick: onDismiss,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_cross_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            className: "w-5 h-5 stroke-[#242424]"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-end justify-between mb-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-5xl font-bold uppercase",
                            children: "Select a token"
                        })
                    }),
                    listView ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchModal_ListSelect__WEBPACK_IMPORTED_MODULE_5__/* .ListSelect */ .H, {
                        onDismiss: onDismiss,
                        onBack: handleClickBack
                    }) : noListSelected ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchModal_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__/* .CurrencySearch */ .$, {
                        isOpen: isOpen,
                        onDismiss: onDismiss,
                        onCurrencySelect: handleCurrencySelect,
                        onChangeList: handleClickChangeList,
                        selectedCurrency: selectedCurrency,
                        otherSelectedCurrency: otherSelectedCurrency,
                        showCommonBases: false
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchModal_CurrencySearch__WEBPACK_IMPORTED_MODULE_6__/* .CurrencySearch */ .$, {
                        isOpen: isOpen,
                        onDismiss: onDismiss,
                        onCurrencySelect: handleCurrencySelect,
                        onChangeList: handleClickChangeList,
                        selectedCurrency: selectedCurrency,
                        otherSelectedCurrency: otherSelectedCurrency,
                        showCommonBases: false
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2071:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7883);



const ConfirmationModalContent = ({ title , bottomContent , onDismiss , topContent  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_2__/* .Wrapper */ .im, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_2__/* .Section */ .$0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_2__/* .ContentHeader */ .yW, {
                        onDismiss: onDismiss,
                        children: title
                    }),
                    topContent()
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_2__/* .BottomSection */ .$B, {
                gap: "12px",
                children: bottomContent()
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmationModalContent);


/***/ }),

/***/ 420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Shared__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8306);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(247);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7883);







const CustomLightSpinner = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Shared__WEBPACK_IMPORTED_MODULE_4__/* .Spinner */ .$j).withConfig({
    componentId: "sc-985ada37-0"
})`
  height: ${({ size  })=>size};
  width: ${({ size  })=>size};
`;
const ConfirmationPendingContent = ({ onDismiss , pendingText  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .Wrapper */ .im, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .Section */ .$0, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .ContentHeader */ .yW, {
                    onDismiss: onDismiss,
                    children: "Waiting for confirmation"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .ConfirmedIcon */ .E0, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomLightSpinner, {
                        src: "/images/blue-loader.svg",
                        alt: "loader",
                        size: "90px"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                    gap: "12px",
                    justify: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                            gap: "12px",
                            justify: "center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                fontSize: "14px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                    children: pendingText
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                            fontSize: "14px",
                            children: "Confirm this transaction in your wallet"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfirmationPendingContent);


/***/ }),

/***/ 4135:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6305);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5820);
/* harmony import */ var _ConfirmationPendingContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(420);
/* harmony import */ var _TransactionSubmittedContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7658);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_3__]);
_hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const TransactionConfirmationModal = ({ isOpen , onDismiss , attemptingTxn , hash , pendingText , content  })=>{
    const { chainId  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActiveWeb3React */ .aQ)();
    if (!chainId) return null;
    // confirmation screen
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        isOpen: isOpen,
        onDismiss: onDismiss,
        maxHeight: 90,
        children: attemptingTxn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ConfirmationPendingContent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            onDismiss: onDismiss,
            pendingText: pendingText
        }) : hash ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TransactionSubmittedContent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            chainId: chainId,
            hash: hash,
            onDismiss: onDismiss
        }) : content()
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionConfirmationModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(247);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7883);







const TransactionErrorContent = ({ message , onDismiss  })=>{
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(styled_components__WEBPACK_IMPORTED_MODULE_2__.ThemeContext);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .Wrapper */ .im, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .Section */ .$0, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .ContentHeader */ .yW, {
                        onDismiss: onDismiss,
                        children: "Error"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                        style: {
                            marginTop: 20,
                            padding: "2rem 0"
                        },
                        gap: "24px",
                        justify: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_4__.AlertTriangle, {
                                color: theme.colors.failure,
                                style: {
                                    strokeWidth: 1.5
                                },
                                size: 64
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                fontSize: "16px",
                                color: "failure",
                                style: {
                                    textAlign: "center",
                                    width: "85%"
                                },
                                children: message
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_6__/* .BottomSection */ .$B, {
                gap: "12px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                    onClick: onDismiss,
                    children: "Dismiss"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionErrorContent);


/***/ }),

/***/ 7658:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9101);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(247);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8847);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7883);








const TransactionSubmittedContent = ({ onDismiss , chainId , hash  })=>{
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(styled_components__WEBPACK_IMPORTED_MODULE_2__.ThemeContext);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_7__/* .Wrapper */ .im, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_helpers__WEBPACK_IMPORTED_MODULE_7__/* .Section */ .$0, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_7__/* .ContentHeader */ .yW, {
                    onDismiss: onDismiss,
                    children: "Transaction submitted"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_helpers__WEBPACK_IMPORTED_MODULE_7__/* .ConfirmedIcon */ .E0, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_4__.ArrowUpCircle, {
                        strokeWidth: 0.5,
                        size: 97,
                        color: theme.colors.primary
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_5__/* .AutoColumn */ .Tz, {
                    gap: "8px",
                    justify: "center",
                    children: [
                        chainId && hash && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.LinkExternal, {
                            href: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .getBscScanLink */ .s6)(chainId, hash, "transaction"),
                            children: "View on BscScan"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            onClick: onDismiss,
                            mt: "20px",
                            children: "Close"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransactionSubmittedContent);


/***/ }),

/***/ 7883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$0": () => (/* binding */ Section),
/* harmony export */   "$B": () => (/* binding */ BottomSection),
/* harmony export */   "E0": () => (/* binding */ ConfirmedIcon),
/* harmony export */   "im": () => (/* binding */ Wrapper),
/* harmony export */   "yW": () => (/* binding */ ContentHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(247);





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-dba0b8d-0"
})`
  width: 100%;
  overflow-y: auto;
`;
const Section = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz).withConfig({
    componentId: "sc-dba0b8d-1"
})`
  padding: 24px;
`;
const ConfirmedIcon = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(_Column__WEBPACK_IMPORTED_MODULE_4__/* .ColumnCenter */ .lg).withConfig({
    componentId: "sc-dba0b8d-2"
})`
  padding: 40px 0;
`;
const BottomSection = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(Section).withConfig({
    componentId: "sc-dba0b8d-3"
})`
  background-color: ${({ theme  })=>theme.colors.invertedContrast};
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
`;
/**
 * TODO: Remove this when modal system from the UI Kit is implemented
 */ const StyledContentHeader = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
    componentId: "sc-dba0b8d-4"
})`
  align-items: center;
  display: flex;

  & > ${_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading} {
    flex: 1;
  }
`;
const ContentHeader = ({ children , onDismiss  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledContentHeader, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.Heading, {
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                onClick: onDismiss,
                variant: "text",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_3__.CloseIcon, {
                    color: "primary"
                })
            })
        ]
    });


/***/ }),

/***/ 6002:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "ht": () => (/* reexport safe */ _TransactionErrorContent__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "pM": () => (/* reexport safe */ _ConfirmationModalContent__WEBPACK_IMPORTED_MODULE_1__.Z)
/* harmony export */ });
/* harmony import */ var _TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4135);
/* harmony import */ var _ConfirmationModalContent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2071);
/* harmony import */ var _ConfirmationPendingContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(420);
/* harmony import */ var _TransactionErrorContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1794);
/* harmony import */ var _TransactionSubmittedContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7658);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_0__]);
_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_TransactionConfirmationModal__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useTokenAllowance)
/* harmony export */ });
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5307);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useContract__WEBPACK_IMPORTED_MODULE_2__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__]);
([_hooks_useContract__WEBPACK_IMPORTED_MODULE_2__, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function useTokenAllowance(token, owner, spender) {
    const contract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useTokenContract */ .Ib)(token?.address, false);
    const inputs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>[
            owner,
            spender
        ], [
        owner,
        spender
    ]);
    const allowance = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useSingleCallResult */ .Wk)(contract, "allowance", inputs).result;
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>token && allowance ? new _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_0__.TokenAmount(token, allowance.toString()) : undefined, [
        token,
        allowance, 
    ]);
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useTokenAllowance)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2945:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UK": () => (/* binding */ ApprovalState),
/* harmony export */   "qL": () => (/* binding */ useApproveCallback),
/* harmony export */   "re": () => (/* binding */ useApproveCallbackFromTrade)
/* harmony export */ });
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6644);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7974);
/* harmony import */ var _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1407);
/* harmony import */ var _data_Allowances__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3405);
/* harmony import */ var _state_swap_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9911);
/* harmony import */ var _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7507);
/* harmony import */ var _utils_prices__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9577);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8847);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5307);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_data_Allowances__WEBPACK_IMPORTED_MODULE_4__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_6__, _useContract__WEBPACK_IMPORTED_MODULE_9__, _index__WEBPACK_IMPORTED_MODULE_10__]);
([_data_Allowances__WEBPACK_IMPORTED_MODULE_4__, _state_transactions_hooks__WEBPACK_IMPORTED_MODULE_6__, _useContract__WEBPACK_IMPORTED_MODULE_9__, _index__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











var ApprovalState;
(function(ApprovalState) {
    ApprovalState[ApprovalState["UNKNOWN"] = 0] = "UNKNOWN";
    ApprovalState[ApprovalState["NOT_APPROVED"] = 1] = "NOT_APPROVED";
    ApprovalState[ApprovalState["PENDING"] = 2] = "PENDING";
    ApprovalState[ApprovalState["APPROVED"] = 3] = "APPROVED";
})(ApprovalState || (ApprovalState = {}));
// returns a variable indicating the state of the approval and a function which approves if necessary or early returns
function useApproveCallback(amountToApprove, spender) {
    const { account  } = (0,_index__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .aQ)();
    const token = amountToApprove instanceof _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.TokenAmount ? amountToApprove.token : undefined;
    const currentAllowance = (0,_data_Allowances__WEBPACK_IMPORTED_MODULE_4__/* .useTokenAllowance */ .F)(token, account ?? undefined, spender);
    const pendingApproval = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useHasPendingApproval */ .wB)(token?.address, spender);
    // check the current approval status
    const approvalState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!amountToApprove || !spender) return ApprovalState.UNKNOWN;
        if (amountToApprove.currency === _pancakeswap_libs_sdk__WEBPACK_IMPORTED_MODULE_1__.ETHER) return ApprovalState.APPROVED;
        // we might not have enough data to know whether or not we need to approve
        if (!currentAllowance) return ApprovalState.UNKNOWN;
        // amountToApprove will be defined if currentAllowance is
        return currentAllowance.lessThan(amountToApprove) ? pendingApproval ? ApprovalState.PENDING : ApprovalState.NOT_APPROVED : ApprovalState.APPROVED;
    }, [
        amountToApprove,
        currentAllowance,
        pendingApproval,
        spender
    ]);
    const tokenContract = (0,_useContract__WEBPACK_IMPORTED_MODULE_9__/* .useTokenContract */ .Ib)(token?.address);
    const addTransaction = (0,_state_transactions_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTransactionAdder */ .h7)();
    const approve = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ()=>{
        if (approvalState !== ApprovalState.NOT_APPROVED) {
            console.error("approve was called unnecessarily");
            return;
        }
        if (!token) {
            console.error("no token");
            return;
        }
        if (!tokenContract) {
            console.error("tokenContract is null");
            return;
        }
        if (!amountToApprove) {
            console.error("missing amount to approve");
            return;
        }
        if (!spender) {
            console.error("no spender");
            return;
        }
        let useExact = false;
        const estimatedGas = await tokenContract.estimateGas.approve(spender, _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__.MaxUint256).catch(()=>{
            // general fallback for tokens who restrict approval amounts
            useExact = true;
            return tokenContract.estimateGas.approve(spender, amountToApprove.raw.toString());
        });
        // eslint-disable-next-line consistent-return
        return tokenContract.approve(spender, useExact ? amountToApprove.raw.toString() : _ethersproject_constants__WEBPACK_IMPORTED_MODULE_0__.MaxUint256, {
            gasLimit: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .calculateGasMargin */ .yC)(estimatedGas)
        }).then((response)=>{
            addTransaction(response, {
                summary: `Approve ${amountToApprove.currency.symbol}`,
                approval: {
                    tokenAddress: token.address,
                    spender
                }
            });
        }).catch((error)=>{
            console.error("Failed to approve token", error);
            throw error;
        });
    }, [
        approvalState,
        token,
        tokenContract,
        amountToApprove,
        spender,
        addTransaction
    ]);
    return [
        approvalState,
        approve
    ];
}
// wraps useApproveCallback in the context of a swap
function useApproveCallbackFromTrade(trade, allowedSlippage = 0) {
    const amountToApprove = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>trade ? (0,_utils_prices__WEBPACK_IMPORTED_MODULE_7__/* .computeSlippageAdjustedAmounts */ .b5)(trade, allowedSlippage)[_state_swap_actions__WEBPACK_IMPORTED_MODULE_5__/* .Field.INPUT */ .gN.INPUT] : undefined, [
        trade,
        allowedSlippage
    ]);
    return useApproveCallback(amountToApprove, _constants__WEBPACK_IMPORTED_MODULE_3__/* .ROUTER_ADDRESS */ .bR);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2501:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8454);
/* harmony import */ var _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6590);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9795);
/* harmony import */ var _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3912);
/* harmony import */ var _pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks_useToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7284);
/* harmony import */ var _connectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3966);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_connectors__WEBPACK_IMPORTED_MODULE_7__]);
_connectors__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const useAuth = ()=>{
    const { activate , deactivate  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_1__.useWeb3React)();
    const { toastError  } = (0,_hooks_useToast__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const login = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((connectorID)=>{
        const connector = _connectors__WEBPACK_IMPORTED_MODULE_7__/* .connectorsByName */ .BA[connectorID];
        if (connector) {
            activate(connector, async (error)=>{
                window.localStorage.removeItem(_pancakeswap_libs_uikit__WEBPACK_IMPORTED_MODULE_5__.connectorLocalStorageKey);
                if (error instanceof _web3_react_core__WEBPACK_IMPORTED_MODULE_1__.UnsupportedChainIdError) {
                    toastError("Unsupported Chain Id", "Unsupported Chain Id Error. Check your chain Id.");
                } else if (error instanceof _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_3__.NoEthereumProviderError || error instanceof _binance_chain_bsc_connector__WEBPACK_IMPORTED_MODULE_2__.NoBscProviderError) {
                    toastError("Provider Error", "No provider was found");
                } else if (error instanceof _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_3__.UserRejectedRequestError || error instanceof _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_4__.UserRejectedRequestError) {
                    if (connector instanceof _web3_react_walletconnect_connector__WEBPACK_IMPORTED_MODULE_4__.WalletConnectConnector) {
                        const walletConnector = connector;
                        walletConnector.walletConnectProvider = null;
                    }
                    toastError("Authorization Error", "Please authorize to access your account");
                } else {
                    toastError(error.name, error.message);
                }
            });
        } else {
            toastError("Can't find connector", "The connector config is wrong");
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return {
        login,
        logout: deactivate
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAuth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useLastTruthy),
/* harmony export */   "Z": () => (/* binding */ useLast)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Returns the last value of type T that passes a filter function
 * @param value changing value
 * @param filterFn function that determines whether a given value should be considered for the last value
 */ function useLast(value, filterFn) {
    const { 0: last , 1: setLast  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(filterFn && filterFn(value) ? value : undefined);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setLast((prev)=>{
            const shouldUse = filterFn ? filterFn(value) : true;
            if (shouldUse) return value;
            return prev;
        });
    }, [
        filterFn,
        value
    ]);
    return last;
};
function isDefined(x) {
    return x !== null && x !== undefined;
}
/**
 * Returns the last truthy value of type T
 * @param value changing value
 */ function useLastTruthy(value) {
    return useLast(value, isDefined);
}


/***/ }),

/***/ 5345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ useOnClickOutside)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useOnClickOutside(node, handler) {
    const handlerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(handler);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        handlerRef.current = handler;
    }, [
        handler
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const handleClickOutside = (e)=>{
            if (node.current?.contains(e.target) ?? false) {
                return;
            }
            if (handlerRef.current) handlerRef.current();
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        node
    ]);
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useOnClickOutside)));


/***/ }),

/***/ 7284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hooks_useToast)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
// EXTERNAL MODULE: external "@pancakeswap-libs/uikit"
var uikit_ = __webpack_require__(3912);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: ./state/toasts/index.ts
/* eslint-disable no-param-reassign */ 
const initialState = {
    data: []
};
const toastsSlice = (0,toolkit_.createSlice)({
    name: "toasts",
    initialState,
    reducers: {
        push: (state, action)=>{
            const { payload  } = action;
            const toastIndex = state.data.findIndex((toast)=>toast.id === action.payload.id);
            // If id already matches remove it before adding it to the top of the stack
            if (toastIndex >= 0) {
                state.data.splice(toastIndex, 1);
            }
            state.data.unshift(payload);
        },
        remove: (state, action)=>{
            const toastIndex = state.data.findIndex((toast)=>toast.id === action.payload);
            if (toastIndex >= 0) {
                state.data.splice(toastIndex, 1);
            }
        },
        clear: (state)=>{
            state.data = [];
        }
    }
});
// Actions
const { clear , remove , push: toasts_push  } = toastsSlice.actions;
/* harmony default export */ const toasts = (toastsSlice.reducer);

;// CONCATENATED MODULE: ./state/actions.ts


;// CONCATENATED MODULE: ./hooks/useToast.ts





// Toasts
const useToast = ()=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const helpers = (0,external_react_.useMemo)(()=>{
        const push = (toast)=>dispatch(toasts_push(toast));
        return {
            toastError: (title, description)=>{
                return push({
                    id: (0,external_lodash_.kebabCase)(title),
                    type: uikit_.toastTypes.DANGER,
                    title,
                    description
                });
            },
            toastInfo: (title, description)=>{
                return push({
                    id: (0,external_lodash_.kebabCase)(title),
                    type: uikit_.toastTypes.INFO,
                    title,
                    description
                });
            },
            toastSuccess: (title, description)=>{
                return push({
                    id: (0,external_lodash_.kebabCase)(title),
                    type: uikit_.toastTypes.SUCCESS,
                    title,
                    description
                });
            },
            toastWarning: (title, description)=>{
                return push({
                    id: (0,external_lodash_.kebabCase)(title),
                    type: uikit_.toastTypes.WARNING,
                    title,
                    description
                });
            },
            push,
            remove: (id)=>dispatch(remove(id)),
            clear: ()=>dispatch(clear())
        };
    }, [
        dispatch
    ]);
    return helpers;
};
/* harmony default export */ const hooks_useToast = (useToast);


/***/ }),

/***/ 5392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useToggle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useToggle(initialState = false) {
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
    const toggle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>setState((prev)=>!prev), []);
    return [
        state,
        toggle
    ];
};


/***/ }),

/***/ 7930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ listVersionLabel)
/* harmony export */ });
function listVersionLabel(version) {
    return `v${version.major}.${version.minor}.${version.patch}`;
};


/***/ })

};
;