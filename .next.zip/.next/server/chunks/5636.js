exports.id = 5636;
exports.ids = [5636];
exports.modules = {

/***/ 6333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgChevron = function SvgChevron(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 16 10",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    opacity: 0.5,
    d: "m1.334 1.667 6.667 6.666 6.666-6.666"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgChevron);

/***/ }),

/***/ 6524:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCross = function SvgCross(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 21 20",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#242424",
    d: "M.947 0 19.9 18.952l-.947.947L0 .948z"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#242424",
    d: "M.102 19.053 19.053.1l.948.947L1.049 20z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCross);

/***/ }),

/***/ 1902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _rect, _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMarketplace = function SvgMarketplace(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 16,
    height: 20,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _rect || (_rect = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 6,
    y: 4,
    width: 10,
    height: 16,
    rx: 2,
    fill: "#3985F5"
  })), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3V6a3 3 0 0 1 3-3h2V2a2 2 0 0 0-2-2H2Z",
    fill: "#3985F5"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgMarketplace);

/***/ }),

/***/ 6623:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "Preloader_wrapper__8h9IR",
	"preloader": "Preloader_preloader__VtOJY",
	"lds-ring": "Preloader_lds-ring__xOS8Z"
};


/***/ }),

/***/ 2782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Account)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-moralis"
var external_react_moralis_ = __webpack_require__(6921);
// EXTERNAL MODULE: external "@web3auth/web3auth"
var web3auth_ = __webpack_require__(4040);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./assets/chevron.svg
var chevron = __webpack_require__(6333);
// EXTERNAL MODULE: ./hooks/useOutsideClick.js
var useOutsideClick = __webpack_require__(5806);
;// CONCATENATED MODULE: ./assets/bell.svg
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBell = function SvgBell(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 18,
    height: 19,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M15.666 13.166h1.667v1.667H.667v-1.667h1.666V7.333a6.667 6.667 0 0 1 13.334 0v5.833Zm-1.666 0V7.333a5 5 0 1 0-10 0v5.833h10ZM6.5 16.5h5v1.666h-5V16.5Z",
    fill: "#90E040"
  })));
};
/* harmony default export */ const bell = (SvgBell);
// EXTERNAL MODULE: external "react-bootstrap-icons"
var external_react_bootstrap_icons_ = __webpack_require__(3468);
;// CONCATENATED MODULE: ./components/Account.js
/* eslint-disable @next/next/no-img-element */ /* eslint-disable react-hooks/exhaustive-deps */ 








const isBrowser = "undefined" !== "undefined";
function Account({ setIsLoading , openEventsModal , onAuth  }) {
    const ref = (0,external_react_.useRef)(null);
    const { Moralis , user , logout , isAuthenticated  } = (0,external_react_moralis_.useMoralis)();
    const { 0: userMenuOpen , 1: setUserMenuOpen  } = (0,external_react_.useState)(false);
    const profilePicture = user?.attributes.profile_picture;
    (0,external_react_.useEffect)(()=>{
        if (!isBrowser) return;
        if (isAuthenticated) {
            const loadEmail = async ()=>{
                try {
                    const web3Auth = new web3auth_.Web3Auth({
                        clientId: "BCNz7x5YxmsUXljrYxTHt5jI3pWb7e8TKMqVsntTkYHYPplVClVH0c3qd9wiJx2PKYbAz-t-nw8Uzj3IT5JqeQE",
                        chainConfig: {
                            chainNamespace: "eip155",
                            chainId: "0x61",
                            rpcTarget: "https://data-seed-prebsc-1-s3.binance.org:8545",
                            displayName: "BinanceTestnet",
                            blockExplorer: "https://testnet.bscscan.com/",
                            ticker: "tBNB",
                            tickerName: "Binance"
                        }
                    });
                    await web3Auth.initModal();
                    const userInfo = await web3Auth.getUserInfo();
                    if (userInfo.email) {
                        const isEmail = await Moralis.Cloud.run("searchEmail", {
                            email: userInfo.email,
                            ethAddress: address
                        });
                        if (isEmail) {
                            const { id  } = user;
                            await logout();
                            const result = await Moralis.Cloud.run("deleteRecord", {
                                id
                            });
                            if (result) {
                                alert("This email already exist");
                                router_.Router.push("/");
                            }
                        } else {
                            const { id: id1  } = user;
                            const result1 = await Moralis.Cloud.run("addEmail", {
                                id: id1,
                                email: userInfo.email
                            });
                            if (result1) {
                                router_.Router.push("/");
                            }
                        }
                    } else {
                        if (!user.attributes.email) {} else {
                            router_.Router.push("/");
                        }
                    }
                } catch (error) {
                // console.log('catch', error);
                }
            };
            loadEmail();
        }
    }, [
        isAuthenticated,
        router_.Router,
        logout,
        user
    ]);
    const getUserName = ()=>{
        if (user && user.attributes.nickname) {
            return user.attributes.nickname;
        }
        const { ethAddress  } = user?.attributes;
        return `${ethAddress?.slice(0, 6)}...${ethAddress?.slice(-4)}`;
    };
    const toggleUserMenu = ()=>setUserMenuOpen((userMenuOpen)=>!userMenuOpen);
    const closeUserMenu = ()=>setUserMenuOpen(false);
    (0,useOutsideClick/* default */.Z)(ref, closeUserMenu);
    if (isAuthenticated) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            ref: ref,
            className: "relative flex items-center justify-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: toggleUserMenu,
                    className: "flex items-center lg:flex-row flex-col",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[30px] h-[30px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: profilePicture && profilePicture ? profilePicture : "/assets/user.png",
                            width: "30px",
                            height: "30px",
                            className: "rounded-full bg-[#90e040]",
                            alt: "profile picture 22"
                        })
                    })
                }),
                userMenuOpen && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute top-16 shadow-[0_0px_10px_2px_rgba(0,30,0,0.15)] rounded-lg bg-white nav-dropdown",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-between items-center py-6 h-[250px] w-[200px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col justify-center items-center px-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: profilePicture && profilePicture ? profilePicture : "/assets/user.png",
                                        width: "60px",
                                        height: "60px",
                                        className: "rounded-full bg-[#90e040]",
                                        alt: "profile picture 22"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-lg text-[#242424]",
                                        children: getUserName()
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex gap-x-5 justify-center items-center cursor-pointer hover:bg-[#F2F7F2] py-2 w-full",
                                onClick: logout,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_icons_.BoxArrowInRight, {
                                        size: "20"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-lg text-[#242424] uppercase",
                                        children: "Logout"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-12 w-[1px] bg-[#242424] mx-4 opacity-30"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "h-8 w-8 rounded-full bg-[#F3F4F6] shrink-0 flex justify-center items-center",
                    onClick: openEventsModal,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(bell, {})
                })
            ]
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx("button", {
            onClick: onAuth,
            type: "button",
            className: "hidden sm:flex items-center bg-[#ffffff] py-2 px-6 rounded-full font-bold text-[20px] text-black uppercase h-16",
            children: "connect wallet"
        });
    }
};


/***/ }),

/***/ 2604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/footer-logo.svg
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgFooterLogo = function SvgFooterLogo(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 80,
    height: 80,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M12.53 7.157c-2.373 10.891 1.244 21.371 9.784 28.345.826.674.875.733.336.396-6.555-4.091-10.623-10.225-11.943-18.008l-.219-1.294-.053.594c-.803 9.067 4.094 17.973 12.452 22.647.813.455.747.482-.232.098-5.575-2.19-9.876-6.433-12.263-12.098-.214-.51-.39-.893-.392-.852-.001.04.072.43.162.867 1.617 7.81 6.573 13.498 14.05 16.126.444.156.786.285.76.287-.13.01-1.839-.362-2.565-.558-4.285-1.155-7.853-3.65-10.36-7.241-.5-.718-.529-.748-.412-.43 2.227 6.078 7.297 10.134 14.092 11.274.459.078.85.157.87.178.056.06-2.533-.03-3.158-.11-3.492-.45-6.402-1.782-8.726-3.995l-.494-.47.184.364c2.09 4.124 6.18 6.246 12.89 6.686 1.408.093 1.419.117.151.331-2.936.498-6.208.076-8.356-1.078-.582-.313-.604-.276-.128.208.316.322.39.452.614 1.093 2.314 6.6 7.89 11.945 14.69 14.083l.779.245.175.704c.772 3.105.517 4.025-.979 3.53-1.302-.433-2.01-.287-2.712.556-.316.38-.267.408.335.192l.498-.179.348.174.348.173 1.593-.04c2.142-.055 2.014.019 2.199-1.287.522-3.695.402-3.397 1.317-3.272 1.088.149 3.578.2 4.792.1 1.176-.096 1.005-.221 1.218.893.489 2.567.157 3.25-1.286 2.654-1.014-.42-2.058-.173-2.616.618-.244.348-.214.36.377.157l.498-.173.336.178.337.177 1.69-.054c1.93-.063 1.933-.064 2.009-.608.394-2.856 1-5.89 1.394-6.985l.095-.264.117.396c.41 1.396 1.454 2.28 3.095 2.622 2.127.442 2.179.488 2.652 2.349.175.687.18.649-.115.736-.61.18-1.128.65-1.326 1.2-.18.5-.316.466 1.849.466h1.95l-.034-.149c-.046-.202-.354-2.368-.407-2.86-.024-.218-.084-.65-.135-.958-.27-1.648-.127-3.636.438-6.122.11-.489.21-1.065.219-1.281l.017-.393.2.115c.495.284.468-.008.506 5.565l.033 4.992.15.275c.196.36.578.664.988.785.595.174 9.536.142 9.716-.035.311-.306.165-.388-2.168-1.222-2.572-.918-2.86-.942-3.188-.266l-.112.231h-1.957c-2.438 0-2.118.75-2.118-4.958v-4.8l.48-.527c2.987-3.275 4.87-7.085 5.594-11.314l.16-.937.43-.485c.653-.737 1.737-2.31 1.737-2.52 0-.036-.297.215-.659.557-2.65 2.503-6.179 3.839-10.363 3.924-1.498.03-1.5.034.226-.298 6.181-1.187 10.755-4.84 13.159-10.513.377-.89.366-.931-.078-.297-2.835 4.051-6.796 6.628-11.78 7.665-1.216.252-1.35.256-.653.015 7.611-2.631 12.594-8.303 14.25-16.225.19-.91.161-.931-.17-.129-2.379 5.753-6.773 10.084-12.482 12.302-.997.387-1.032.383-.288-.034 8.229-4.614 12.675-12.082 12.68-21.294 0-1.757-.076-2.44-.175-1.567-.867 7.644-5.292 14.537-12.068 18.797-.573.36-.546.329.33-.393 8.349-6.87 11.946-16.748 9.979-27.4-.311-1.684-.324-1.69-.42-.17-.568 9.053-3.252 16.318-7.895 21.363l-.284.31-.611-.72c-9.532-11.232-27.565-10.508-35.982 1.446l-.361.513-.26-.248c-5.38-5.121-8.517-12.972-9.12-22.823-.037-.597-.077-1.095-.09-1.107-.013-.013-.073.207-.135.489Zm30.836 15.026a21.774 21.774 0 0 1 14.418 7.772c.491.592.499.503-.086 1.064-1.548 1.487-3.391 2.782-5.427 3.813-1.298.657-1.239.569-1.096 1.638.605 4.537-.745 8.78-3.662 11.51l-.608.57.173.256c2.567 3.787 10.38 4.223 13.848.773.691-.689.686-.695-.207-.255-2.209 1.09-5.336 1.458-8.171.964-1.192-.208-1.225-.24-.306-.292 4.61-.262 6.768-.81 9.236-2.343.772-.48.725-.525.481.461-.833 3.37-2.595 6.701-4.806 9.087l-.301.325-.459-.45c-.252-.249-.807-.684-1.232-.97-.425-.284-.94-.661-1.144-.838-.842-.728-1.525-1.019-2.771-1.18-1.725-.222-3.26-.855-4.005-1.65l-.271-.29-.033.342c-.019.188-.066.686-.105 1.107-.076.818-.253 1.602-.465 2.06l-.13.282.036-2.447c.05-3.411-.086-4.743-.629-6.127-.133-.34-.66-1.714-1.173-3.055-1.088-2.849-.91-2.54-1.315-2.294-.451.274-1.098.427-1.592.376-.537-.055-.681-.141-.34-.203 1.637-.299 2.925-1.481 3.824-3.51.724-1.634 1.242-2.424 2.183-3.324l.504-.482-.504.176c-.687.24-1.018.413-1.634.848-.635.448-.651.451-.37.066.81-1.11 2.687-2.142 3.894-2.142.288 0 .237-.092-.211-.387-1.265-.83-2.739-.778-4.238.152-.44.273-.46.263-.231-.122l.18-.3-.325-.204c-1.486-.928-2.622-.599-5.114 1.484-1.95 1.63-2.726 2.065-3.946 2.213l-.338.041.32.338c.523.552 1.315.884 2.105.884h.302l-.612.678c-1.494 1.655-2.955 4.536-2.955 5.826 0 .054.338-.241.75-.657.728-.733.964-.909.665-.496-1.901 2.627-2.132 8.24-.55 13.383.143.466.237.824.21.794-.027-.03-.362-.516-.745-1.08-.511-.754-.702-.99-.722-.892-.257 1.223.245 5.895.805 7.5.16.46.197.452-.678.136-5.503-1.992-10.115-6.215-12.403-11.356-.38-.853-.384-.83.117-.637 4.276 1.653 9.409.645 11.399-2.237l.216-.313-.792-.779c-2.78-2.734-4.002-6.676-3.474-11.21.139-1.19.178-1.12-.926-1.67-1.789-.89-3.446-1.982-4.813-3.174-.07-.06.029-.234.496-.864 3.856-5.2 9.587-8.315 16.158-8.78.593-.042 2.936.017 3.595.09Zm-1.188 12.455c.236.465.166.529-.942.869-.804.246-.804.22.006-.511.833-.752.752-.722.936-.358Zm.914 27.946c.06.273.19.74.29 1.04.098.299.165.556.149.572-.2.192-3.717.198-5.138.009l-.748-.1c-.006 0 .077-.318.183-.708a8.755 8.755 0 0 0 .294-2.79l-.046-.69.533.524c.739.725 1.559 1.28 2.741 1.853 1.343.65 1.221.71 1.26-.619.025-.837.063-1.196.158-1.471l.124-.364.045 1.124c.025.62.094 1.347.155 1.62Zm3.815 1.868c-.118.264-.214.5-.214.526 0 .025.44.334.977.686 1.112.729 1.071.68 1.203 1.46.172 1.023.193.933-.258 1.114-.68.272-1.153.79-1.283 1.405l-.045.215h3.299l.064-.248c.28-1.08.303-1.329.218-2.323-.128-1.505-.112-1.45-.437-1.531-1.29-.323-2.23-.774-2.852-1.37a10.45 10.45 0 0 0-.445-.413c-.008 0-.11.216-.227.48Z",
    fill: "#fff"
  })));
};
/* harmony default export */ const footer_logo = (SvgFooterLogo);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./assets/marketplace.svg
var marketplace = __webpack_require__(1902);
;// CONCATENATED MODULE: ./constants/menu.js


const menuLinks = [
    {
        id: 1,
        title: "Marketplace",
        url: "https://nft.yourlifegames.com/nftMarket",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(marketplace/* default */.Z, {})
    },
    {
        id: 2,
        title: "Transfers",
        url: "https://nft.yourlifegames.com/nftMarket"
    },
    {
        id: 3,
        title: "My account",
        url: "https://nft.yourlifegames.com/myaccount"
    },
    {
        id: 4,
        title: "Collections",
        url: "https://nft.yourlifegames.com/collections"
    },
    {
        id: 5,
        title: "Chat",
        url: "https://nft.yourlifegames.com/chat"
    }, 
];
const footerLinks = [
    {
        id: 1,
        title: "Marketplace",
        url: "https://nft.yourlifegames.com/nftMarket",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(marketplace/* default */.Z, {})
    },
    {
        id: 2,
        title: "BUY BNB",
        url: "https://www.binance.us/"
    },
    {
        id: 3,
        title: "HELP",
        url: "https://docs.yourlife.io/"
    }, 
];
/* harmony default export */ const menu = ((/* unused pure expression or super */ null && (menuLinks)));

// EXTERNAL MODULE: external "react-moralis"
var external_react_moralis_ = __webpack_require__(6921);
;// CONCATENATED MODULE: ./components/Footer.js






function Footer() {
    const { 0: tokenURI , 1: setTokenURI  } = (0,external_react_.useState)("");
    const { authenticate , isAuthenticated , user  } = (0,external_react_moralis_.useMoralis)();
    (0,external_react_.useEffect)(()=>{
        setTokenURI(`?token=${user?.id}`);
    }, [
        isAuthenticated
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "px-3 w-full",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full h-[136px] flex items-center px-5 md:px-7 bg-[#61616A] rounded-lg",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(footer_logo, {
                            className: "h-20"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden md:flex items-center",
                            children: footerLinks.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `${link.url}${tokenURI}`,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "flex text-md text-white uppercase underline underline-offset-8 underline-color decoration-[#3985F5] mr-4",
                                        children: [
                                            link.icon && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mr-2",
                                                children: link.icon
                                            }),
                                            link.title
                                        ]
                                    })
                                }, link.id))
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "uppercase text-[#646464] ml-5 sm:ml-14",
                children: "Yourlife. 2022"
            })
        ]
    });
};


/***/ }),

/***/ 8010:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Account__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2782);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6921);
/* harmony import */ var react_moralis__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_moralis__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_marketplace_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1902);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _state_ylttoast_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2684);
/* harmony import */ var react_onesignal__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(210);
/* harmony import */ var react_onesignal__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_onesignal__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react-hooks/exhaustive-deps */ 










function Navbar({ setIsLoading  }) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const notiInfo = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)(({ notification  })=>notification.value);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const set = notiInfo.set;
        const data = notiInfo.data;
        if (set && data) {
            if (data.type == 1) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast)(data.msg, {
                    type: react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.TYPE.INFO,
                    autoClose: 6000
                });
            }
            if (data.type == 3) {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast)(data.msg, {
                    type: react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.TYPE.WARNING,
                    autoClose: 6000
                });
            }
            clearNotify();
        }
    }, [
        notiInfo
    ]);
    const clearNotify = ()=>{
        const msg = {
            set: false,
            data: {}
        };
        dispatch(_state_ylttoast_index__WEBPACK_IMPORTED_MODULE_9__/* .setNotification */ .s(msg));
    };
    const { 0: eventsModalOpen , 1: setEventsModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: tokenURI , 1: setTokenURI  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { authenticate , isAuthenticated , user , enableWeb3 , Moralis  } = (0,react_moralis__WEBPACK_IMPORTED_MODULE_6__.useMoralis)();
    const authUser = async ()=>{
        const connectorId = window.localStorage.getItem("connectorId");
        await enableWeb3({
            throwOnError: true,
            provider: connectorId
        });
        const { account , chainId  } = Moralis;
        const { message  } = await Moralis.Cloud.run("requestMessage", {
            address: account,
            chain: parseInt(chainId, 16),
            url: "https://swapdev.yourlife.io",
            networkType: "evm"
        });
        // Authenticate and login via parse
        await authenticate({
            signingMessage: message,
            throwOnError: true
        }).then((user)=>{
            if (user) {} else {}
        });
    };
    const eventsModalOpenHandler = ()=>setEventsModalOpen(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setTokenURI(`?token=${user?.id}`);
        if (user != null && user.attributes.isSuperAdmin) {
            react_onesignal__WEBPACK_IMPORTED_MODULE_10___default().sendTag("admin", "superAdmin");
        }
    }, [
        isAuthenticated
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full flex items-center h-20 px-3 text-center shrink-0 navbar-zindex",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: "/assets/swapWagonLogo.png",
                    alt: "no image",
                    className: "h-[80px]"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex h-full w-full items-center justify-end",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative items-center hidden lg:flex lg:gap-x-8",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex text-[18px] text-[#ffffff] decoration-[#3985F5]",
                                children: "Swap"
                            })
                        }, 1),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            kye: 2,
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex text-[18px] text-[#ffffff] decoration-[#3985F5]",
                                children: "How it works"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            kye: 3,
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex text-[18px] text-[#ffffff] decoration-[#3985F5]",
                                children: "FAQ"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            kye: 3,
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex text-[18px] text-[#ffffff] decoration-[#3985F5]",
                                children: "$ATK"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Account__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            setIsLoading: setIsLoading,
                            openEventsModal: eventsModalOpenHandler,
                            onAuth: authUser
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
        ]
    });
};
;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Preloader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Preloader_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6623);
/* harmony import */ var _Preloader_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Preloader_module_css__WEBPACK_IMPORTED_MODULE_1__);


function Preloader() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Preloader_module_css__WEBPACK_IMPORTED_MODULE_1___default().wrapper),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_Preloader_module_css__WEBPACK_IMPORTED_MODULE_1___default().preloader),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
            ]
        })
    });
};


/***/ }),

/***/ 5806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useOutsideClick)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useOutsideClick(ref, handler) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const listener = (event)=>{
            const { target  } = event;
            if (!ref.current || ref.current.contains(target)) {
                return;
            }
            handler(event);
        };
        document.addEventListener("click", listener);
        return ()=>{
            document.removeEventListener("click", listener);
        };
    }, [
        ref,
        handler
    ]);
};


/***/ }),

/***/ 2684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "s": () => (/* binding */ setNotification)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: {
        set: false,
        data: {}
    }
};
const notificationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "notification",
    initialState,
    reducers: {
        setNotification: (state, action)=>{
            state.value = action.payload;
        }
    }
});
const { setNotification  } = notificationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (notificationSlice.reducer);


/***/ })

};
;