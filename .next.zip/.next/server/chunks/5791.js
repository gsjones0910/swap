"use strict";
exports.id = 5791;
exports.ids = [5791];
exports.modules = {

/***/ 5791:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ Scrolling)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_fast_marquee__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5700);
/* harmony import */ var react_fast_marquee__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_fast_marquee__WEBPACK_IMPORTED_MODULE_1__);


const Scrolling = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_fast_marquee__WEBPACK_IMPORTED_MODULE_1___default()), {
        direction: "right",
        speed: 5,
        gradient: false,
        style: {
            position: "absolute",
            opacity: 0.7,
            overflow: "hidden",
            width: "100%",
            height: "100%",
            backgroundColor: "#f6f6f7"
        },
        className: "marquee-wrapper",
        children: Array.from({
            length: 8
        }).map((_, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex items-center justify-between w-full h-full -rotate-12",
                children: Array.from({
                    length: 4
                }).map((_, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "marquee-text",
                        children: "swap"
                    }, `text-${index}`))
            }, `container-${index}`))
    });
};


/***/ })

};
;